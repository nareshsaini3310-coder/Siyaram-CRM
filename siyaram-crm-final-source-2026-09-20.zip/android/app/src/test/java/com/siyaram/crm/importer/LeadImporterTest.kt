package com.siyaram.crm.importer

import com.siyaram.crm.data.ColourEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LeadImporterTest {
    private val colours = listOf(
        ColourEntity(1, "Orange", "#EF9F27", "warm", 3, 1),
        ColourEntity(2, "Purple", "#7F77DD", "visit", 1, 2),
        ColourEntity(3, "Red", "#E24B4A", "daily", 1, 3),
        ColourEntity(4, "Grey", "#888780", "none", null, 4),
    )

    @Test fun normalizesIndianPhoneVariantsAndScientificNotation() {
        assertEquals("7428846731", LeadImporter.cleanPhone("742 884 6731"))
        assertEquals("9876543210", LeadImporter.cleanPhone("+91 9876543210"))
        assertEquals("9876543211", LeadImporter.cleanPhone("09876543211"))
        assertEquals("9876543210", LeadImporter.cleanPhone("9.87654321E9"))
        assertEquals("", LeadImporter.cleanPhone("12345"))
    }

    @Test fun parsesQuotedCsv() {
        val table = CsvParser.parse("Name,Remarks\n\"Mohit, Yadav\",\"He said \"\"call, tomorrow\"\"\"".byteInputStream())
        assertEquals("Mohit, Yadav", table.rows[1][0])
        assertEquals("He said \"call, tomorrow\"", table.rows[1][1])
    }

    @Test fun countsFirstOccurrenceAndInvalidRows() {
        val rows = listOf(listOf("Name", "Mobile", "Status"), listOf("A", "7428846731", "Orange"), listOf("B", "7428846731", "Grey"), listOf("C", "12345", "Orange"))
        val preview = LeadImporter.preview(rows, emptySet(), colours)
        assertEquals(2, preview.total)
        assertEquals(1, preview.newLeads.size)
        assertEquals(1, preview.duplicates)
        assertEquals(1, preview.invalid)
        assertTrue(preview.newLeads.single().name == "A")
    }
}
