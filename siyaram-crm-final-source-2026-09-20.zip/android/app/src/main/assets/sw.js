const CACHE_NAME = 'siyaram-crm-v1.5.0';
const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg',
  '/pwa-192x192.png',
  '/pwa-512x512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      // Use resilient individual caching so a single asset failure never breaks the service worker
      await Promise.allSettled(
        PRECACHE_URLS.map(async (url) => {
          try {
            await cache.add(url);
          } catch (e) {
            console.warn('SW pre-cache skipped for:', url, e);
          }
        })
      );
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET' || event.request.url.includes('/api/')) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        fetch(event.request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, networkResponse));
          }
        }).catch(() => {});
        return cachedResponse;
      }
      return fetch(event.request).then((networkResponse) => {
        return networkResponse;
      }).catch(() => {
        if (event.request.mode === 'navigate') {
          return caches.match('/');
        }
      });
    })
  );
});

// Handle Background / Scheduled Notifications
self.addEventListener('message', (event) => {
  if (!event.data) return;

  if (event.data.type === 'SHOW_NOTIFICATION') {
    const { title, options } = event.data;
    const defaultOptions = {
      icon: '/pwa-192x192.png',
      badge: '/icon.svg',
      vibrate: [200, 100, 200, 100, 300],
      requireInteraction: true,
      tag: options?.tag || 'crm-followup-alert',
      renotify: true,
      data: options?.data || { url: '/' },
      ...options,
    };

    self.registration.showNotification(title, defaultOptions);
  }
});

// Handle Native Notification Click
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const data = event.notification.data || {};
  const action = event.action;

  if (action === 'call' && data.phone) {
    const cleanNum = data.phone.replace(/[^0-9+]/g, '');
    if (clients.openWindow) {
      event.waitUntil(clients.openWindow(`tel:${cleanNum}`));
    }
    return;
  }

  if (action === 'whatsapp' && (data.whatsapp || data.phone)) {
    const cleanNum = (data.whatsapp || data.phone).replace(/[^0-9]/g, '');
    if (clients.openWindow) {
      event.waitUntil(clients.openWindow(`https://wa.me/${cleanNum}`));
    }
    return;
  }

  // Default: focus existing CRM window or open a new one
  const targetUrl = data.url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});
