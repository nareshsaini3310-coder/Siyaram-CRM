package com.siyaram.crm.importer

import com.siyaram.crm.data.ColourEntity
import java.math.BigDecimal
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

private fun key(value: String) = value.lowercase(Locale.ROOT).replace(Regex("[\\s_./()\\-]+"), "")
private val aliases = mapOf(
    "name" to setOf("name", "clientname", "naam", "customer", "party", "buyername"),
    "phone" to setOf("mobile", "phone", "number", "contact", "mobno", "mobilenumber"),
    "budget" to setOf("budget", "budgetrange"),
    "size" to setOf("size", "plotsize", "area", "gaj"),
    "project" to setOf("project", "projectname", "site"),
    "status" to setOf("status", "colour", "color", "stage"),
    "remarks" to setOf("remarks", "notes", "comment", "feedback"),
    "source" to setOf("source")
)

data class ColumnMap(val fields: Map<String, Int>, val ignored: List<String>, val headerUsed: Boolean)
data class MappedLead(val rowNumber: Int, val name: String, val phone: String, val budget: String, val size: String, val project: String, val status: String, val remarks: String, val source: String)
data class ImportPreview(val total: Int, val newLeads: List<MappedLead>, val duplicates: Int, val invalid: Int, val columns: ColumnMap, val projects: List<String>)

object LeadImporter {
    fun cleanPhone(raw: String): String {
        val trimmed = raw.trim()
        val expanded = if (trimmed.matches(Regex("[0-9]+(?:\\.[0-9]+)?[eE][+-]?[0-9]+"))) {
            runCatching { BigDecimal(trimmed).toBigInteger().toString() }.getOrDefault(trimmed)
        } else trimmed
        val digits = expanded.filter(Char::isDigit)
        return if (digits.length >= 10) digits.takeLast(10) else ""
    }

    fun detectColumns(rows: List<List<String>>): ColumnMap {
        if (rows.isEmpty()) throw ImportException("File mein data nahi mila.")
        val first = rows.first()
        val fields = mutableMapOf<String, Int>()
        first.forEachIndexed { index, value -> aliases.entries.firstOrNull { it.value.contains(key(value)) }?.let { fields.putIfAbsent(it.key, index) } }
        val headerUsed = fields.containsKey("name") || fields.containsKey("phone")
        if (!headerUsed) {
            val width = rows.maxOf { it.size }
            val phoneColumn = (0 until width).maxByOrNull { column -> rows.take(30).count { cleanPhone(it.getOrNull(column).orEmpty()).isNotEmpty() } }
            if (phoneColumn == null || rows.drop(1).count { cleanPhone(it.getOrNull(phoneColumn).orEmpty()).isNotEmpty() } == 0) throw ImportException("Phone column nahi mila. File mein mobile number zaroori hai.")
            fields["phone"] = phoneColumn
            fields["name"] = (0 until width).firstOrNull { column -> column != phoneColumn && rows.drop(1).count { it.getOrNull(column).orEmpty().any(Char::isLetter) } >= rows.drop(1).size / 2 } ?: throw ImportException("Name column nahi mila.")
        }
        val ignored = first.mapIndexedNotNull { index, value -> if (index !in fields.values) value.ifBlank { "Column ${index + 1}" } else null }
        return ColumnMap(fields, ignored, headerUsed)
    }

    fun preview(rows: List<List<String>>, existingPhones: Set<String>, colours: List<ColourEntity>): ImportPreview {
        val map = detectColumns(rows)
        val dataRows = if (map.headerUsed) rows.drop(1) else rows
        val seen = existingPhones.toMutableSet()
        val leads = mutableListOf<MappedLead>()
        var duplicates = 0
        var invalid = 0
        dataRows.forEachIndexed { index, row ->
            val phone = cleanPhone(row.getOrNull(map.fields.getValue("phone")).orEmpty())
            if (phone.isBlank()) { invalid++; return@forEachIndexed }
            if (!seen.add(phone)) { duplicates++; return@forEachIndexed }
            leads += MappedLead(
                index + 1,
                row.getOrNull(map.fields["name"] ?: -1).orEmpty().ifBlank { "Naam nahi" },
                phone,
                row.getOrNull(map.fields["budget"] ?: -1).orEmpty(),
                row.getOrNull(map.fields["size"] ?: -1).orEmpty(),
                row.getOrNull(map.fields["project"] ?: -1).orEmpty().ifBlank { "General" },
                row.getOrNull(map.fields["status"] ?: -1).orEmpty(),
                row.getOrNull(map.fields["remarks"] ?: -1).orEmpty(),
                row.getOrNull(map.fields["source"] ?: -1).orEmpty().ifBlank { "Excel se" }
            )
        }
        return ImportPreview(dataRows.size, leads, duplicates, invalid, map, leads.map { it.project }.distinctBy(String::lowercase))
    }

    fun colourFor(status: String, colours: List<ColourEntity>): ColourEntity {
        val text = status.trim().lowercase()
        return colours.firstOrNull { it.name.lowercase() == text }
            ?: colours.firstOrNull { text.isNotBlank() && text.contains(it.name.lowercase()) }
            ?: colours.firstOrNull { it.name.equals("Orange", true) }
            ?: colours.first()
    }

    fun followUpAt(colour: ColourEntity, rowIndex: Int, now: Long): Long? {
        if (colour.days == null) return null
        val day = LocalDate.ofInstant(java.time.Instant.ofEpochMilli(now), ZoneId.systemDefault()).plusDays((colour.days + rowIndex % 3).toLong())
        return day.atTime(11, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }
}
