package com.siyaram.crm.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [ColourEntity::class, ProjectEntity::class, LeadEntity::class, InteractionEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun colours(): ColourDao
    abstract fun projects(): ProjectDao
    abstract fun leads(): LeadDao
    abstract fun interactions(): InteractionDao

    companion object {
        fun create(context: Context): AppDatabase = Room.databaseBuilder(context, AppDatabase::class.java, "siyaram-leads.db")
            .addCallback(object : Callback() {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    super.onCreate(db)
                    db.execSQL("INSERT INTO colours(id,name,hex,rule,days,sortOrder) VALUES (1,'Orange','#EF9F27','warm',3,1),(2,'Purple','#7F77DD','visit',1,2),(3,'Red','#E24B4A','daily',1,3),(4,'Grey','#888780','none',NULL,4),(5,'Green','#639922','green',3,5)")
                }
            }).build()
    }
}
