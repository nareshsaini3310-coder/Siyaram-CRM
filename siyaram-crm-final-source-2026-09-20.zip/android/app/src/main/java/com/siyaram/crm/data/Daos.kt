package com.siyaram.crm.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Upsert

@Dao
interface ColourDao {
    @Query("SELECT * FROM colours ORDER BY sortOrder") suspend fun all(): List<ColourEntity>
    @Insert suspend fun insertAll(items: List<ColourEntity>)
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY name") suspend fun all(): List<ProjectEntity>
    @Query("SELECT * FROM projects WHERE lower(name) = lower(:name) LIMIT 1") suspend fun byName(name: String): ProjectEntity?
    @Insert suspend fun insert(item: ProjectEntity): Long
}

@Dao
interface LeadDao {
    @Query("SELECT * FROM leads WHERE archived = 0 ORDER BY createdAt DESC") suspend fun active(): List<LeadEntity>
    @Query("SELECT * FROM leads WHERE id = :id LIMIT 1") suspend fun byId(id: Long): LeadEntity?
    @Query("SELECT phoneClean FROM leads") suspend fun allPhoneClean(): List<String>
    @Insert suspend fun insert(item: LeadEntity): Long
    @Upsert suspend fun update(item: LeadEntity)
}

@Dao
interface InteractionDao {
    @Insert suspend fun insert(item: InteractionEntity): Long
    @Query("SELECT * FROM interactions WHERE leadId = :leadId ORDER BY at DESC") suspend fun forLead(leadId: Long): List<InteractionEntity>
}
