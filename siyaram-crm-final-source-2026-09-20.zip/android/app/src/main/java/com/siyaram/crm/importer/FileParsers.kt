package com.siyaram.crm.importer

import android.util.Xml
import java.io.InputStream
import java.util.zip.ZipInputStream
import kotlin.math.max

class ImportException(message: String) : Exception(message)
data class ParsedTable(val rows: List<List<String>>, val format: String)

object CsvParser {
    fun parse(input: InputStream): ParsedTable {
        val text = input.readBytes().toString(Charsets.UTF_8).removePrefix("\uFEFF")
        if (text.isBlank()) throw ImportException("File khaali hai.")
        val delimiter = detectDelimiter(text)
        val rows = mutableListOf<MutableList<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var i = 0
        fun endField() { row += field.toString(); field.clear() }
        fun endRow() { endField(); if (row.any { it.isNotBlank() }) rows += row; row = mutableListOf() }
        while (i < text.length) {
            val ch = text[i]
            when {
                ch == '"' && quoted && i + 1 < text.length && text[i + 1] == '"' -> { field.append('"'); i++ }
                ch == '"' -> quoted = !quoted
                ch == delimiter && !quoted -> endField()
                (ch == '\n' || ch == '\r') && !quoted -> { if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++; endRow() }
                else -> field.append(ch)
            }
            i++
        }
        if (quoted) throw ImportException("CSV quote galat hai.")
        if (field.isNotEmpty() || row.isNotEmpty()) endRow()
        if (rows.isEmpty()) throw ImportException("File mein data nahi mila.")
        return ParsedTable(rows, "CSV")
    }

    private fun detectDelimiter(text: String): Char {
        val first = text.lineSequence().firstOrNull().orEmpty()
        return listOf(',', ';', '\t').maxByOrNull { delimiter -> first.count { it == delimiter } } ?: ','
    }
}

object XlsxParser {
    fun parse(input: InputStream): ParsedTable {
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) entries[entry.name] = zip.readBytes()
                entry = zip.nextEntry
            }
        }
        if (entries.keys.none { it.startsWith("xl/") && it.endsWith(".xml") }) throw ImportException("XLSX file corrupt hai.")
        val shared = entries["xl/sharedStrings.xml"]?.let(::readSharedStrings).orEmpty()
        val sheet = entries.keys.filter { it.startsWith("xl/worksheets/") && it.endsWith(".xml") }.sorted().firstOrNull()
            ?: throw ImportException("XLSX mein worksheet nahi mili.")
        return ParsedTable(readSheet(entries.getValue(sheet), shared), "XLSX")
    }

    private fun readSharedStrings(bytes: ByteArray): List<String> {
        val parser = Xml.newPullParser().apply { setInput(bytes.inputStream(), "UTF-8") }
        val values = mutableListOf<String>()
        var current = StringBuilder()
        var inside = false
        var event = parser.eventType
        while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            if (event == org.xmlpull.v1.XmlPullParser.START_TAG && parser.name == "si") { current = StringBuilder(); inside = true }
            if (event == org.xmlpull.v1.XmlPullParser.TEXT && inside) current.append(parser.text)
            if (event == org.xmlpull.v1.XmlPullParser.END_TAG && parser.name == "si") { values += current.toString(); inside = false }
            event = parser.next()
        }
        return values
    }

    private fun readSheet(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val parser = Xml.newPullParser().apply { setInput(bytes.inputStream(), "UTF-8") }
        val rows = mutableListOf<List<String>>()
        var current = mutableListOf<String>()
        var currentColumn = 0
        var cellType = ""
        var cellValue = StringBuilder()
        var inValue = false
        var inInline = false
        var event = parser.eventType
        while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when (event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> current = mutableListOf()
                    "c" -> { currentColumn = columnIndex(parser.getAttributeValue(null, "r") ?: "A1"); cellType = parser.getAttributeValue(null, "t").orEmpty(); while (current.size <= currentColumn) current += ""; cellValue = StringBuilder(); inInline = false }
                    "v", "t" -> { if (cellType == "inlineStr" || parser.name == "v") inValue = true; if (cellType == "inlineStr") inInline = true }
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if (inValue || inInline) cellValue.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when (parser.name) {
                    "v", "t" -> inValue = false
                    "c" -> { current[currentColumn] = when (cellType) { "s" -> shared.getOrNull(cellValue.toString().toIntOrNull() ?: -1).orEmpty(); else -> cellValue.toString() }; inInline = false }
                    "row" -> if (current.any { it.isNotBlank() }) rows += current
                }
            }
            event = parser.next()
        }
        if (rows.isEmpty()) throw ImportException("XLSX mein data nahi mila.")
        val width = rows.maxOf { it.size }
        return rows.map { it + List(max(0, width - it.size)) { "" } }
    }

    private fun columnIndex(reference: String): Int {
        var result = 0
        for (char in reference.takeWhile { it.isLetter() }) result = result * 26 + (char.uppercaseChar() - 'A' + 1)
        return result - 1
    }
}
