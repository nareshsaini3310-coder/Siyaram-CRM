package com.siyaram.crm.data

import androidx.room.withTransaction
import com.siyaram.crm.importer.ImportPreview
import com.siyaram.crm.importer.LeadImporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LeadRepository(private val database: AppDatabase) {
    suspend fun preview(rows: List<List<String>>): ImportPreview = withContext(Dispatchers.IO) {
        val colours = database.colours().all()
        LeadImporter.preview(rows, database.leads().allPhoneClean().toSet(), colours)
    }
        suspend fun activeLeads(): List<LeadEntity> = withContext(Dispatchers.IO) { database.leads().active() }

    suspend fun import(preview: ImportPreview): ImportResult = withContext(Dispatchers.IO) {
        database.withTransaction {
            val colours = database.colours().all()
            var followUps = 0
            preview.newLeads.forEach { item ->
                val project = database.projects().byName(item.project) ?: ProjectEntity(name = item.project, type = projectType(item.project), createdAt = System.currentTimeMillis()).let { draft ->
                    draft.copy(id = database.projects().insert(draft))
                }
                val colour = LeadImporter.colourFor(item.status, colours)
                val created = System.currentTimeMillis()
                val next = LeadImporter.followUpAt(colour, item.rowNumber, created)
                if (next != null) followUps++
                val leadId = database.leads().insert(LeadEntity(name = item.name, phone = item.phone, phoneClean = item.phone, projectId = project.id, colourId = colour.id, budget = item.budget, size = item.size, source = item.source, createdAt = created, lastContactAt = null, nextFollowUpAt = next, lastTalk = "", nextTalk = "", archived = false))
                database.interactions().insert(InteractionEntity(leadId = leadId, type = "import", at = created, text = "Excel se import hua", source = "Excel import"))
                if (item.remarks.isNotBlank()) database.interactions().insert(InteractionEntity(leadId = leadId, type = "comment", at = created, text = item.remarks, source = "Excel se aaya"))
            }
            ImportResult(preview.newLeads.size, preview.duplicates, followUps)
        }
    }

    private fun projectType(name: String): String {
        val value = name.lowercase()
        return when {
            listOf("floor", "flat", "apartment").any(value::contains) -> "Floors"
            listOf("high", "rise", "tower").any(value::contains) -> "High-rise"
            else -> "Plots"
        }
    }
}

data class ImportResult(val newLeads: Int, val duplicates: Int, val followUps: Int)
