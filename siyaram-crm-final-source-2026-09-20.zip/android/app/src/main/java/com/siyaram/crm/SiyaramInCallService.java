package com.siyaram.crm;

import android.content.Intent;
import android.telecom.Call;
import android.telecom.InCallService;
import android.os.SystemClock;

public class SiyaramInCallService extends InCallService {
    @Override public void onCallAdded(Call call) {
        super.onCallAdded(call);
        final long startedAt = SystemClock.elapsedRealtime();
        call.registerCallback(new Call.Callback() {
            @Override public void onStateChanged(Call c, int state) {
                if (state == Call.STATE_DISCONNECTED) {
                    long duration = Math.max(0L, SystemClock.elapsedRealtime() - startedAt);
                    Intent i = new Intent(MainActivity.ACTION_CALL_ENDED);
                    i.setPackage(getPackageName());
                    i.putExtra("duration_ms", duration);
                    sendBroadcast(i);
                    c.unregisterCallback(this);
                }
            }
        });
    }
}
