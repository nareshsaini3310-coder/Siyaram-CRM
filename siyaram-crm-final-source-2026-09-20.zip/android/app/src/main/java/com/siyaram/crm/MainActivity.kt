package com.siyaram.crm

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import com.siyaram.crm.data.AppDatabase
import com.siyaram.crm.data.ImportResult
import com.siyaram.crm.data.LeadEntity
import com.siyaram.crm.data.LeadRepository
import com.siyaram.crm.importer.CsvParser
import com.siyaram.crm.importer.ImportException
import com.siyaram.crm.importer.ImportPreview
import com.siyaram.crm.importer.XlsxParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SiyaramApp(LeadRepository(AppDatabase.create(this))) }
    }
}

@Composable
private fun SiyaramApp(repository: LeadRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var preview by remember { mutableStateOf<ImportPreview?>(null) }
    var result by remember { mutableStateOf<ImportResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var leads by remember { mutableStateOf<List<LeadEntity>>(emptyList()) }
    var showLeads by remember { mutableStateOf(false) }
    var selectedLead by remember { mutableStateOf<LeadEntity?>(null) }

    fun chooseFile(uri: Uri) {
        scope.launch {
            busy = true
            error = null
            preview = null
            result = null
            try {
                val parsed = withContext(Dispatchers.IO) {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw ImportException("File open nahi ho payi.")
                    when {
                        bytes.size > 25 * 1024 * 1024 -> throw ImportException("File 25 MB se chhoti honi chahiye.")
                        hasPrefix(bytes, byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte())) -> throw ImportException("Purana .xls supported nahi hai. File ko .xlsx ya .csv mein save karein.")
                        hasPrefix(bytes, byteArrayOf(0x50, 0x4B, 0x03, 0x04)) -> XlsxParser.parse(bytes.inputStream())
                        else -> CsvParser.parse(bytes.inputStream())
                    }
                }
                preview = repository.preview(parsed.rows)
            } catch (exception: Exception) {
                error = exception.message ?: "File read nahi ho payi."
            } finally {
                busy = false
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::chooseFile) }
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Siyaram Leads", style = MaterialTheme.typography.headlineMedium)
                Text("Aaj", style = MaterialTheme.typography.titleMedium)
                Button(onClick = { picker.launch(arrayOf("text/csv", "text/tab-separated-values", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/octet-stream")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Excel / CSV choose karo") }
                if (busy) CircularProgressIndicator()
                error?.let { message -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text(message); TextButton(onClick = { error = null }) { Text("Dobara try karo") } } } }
                result?.let { imported ->
                    AnimatedVisibility(true, enter = scaleIn(animationSpec = spring())) {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("✓ Import ho gaya", style = MaterialTheme.typography.titleLarge)
                                Text("${imported.newLeads} new leads · ${imported.duplicates} duplicates · ${imported.followUps} follow-ups set")
                                TextButton(onClick = { scope.launch { leads = repository.activeLeads(); showLeads = true } }) { Text("Leads dekho") }
                            }
                        }
                    }
                }
                preview?.let { current -> PreviewCard(current) {
                    scope.launch {
                        busy = true
                        try { result = repository.import(current); preview = null }
                        catch (exception: Exception) { error = "Import fail hua: ${exception.message ?: "data save nahi hua"}" }
                        finally { busy = false }
                    }
                } }
                if (showLeads) LeadsList(leads) { selectedLead = it }
                selectedLead?.let { lead -> LeadProfile(lead) { selectedLead = null } }
            }
        }
    }
}

@Composable
private fun PreviewCard(preview: ImportPreview, onImport: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Preview", style = MaterialTheme.typography.titleLarge)
            Text("${preview.total} rows · ${preview.newLeads.size} new · ${preview.duplicates} duplicates · ${preview.invalid} invalid")
            Text(if (preview.columns.headerUsed) "Header mapped: ${preview.columns.fields.keys.joinToString()}" else "Header nahi tha: columns data se detect hue")
            if (preview.columns.ignored.isNotEmpty()) Text("Ignored columns: ${preview.columns.ignored.joinToString()}")
            LazyColumn { items(preview.newLeads.take(50)) { lead -> Text("${lead.name} · ${lead.phone} · ${lead.project}", Modifier.padding(vertical = 4.dp)) } }
            Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("${preview.newLeads.size} leads import karo") }
        }
    }
}

@Composable
private fun LeadsList(leads: List<LeadEntity>, onSelect: (LeadEntity) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Leads", style = MaterialTheme.typography.titleLarge)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(leads) { lead ->
                Card(onClick = { onSelect(lead) }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(lead.name, style = MaterialTheme.typography.titleMedium)
                        Text("${lead.phoneClean} · ${lead.budget.ifBlank { "Budget nahi" }}")
                        Text(if (lead.nextFollowUpAt == null) "Follow-up nahi" else "Follow-up set")
                    }
                }
            }
        }
    }
}

@Composable
private fun LeadProfile(lead: LeadEntity, onClose: () -> Unit) {
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(lead.name, style = MaterialTheme.typography.headlineSmall)
            Text("${lead.phoneClean} · ${lead.budget.ifBlank { "Budget nahi" }} · ${lead.size.ifBlank { "Size nahi" }}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${lead.phoneClean}"))) }) { Text("Call") }
                Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${lead.phoneClean}"))) }) { Text("WhatsApp") }
                TextButton(onClick = {}, enabled = false) { Text("Visit") }
                TextButton(onClick = {}, enabled = false) { Text("Refer") }
            }
            Text("Next follow-up: ${if (lead.nextFollowUpAt == null) "Nahi" else "Set"}")
            Text("Source: ${lead.source}")
            TextButton(onClick = onClose) { Text("Back to leads") }
        }
    }
}

private fun hasPrefix(value: ByteArray, prefix: ByteArray): Boolean = value.size >= prefix.size && prefix.indices.all { value[it] == prefix[it] }
