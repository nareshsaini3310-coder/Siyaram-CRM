package com.siyaram.crm

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val callback = filePathCallback
        filePathCallback = null
        callback?.onReceiveValue(uri?.let { arrayOf(it) })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.allowFileAccessFromFileURLs = true
            settings.allowUniversalAccessFromFileURLs = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            CookieManager.getInstance().setAcceptCookie(true)
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = openExternalUrl(request.url.toString())
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = openExternalUrl(url)
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    Log.e("SiyaramWebView", "Load error ${error.description}: ${request.url}")
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = callback
                    return try {
                        filePicker.launch(arrayOf("text/csv", "text/comma-separated-values", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/octet-stream"))
                        true
                    } catch (_: ActivityNotFoundException) {
                        filePathCallback = null
                        callback.onReceiveValue(null)
                        Toast.makeText(this@MainActivity, "File picker nahi mil raha.", Toast.LENGTH_LONG).show()
                        false
                    }
                }
                override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                    Log.d("SiyaramWebView", "${message.message()} ${message.sourceId()}:${message.lineNumber()}")
                    return true
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun openExternalUrl(rawUrl: String): Boolean {
        val uri = Uri.parse(rawUrl)
        val scheme = uri.scheme?.lowercase() ?: return false
        val host = uri.host?.lowercase().orEmpty()
        if (scheme == "https" && (host == "wa.me" || host == "www.wa.me")) return launchExternal(Intent(Intent.ACTION_VIEW, uri), "WhatsApp is not installed.")
        if (scheme == "tel") return launchExternal(Intent(Intent.ACTION_DIAL, uri), "Calling is unavailable on this device.")
        if (scheme == "sms" || scheme == "smsto" || scheme == "mailto" || scheme == "whatsapp" || scheme == "intent") {
            val intent = if (scheme == "intent") runCatching { Intent.parseUri(rawUrl, Intent.URI_INTENT_SCHEME) }.getOrNull() else Intent(Intent.ACTION_SENDTO, uri)
            return intent?.let { launchExternal(it, "No compatible app is installed.") } ?: true
        }
        return false
    }

    private fun launchExternal(intent: Intent, message: String): Boolean = try {
        startActivity(intent)
        true
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        true
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        webView.destroy()
        super.onDestroy()
    }
}
