package com.siyaram.crm.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "colours")
data class ColourEntity(@PrimaryKey val id: Long, val name: String, val hex: String, val rule: String, val days: Int?, val sortOrder: Int)

@Entity(tableName = "projects", indices = [Index(value = ["name"], unique = true)])
data class ProjectEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val type: String, val createdAt: Long)

@Entity(tableName = "leads", indices = [Index(value = ["phoneClean"], unique = true)])
data class LeadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val phoneClean: String,
    val projectId: Long,
    val colourId: Long,
    val budget: String,
    val size: String,
    val source: String,
    val createdAt: Long,
    val lastContactAt: Long?,
    val nextFollowUpAt: Long?,
    val lastTalk: String,
    val nextTalk: String,
    val archived: Boolean = false
)

@Entity(tableName = "interactions")
data class InteractionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val leadId: Long,
    val type: String,
    val at: Long,
    val durationSec: Int? = null,
    val text: String,
    val source: String
)
