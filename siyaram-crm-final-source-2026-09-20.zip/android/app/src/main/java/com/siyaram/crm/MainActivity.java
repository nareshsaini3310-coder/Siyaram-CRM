package com.siyaram.crm;

import android.Manifest;
import android.app.Activity;
import android.app.role.RoleManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.webkit.*;
import android.widget.Toast;
import android.os.SystemClock;

public class MainActivity extends Activity {
    public static final String ACTION_CALL_ENDED = "com.siyaram.crm.CALL_ENDED";
    private WebView web;
    private final BroadcastReceiver callReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { if (web != null) {
                long duration = i.getLongExtra("duration_ms", 0L);
                web.evaluateJavascript("window.dispatchEvent(new CustomEvent(\"siyaram-call-ended\", {detail:{durationMs:" + duration + "}}))", null);
            } }
    };
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.setDownloadListener((u, userAgent, contentDisposition, mime, contentLength) -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))));
        web.addJavascriptInterface(new NativeBridge(), "SiyaramNative");
        web.loadUrl("file:///android_asset/web/index.html"); setContentView(web);
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 42);
        requestDefaultDialerRole();
        registerReceiver(callReceiver, new IntentFilter(ACTION_CALL_ENDED), Context.RECEIVER_NOT_EXPORTED);
    }
    private void requestDefaultDialerRole() {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager)getSystemService(RoleManager.class);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 77);
        }
    }
    public class NativeBridge {
        @JavascriptInterface public void call(String number) {
            try { Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number)); startActivity(i); }
            catch (Exception e) { Toast.makeText(MainActivity.this, "Calling is unavailable on this device", Toast.LENGTH_SHORT).show(); }
        }
    }
    @Override protected void onDestroy() { unregisterReceiver(callReceiver); super.onDestroy(); }
}
