package com.siyaram.crm;

import android.Manifest;
import android.app.Activity;
import android.app.role.RoleManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
    public static final String ACTION_CALL_ENDED = "com.siyaram.crm.CALL_ENDED";
    private static final int CALL_PHONE_REQUEST = 42;
    private static final int RECORD_AUDIO_REQUEST = 43;
    private WebView web;
    private String pendingCallNumber;
    private PermissionRequest pendingAudioRequest;
    private final BroadcastReceiver callReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { if (web != null) {
                long duration = i.getLongExtra("duration_ms", 0L);
                web.evaluateJavascript("window.dispatchEvent(new CustomEvent(\"siyaram-call-ended\", {detail:{durationMs:" + duration + "}}))", null);
            } }
    };
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(true);
        web.getSettings().setAllowUniversalAccessFromFileURLs(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternalUrl(request.getUrl().toString());
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternalUrl(url);
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                String url = (request != null && request.getUrl() != null) ? request.getUrl().toString() : "unknown";
                Log.e("SiyaramWebView", "Page load error: " + error.getDescription() + " url=" + url);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean requestsAudio = false;
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                            requestsAudio = true;
                            break;
                        }
                    }
                    if (!requestsAudio) {
                        request.deny();
                        return;
                    }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        pendingAudioRequest = request;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, RECORD_AUDIO_REQUEST);
                    }
                });
            }

            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingAudioRequest == request) pendingAudioRequest = null;
            }

            @Override public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d("SiyaramWebView", consoleMessage.message() + " :: " + consoleMessage.sourceId() + ":" + consoleMessage.lineNumber());
                return true;
            }
        });
        web.setDownloadListener((u, userAgent, contentDisposition, mime, contentLength) -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))));
        web.addJavascriptInterface(new NativeBridge(), "SiyaramNative");
        web.loadUrl("file:///android_asset/index.html"); setContentView(web);
        requestDefaultDialerRole();
        registerReceiver(callReceiver, new IntentFilter(ACTION_CALL_ENDED), Context.RECEIVER_NOT_EXPORTED);
    }

    private boolean handleExternalUrl(String rawUrl) {
        if (rawUrl == null || rawUrl.isEmpty()) return false;
        Uri uri = Uri.parse(rawUrl);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();

        if ("https".equals(scheme) && ("wa.me".equals(host) || "www.wa.me".equals(host))) {
            openWhatsApp(uri);
            return true;
        }
        if ("tel".equals(scheme)) {
            requestOrPlaceCall(uri.getSchemeSpecificPart());
            return true;
        }
        if ("sms".equals(scheme) || "smsto".equals(scheme)) {
            openSms(uri);
            return true;
        }
        if ("mailto".equals(scheme)) {
            openExternal(new Intent(Intent.ACTION_SENDTO, uri), "No email application is installed");
            return true;
        }
        if ("whatsapp".equals(scheme)) {
            openWhatsApp(uri);
            return true;
        }
        if ("intent".equals(scheme)) {
            try {
                openExternal(Intent.parseUri(rawUrl, Intent.URI_INTENT_SCHEME), "No application can handle this action");
            } catch (Exception e) {
                showMessage("Unable to open this action");
            }
            return true;
        }
        return false;
    }

    private void requestOrPlaceCall(String rawNumber) {
        String number = normalizePhoneNumber(rawNumber);
        if (number.isEmpty()) {
            showMessage("Please enter a valid phone number");
            return;
        }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            pendingCallNumber = number;
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, CALL_PHONE_REQUEST);
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null)));
        } catch (SecurityException e) {
            showMessage("Phone call permission is required");
        } catch (ActivityNotFoundException e) {
            showMessage("Calling is unavailable on this device");
        }
    }

    private void openWhatsApp(Uri source) {
        Intent whatsappIntent = new Intent(Intent.ACTION_VIEW, source);
        whatsappIntent.setPackage("com.whatsapp");
        try {
            startActivity(whatsappIntent);
        } catch (ActivityNotFoundException unavailable) {
            openExternal(new Intent(Intent.ACTION_VIEW, source), "WhatsApp is not installed");
        }
    }

    private void openSms(Uri source) {
        String recipient = source.getSchemeSpecificPart();
        int queryStart = recipient.indexOf('?');
        if (queryStart >= 0) recipient = recipient.substring(0, queryStart);
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", normalizePhoneNumber(recipient), null));
        String body = getQueryParameter(source, "body");
        if (body != null) smsIntent.putExtra("sms_body", body);
        openExternal(smsIntent, "No SMS application is installed");
    }

    private String getQueryParameter(Uri source, String name) {
        String raw = source.toString();
        int queryStart = raw.indexOf('?');
        if (queryStart < 0) return null;
        String[] parameters = raw.substring(queryStart + 1).split("&");
        for (String parameter : parameters) {
            String[] pair = parameter.split("=", 2);
            if (pair.length == 2 && name.equals(Uri.decode(pair[0]))) return Uri.decode(pair[1]);
        }
        return null;
    }

    private void openExternal(Intent intent, String unavailableMessage) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            showMessage(unavailableMessage);
        }
    }

    private String normalizePhoneNumber(String rawNumber) {
        if (rawNumber == null) return "";
        String number = rawNumber.replaceAll("[^0-9+]", "");
        int plus = number.indexOf('+');
        return plus > 0 ? number.replace("+", "") : number;
    }

    private void showMessage(String message) {
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RECORD_AUDIO_REQUEST) {
            PermissionRequest request = pendingAudioRequest;
            pendingAudioRequest = null;
            if (request == null) return;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            } else {
                request.deny();
            }
            return;
        }
        if (requestCode != CALL_PHONE_REQUEST) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && pendingCallNumber != null) {
            String number = pendingCallNumber;
            pendingCallNumber = null;
            requestOrPlaceCall(number);
        } else {
            pendingCallNumber = null;
            showMessage("Phone call permission is required to place a call");
        }
    }
    private void requestDefaultDialerRole() {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager)getSystemService(RoleManager.class);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 77);
        }
    }
    public class NativeBridge {
        @JavascriptInterface public void call(String number) {
            runOnUiThread(() -> requestOrPlaceCall(number));
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
            return;
        }
        super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (pendingAudioRequest != null) pendingAudioRequest.deny();
        unregisterReceiver(callReceiver);
        super.onDestroy();
    }
}
