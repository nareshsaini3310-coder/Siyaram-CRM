# Siyaram Android shell

Native Android wrapper for the Siyaram CRM PWA.

## What it provides
- `ACTION_CALL` cellular calling through Android Telecom.
- `InCallService` disconnect callback.
- Call duration forwarded to the WebView as `siyaram-call-ended` with `event.detail.durationMs`.
- Default-dialer role request on Android 10+.
- JavaScript bridge: `window.SiyaramNative.call(number)`.

## Build
Siyaram native importer

Phone-only build: open GitHub Actions and run **Build Siyaram APK**. Download the `siyaram-debug-apk` artifact. The debug APK is signed automatically and targets Android 9+.

Laptop build with JDK 17 and Android SDK platform 35:

```sh
cd android
gradle test
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

The app uses Storage Access Framework, no storage permission, Room, Kotlin Compose, and no spreadsheet parsing library. Parsing runs off the main thread, and projects, leads, and interactions save in one Room transaction.
