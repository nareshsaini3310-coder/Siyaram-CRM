# Siyaram Android shell

Native Android wrapper for the Siyaram CRM PWA.

## What it provides
- `ACTION_CALL` cellular calling through Android Telecom.
- `InCallService` disconnect callback.
- Call duration forwarded to the WebView as `siyaram-call-ended` with `event.detail.durationMs`.
- Default-dialer role request on Android 10+.
- JavaScript bridge: `window.SiyaramNative.call(number)`.

## Build
1. Run `npm install`.
2. Run `npm run build:android`. This creates `android/app/src/main/assets/web/` from the Vite production build.
3. Open the `android/` folder in Android Studio with Android SDK 35 installed.
4. Build the `app` debug/release APK.

The current development environment does not include Android SDK/Gradle, so APK compilation cannot be truthfully marked as device-tested here.
