# Siyaram Design System

## Rule 1 — Single source of truth
All brand colors, typography, glass surfaces, spacing, radii and reusable controls must come from the central theme/design tokens. Do not invent one-off visual styles in individual screens.

## Brand palette
- Primary / actions: `#2563EB`
- Secondary / premium highlights: `#8B5CF6`
- Success / completed / WhatsApp: `#10B981`
- Warning / warm / attention: `#F59E0B`
- Danger / overdue / missed: `#EF4444`
- Info / cold / informational: `#06B6D4`
- Dark background: `#07111F`
- Light background: `#F5F8FF`

## Lead status
- Hot: red / urgent, follow-up every 3 days
- Warm: amber, follow-up every 7 days
- Cold: cyan/blue, follow-up every 15 days
- Overdue: red
- Completed: green

## Visual language
- iOS-inspired, not a literal copy
- Liquid glass / frosted surfaces
- 40px-ish backdrop blur for major glass surfaces
- 20px large card radius, 14px compact controls
- White/silver highlights on glass edges
- Blue/violet brand glow; avoid gold as the primary brand color

## Notifications
- Morning agenda
- Follow-up reminder
- 2-minute pre-call alert where the platform supports it
- Due/overdue alert
- Old-lead alert
- Site-visit reminder
- Action confirmation
- Notification taps should deep-link to the relevant client/action where the platform permits it.

## Product rule
Siyaram is rule-based. No AI integration is required for CRM workflows.

## Development pass 2026-09-20
- Lead Radar uses deterministic Hot/Warm/Cold rules: Hot=3 days, Warm=7 days, Cold=15 days.
- Overdue calculations use the current device date; no hard-coded demo date.
- Dashboard direct calls use the shared native bridge.
- High-visibility legacy gold/red accents are being migrated to the locked blue/violet/semantic status palette.
