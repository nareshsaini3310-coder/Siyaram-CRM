# Siyaram Development Status

## Pass: 2026-09-20

Completed in this pass:
- Added `src/utils/leadRules.ts` for deterministic Hot/Warm/Cold reminder rules (3/7/15 days).
- Removed Dashboard's hard-coded overdue date and replaced it with current-date logic.
- Added Dashboard Lead Radar for clients with overdue work or no next action.
- Routed Dashboard direct calls through the shared native call bridge.
- Fixed Dashboard follow-up filtering to use the actual `FollowUp.type` field.
- Continued migration of visible legacy gold/red accents toward the locked blue/violet + semantic status palette.
- Updated design-system documentation.

Verification:
- Static TypeScript check was attempted, but dependencies are not installed in the working environment.
- `npm install` timed out, so a production Vite build could not be completed in this pass.
- No AI integration was added.

Next priority:
1. Post-call popup with Tomorrow / 3 / 7 / 15 / Custom and Save & Next.
2. Native Android call lifecycle bridge.
3. Excel import + duplicate phone/date rules.
4. Notification Center refinement and Android packaging/testing.

## Development Pass 03
- Upgraded client call return flow into a glass post-call sheet.
- Shows call duration, next action (Call/WhatsApp/Site Visit), and follow-up chips (Tomorrow/3/15 days).
- Save action now reads “Save & Next” and resets call state cleanly.
- Kept AI out of the implementation.


## Phase 1 Completion Pass 04 — 2026-09-20
- Save & Next now commits the completed call as a real `call` communication log with duration/status.
- Save & Next advances to the next pending call scheduled for today; when none remain, it returns to Dashboard.
- Post-call follow-up options now include Tomorrow / 3 Days / 7 Days / 15 Days / Custom date.
- Selected next action is persisted into the next follow-up type (Call / WhatsApp / Site Visit).
- Custom follow-up date is stored deterministically without AI.
- Kept the implementation local/rule-based; no AI integration added.

Verification note:
- Source-level changes completed and reviewed.
- Full TypeScript/Vite build remains unverified because this working archive has no installed `node_modules` and dependency installation previously timed out.

## Phase 1 completion hardening — 2026-09-20
- Removed duplicate DataContext import in `App.tsx` that could block TypeScript compilation.
- Save & Next uses the user's local calendar date rather than UTC for today's queue.
- Dashboard's Today's Calls queue is now truly date-scoped and renders the complete list rather than an arbitrary six-item slice.
- Removed hard-coded call-count fallback.
- Removed invalid `FollowUp.channel` references and uses the canonical `FollowUp.type`.
- Continued removal of legacy amber/gold dashboard accents in favor of the locked blue/violet semantic palette.

## Phase 1 exit checklist
- [x] Core dashboard/client/project/follow-up foundation
- [x] Hot/Warm/Cold rule-based lead radar
- [x] Native call bridge entry point
- [x] Post-call call log + duration
- [x] Post-call next action + follow-up date choices
- [x] Save & Next queue progression
- [x] Today's queue uses local calendar date
- [x] Today's queue renders the complete list
- [x] Notification permission + 2-minute/due alert engine
- [x] Local persistence for clients, follow-ups and communication logs
- [x] No AI integration
- [ ] Full dependency-backed build verification (environment limitation: install timed out)

## Native Android shell — 2026-09-20
- Added `android/` native shell skeleton for direct cellular calling.
- Added default-dialer role request and `InCallService` disconnect event bridge.
- APK compilation/device verification remains pending until Android SDK/Gradle dependencies are available.
