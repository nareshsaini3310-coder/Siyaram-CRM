const fs = require('fs');
let content = fs.readFileSync('src/views/ClientDetailView.tsx', 'utf8');

// 1. Get the last activity
const lastActivityCode = `              {/* Last Interaction Block */}
              {unifiedActivityLogs.length > 0 && (
                <div className="mt-3 inline-flex flex-col sm:flex-row sm:items-center gap-2 p-2.5 rounded-xl bg-stone-500/10 border border-stone-500/20 text-xs text-stone-300">
                  <div className="flex items-center gap-1.5 shrink-0">
                    <div className="w-6 h-6 rounded-full bg-stone-500/20 flex items-center justify-center shrink-0">
                      {unifiedActivityLogs[0].type === 'recording' ? (
                        <Mic className="w-3.5 h-3.5 text-blue-400" />
                      ) : unifiedActivityLogs[0].type === 'comm' && unifiedActivityLogs[0].data.channel === 'whatsapp' ? (
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                      ) : unifiedActivityLogs[0].type === 'comm' && unifiedActivityLogs[0].data.channel === 'call' ? (
                        <Phone className="w-3.5 h-3.5 text-amber-400" />
                      ) : (
                        <FileText className="w-3.5 h-3.5 text-stone-400" />
                      )}
                    </div>
                    <span className="font-bold text-[10px] font-mono uppercase tracking-wider text-stone-400">Last Interaction:</span>
                  </div>
                  <span className="truncate max-w-sm font-sans font-medium">
                    {unifiedActivityLogs[0].type === 'recording' 
                      ? (unifiedActivityLogs[0].data.title || 'Voice Note Recorded')
                      : (unifiedActivityLogs[0].data.notes || \`\${unifiedActivityLogs[0].data.direction === 'outgoing' ? 'Sent' : 'Received'} \${unifiedActivityLogs[0].data.channel} message\`)}
                  </span>
                  <span className="text-[10px] text-stone-500 shrink-0 font-mono ml-auto">
                    {new Date(unifiedActivityLogs[0].timestamp).toLocaleDateString()}
                  </span>
                </div>
              )}`;

const nextFollowupTarget = `              )}
            </div>
          </div>

          {/* Quick Communication Hub Box */}`;

content = content.replace(nextFollowupTarget, `              )}\n${lastActivityCode}\n            </div>\n          </div>\n\n          {/* Quick Communication Hub Box */}`);

// 2. Add Voice Recording button to inline Call Logger
const textFormTarget = `                  <button type="button" onClick={() => setIsLoggingCall(false)} className="text-stone-400 hover:text-white">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <textarea`;

const textFormReplacement = `                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsLoggingCall(false);
                        onOpenVoiceRecorder(client.id);
                      }}
                      className="text-[10px] font-mono uppercase font-bold text-blue-400 hover:bg-blue-500/20 px-2 py-1 rounded bg-blue-500/10 flex items-center gap-1"
                    >
                      <Mic className="w-3 h-3" /> Record Audio
                    </button>
                    <button type="button" onClick={() => setIsLoggingCall(false)} className="text-stone-400 hover:text-white ml-1">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <textarea`;

content = content.replace(textFormTarget, textFormReplacement);

fs.writeFileSync('src/views/ClientDetailView.tsx', content);
