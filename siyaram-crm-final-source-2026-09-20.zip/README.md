# Siyaram CRM

This contains everything you need to run your app locally.


## Run Locally

**Prerequisites:** Node.js 20+

1. Install dependencies: `npm install`
2. Run the app: `npm run dev`
3. Production build: `npm run build`

## Latest development pass
- Added rule-based Lead Radar and current-date overdue calculation.
- Routed Dashboard direct calls through `src/utils/nativeBridge.ts`.
- Continued migration to the locked Siyaram blue/violet liquid-glass palette.
- No AI integration.


## Product constraints
- Personal-use real-estate CRM.
- Rule-based workflows only; no AI integration is required or embedded.
- Client import supports deterministic Excel/CSV column mapping and duplicate-phone protection.
- Phone numbers are normalized to 10-digit values for imported leads.
