const fs = require('fs');
const content = fs.readFileSync('src/views/ClientDetailView.tsx', 'utf8');

let newContent = content.replace(
  "const [commChannelFilter, setCommChannelFilter] = useState<'all' | CommChannel>('all');",
  "const [activityFilter, setActivityFilter] = useState<'all' | 'call' | 'note' | 'recording' | 'whatsapp' | 'sms'>('all');"
);

fs.writeFileSync('src/views/ClientDetailView.tsx', newContent);
