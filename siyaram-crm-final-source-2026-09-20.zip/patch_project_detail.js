const fs = require('fs');
let content = fs.readFileSync('src/views/ProjectDetailView.tsx', 'utf8');

// Import ConfirmDialog
content = content.replace(
  "import { QuickCommModal } from '../components/QuickCommModal';",
  "import { QuickCommModal } from '../components/QuickCommModal';\nimport { ConfirmDialog } from '../components/ConfirmDialog';"
);

// Add state for modal
content = content.replace(
  "const [isCommModalOpen, setIsCommModalOpen] = useState(false);",
  "const [isCommModalOpen, setIsCommModalOpen] = useState(false);\n  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);"
);

// Update delete button
content = content.replace(
  /onClick=\{\(\) => \{\s*if \(confirm\('Archive and remove this project from active registry\?'\)\) \{\s*deleteProject\(project\.id\);\s*onBack\(\);\s*\}\s*\}\}/g,
  "onClick={() => setIsDeleteConfirmOpen(true)}"
);

// Add ConfirmDialog modal
const modalsRegex = /\{\/\* Modals \*\/\}/;
const confirmModal = `{/* Modals */}
      <ConfirmDialog
        isOpen={isDeleteConfirmOpen}
        onClose={() => setIsDeleteConfirmOpen(false)}
        onConfirm={() => {
          deleteProject(project.id);
          onBack();
        }}
        title="Delete Project"
        message="Are you sure you want to delete this project? This action cannot be undone and will permanently remove this project from the active registry."
        confirmText="Delete Project"
        isDestructive={true}
      />`;
content = content.replace(modalsRegex, confirmModal);

fs.writeFileSync('src/views/ProjectDetailView.tsx', content);
