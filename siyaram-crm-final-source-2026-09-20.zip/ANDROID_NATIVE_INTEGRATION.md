# Siyaram Android Native Integration

## Current state
The React/PWA layer now routes all cellular call launches through `src/utils/nativeBridge.ts`. In a browser/PWA this uses the Android `tel:` intent.

## Native shell requirements
A production default-dialer build still needs an Android shell implementing `RoleManager.ROLE_DIALER`, `TelecomManager`, `InCallService`, and call-state callbacks. The shell should send call lifecycle events back to the web layer so Siyaram can open the post-call sheet with real duration/status.

## Post-call UX
The current web layer detects return/focus after a `tel:` intent and opens the existing call-log sheet. This is a fallback; the native shell should replace it with authoritative call-state events.

## Notification workflow
Browser/PWA notifications are already handled by the service worker. Native Android should mirror the same event contract: morning agenda, T-2 minute, due/overdue, old lead, site visit, and deep-link actions.
