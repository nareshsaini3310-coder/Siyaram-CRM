import React, { createContext, useContext, useState, useEffect } from 'react';
import { Project, Client, FollowUp, Tag, VoiceRecording, CommLog } from '../types';
import {
  INITIAL_PROJECTS,
  INITIAL_CLIENTS,
  INITIAL_FOLLOWUPS,
  INITIAL_TAGS,
  INITIAL_RECORDINGS,
  INITIAL_COMM_LOGS,
} from '../data/mockData';
import { deleteAudioBlob } from '../utils/audioStorage';

interface DataContextType {
  projects: Project[];
  clients: Client[];
  followUps: FollowUp[];
  tags: Tag[];
  recordings: VoiceRecording[];
  commLogs: CommLog[];
  syncStatus: 'synced' | 'syncing' | 'offline';
  triggerSync: () => void;
  isOfflineMode: boolean;
  toggleOfflineMode: () => void;
  syncConflict: { itemType: string; localPreview: string; serverPreview: string } | null;
  resolveConflict: (choice: 'local' | 'server') => void;
  simulateSyncConflict: () => void;
  
  // Project operations
  addProject: (project: Omit<Project, 'id' | 'code' | 'spent' | 'voiceRecordingIds'>) => Project;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;
  getProjectById: (id: string) => Project | undefined;
  
  // Client operations
  addClient: (client: Omit<Client, 'id' | 'voiceRecordingIds'>) => Client;
  importClients: (clients: (Omit<Client, 'id' | 'voiceRecordingIds'> & { existingClientId?: string })[]) => { created: number; updated: number; duplicates: number; skipped: number };
  updateClient: (id: string, updates: Partial<Client>) => void;
  deleteClient: (id: string) => void;
  getClientById: (id: string) => Client | undefined;
  
  // FollowUp operations
  addFollowUp: (followUp: Omit<FollowUp, 'id' | 'status'>) => FollowUp;
  toggleFollowUpStatus: (id: string) => void;
  updateFollowUp: (id: string, updates: Partial<FollowUp>) => void;
  deleteFollowUp: (id: string) => void;
  
  // Tag operations
  addTag: (tag: Omit<Tag, 'id' | 'createdAt'>) => Tag;
  updateTag: (id: string, updates: Partial<Tag>) => void;
  deleteTag: (id: string) => void;
  getTagById: (id: string) => Tag | undefined;
  
  // Recording operations
  addRecording: (recording: Omit<VoiceRecording, 'id' | 'createdAt'>) => VoiceRecording;
  deleteRecording: (id: string) => void;

  // Communication / Call Log operations (Call, WhatsApp, SMS)
  addCommLog: (log: Omit<CommLog, 'id' | 'timestamp'> & { timestamp?: string }) => CommLog;
  updateCommLog: (id: string, updates: Partial<CommLog>) => void;
  deleteCommLog: (id: string) => void;
  clearClientActivityLogs: (clientId: string) => void;
  
  // Data Lock & Portability Operations
  exportDataBackup: () => void;
  importDataBackup: (jsonString: string) => boolean;
  resetToMasterData: () => void;

  // Utility counts
  stats: {
    activeProjectsCount: number;
    totalClientsCount: number;
    pendingFollowUpsCount: number;
    urgentFollowUpsCount: number;
    dueOrOverdueFollowUpsCount: number;
    totalActiveBudget: number;
    totalRecordingsCount: number;
    totalCommLogsCount: number;
  };
}

const DataContext = createContext<DataContextType | undefined>(undefined);

const PROJECTS_KEY = 'atelier_crm_projects_v2';
const CLIENTS_KEY = 'atelier_crm_clients_v2';
const FOLLOWUPS_KEY = 'atelier_crm_followups_v2';
const TAGS_KEY = 'atelier_crm_tags_v2';
const RECORDINGS_KEY = 'atelier_crm_recordings_v2';
const COMMLOGS_KEY = 'atelier_crm_commlogs_v2';

const readStoredList = <T,>(key: string, fallback: T[]): T[] => {
  try {
    const saved = localStorage.getItem(key);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed as T[];
    }
  } catch {
    // Ignore malformed persisted data and fall back to master fixture data.
  }
  return fallback;
};

const writeStoredList = <T,>(key: string, value: T[]) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore quota / storage errors in restricted browser contexts.
  }
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [syncStatus, setSyncStatus] = useState<'synced' | 'syncing' | 'offline'>('synced');
  const [isOfflineMode, setIsOfflineMode] = useState(false);

  const toggleOfflineMode = () => {
    setIsOfflineMode(prev => !prev);
  };
  useEffect(() => {
    const handleOnline = () => setSyncStatus('synced');
    const handleOffline = () => setSyncStatus('offline');
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    if (!navigator.onLine) setSyncStatus('offline');
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const simulateSync = () => {
    if (!navigator.onLine) return;
    setSyncStatus('syncing');
    setTimeout(() => setSyncStatus('synced'), 800 + Math.random() * 1000);
  };

  
  const [syncConflict, setSyncConflict] = useState<{ itemType: string; localPreview: string; serverPreview: string } | null>(null);

  const resolveConflict = (choice: 'local' | 'server') => {
    // In a real app, apply the choice to local state or push to server
    setSyncConflict(null);
    setSyncStatus('synced');
  };

  const simulateSyncConflict = () => {
    setSyncStatus('syncing');
    setTimeout(() => {
      setSyncStatus('offline'); // Just to pause the sync visually
      setSyncConflict({
        itemType: 'Project (Siyaram)',
        localPreview: 'Budget: €450,000\nStatus: Active',
        serverPreview: 'Budget: €420,000\nStatus: In Review'
      });
    }, 600);
  };

  const [projects, setProjects] = useState<Project[]>(() => {
    return readStoredList<Project>(PROJECTS_KEY, INITIAL_PROJECTS);
  });

  const [clients, setClients] = useState<Client[]>(() => {
    return readStoredList<Client>(CLIENTS_KEY, INITIAL_CLIENTS);
  });

  const [followUps, setFollowUps] = useState<FollowUp[]>(() => {
    return readStoredList<FollowUp>(FOLLOWUPS_KEY, INITIAL_FOLLOWUPS);
  });

  const [tags, setTags] = useState<Tag[]>(() => {
    return readStoredList<Tag>(TAGS_KEY, INITIAL_TAGS);
  });

  const [recordings, setRecordings] = useState<VoiceRecording[]>(() => {
    return readStoredList<VoiceRecording>(RECORDINGS_KEY, INITIAL_RECORDINGS);
  });

  const [commLogs, setCommLogs] = useState<CommLog[]>(() => {
    return readStoredList<CommLog>(COMMLOGS_KEY, INITIAL_COMM_LOGS);
  });

  // Local storage persistence
  useEffect(() => {
    writeStoredList(PROJECTS_KEY, projects);
  }, [projects]);

  useEffect(() => {
    writeStoredList(CLIENTS_KEY, clients);
  }, [clients]);

  useEffect(() => {
    writeStoredList(FOLLOWUPS_KEY, followUps);
  }, [followUps]);

  useEffect(() => {
    writeStoredList(TAGS_KEY, tags);
  }, [tags]);

  useEffect(() => {
    writeStoredList(RECORDINGS_KEY, recordings);
  }, [recordings]);

  useEffect(() => {
    writeStoredList(COMMLOGS_KEY, commLogs);
  }, [commLogs]);

  // Project methods
  const addProject = (data: Omit<Project, 'id' | 'code' | 'spent' | 'voiceRecordingIds'>): Project => {
    const nextCodeNum = projects.length + 101;
    const newProject: Project = {
      ...data,
      id: `prj-${Date.now()}`,
      code: `PRJ-${nextCodeNum}`,
      spent: 0,
      voiceRecordingIds: [],
    };
    setProjects((prev) => [newProject, ...prev]);

    // Also link this project to each selected client's projectIds
    if (data.clientIds && data.clientIds.length > 0) {
      setClients((prev) =>
        prev.map((c) =>
          data.clientIds.includes(c.id) && !c.projectIds.includes(newProject.id)
            ? { ...c, projectIds: [...c.projectIds, newProject.id] }
            : c
        )
      );
    }

    return newProject;
  };

  const updateProject = (id: string, updates: Partial<Project>) => {
    setProjects((prev) => {
      const current = prev.find((p) => p.id === id);
      if (!current) return prev;
      const next = { ...current, ...updates };
      if (updates.clientIds) {
        setClients((clientPrev) => clientPrev.map((c) => {
          const shouldLink = updates.clientIds!.includes(c.id);
          const wasLinked = current.clientIds.includes(c.id);
          if (shouldLink === wasLinked) return c;
          return { ...c, projectIds: shouldLink ? [...new Set([...c.projectIds, id])] : c.projectIds.filter((pid) => pid !== id) };
        }));
      }
      return prev.map((p) => (p.id === id ? next : p));
    });
  };

  const deleteProject = (id: string) => {
    const projectRecordingIds = recordings.filter((recording) => recording.projectId === id).map((recording) => recording.id);
    setProjects((prev) => prev.filter((p) => p.id !== id));
    setClients((prev) => prev.map((c) => ({ ...c, projectIds: c.projectIds.filter((pid) => pid !== id) })));
    setRecordings((prev) => prev.filter((recording) => recording.projectId !== id));
    if (projectRecordingIds.length > 0) {
      setClients((prev) => prev.map((client) => ({
        ...client,
        voiceRecordingIds: client.voiceRecordingIds.filter((recordingId) => !projectRecordingIds.includes(recordingId)),
      })));
    }
    setFollowUps((prev) => prev.map((followUp) => followUp.projectId === id ? { ...followUp, projectId: undefined } : followUp));
    setCommLogs((prev) => prev.map((log) => log.projectId === id ? { ...log, projectId: undefined } : log));
  };

  const getProjectById = (id: string) => projects.find((p) => p.id === id);

  // Client methods
  const addClient = (data: Omit<Client, 'id' | 'voiceRecordingIds'>): Client => {
    const newClient: Client = {
      ...data,
      id: `cli-${Date.now()}`,
      voiceRecordingIds: [],
    };
    setClients((prev) => [newClient, ...prev]);

    // If client was linked to projects, update those projects
    if (data.projectIds && data.projectIds.length > 0) {
      setProjects((prev) =>
        prev.map((p) =>
          data.projectIds.includes(p.id) && !p.clientIds.includes(newClient.id)
            ? { ...p, clientIds: [...p.clientIds, newClient.id] }
            : p
        )
      );
    }

    return newClient;
  };

  const importClients = (incoming: (Omit<Client, 'id' | 'voiceRecordingIds'> & { existingClientId?: string })[]) => {
    const existingPhones = new Set(clients.map((c) => (c.phone || '').replace(/\D/g, '').slice(-10)).filter((value) => value.length === 10));
    const batchPhones = new Set<string>();
    const additions: Client[] = [];
    const updates: Array<{ id: string; data: Partial<Client> }> = [];
    let updated = 0;
    let duplicates = 0;
    let skipped = 0;
    for (const item of incoming) {
      const phone = (item.phone || '').replace(/\D/g, '');
      const normalizedPhone = phone.length === 10 ? phone : phone.length === 11 && phone.startsWith('0') ? phone.slice(1) : phone.length === 12 && phone.startsWith('91') ? phone.slice(2) : phone.slice(-10);
      if (!normalizedPhone || normalizedPhone.length !== 10) { skipped += 1; continue; }
      if (batchPhones.has(normalizedPhone)) { duplicates += 1; continue; }
      batchPhones.add(normalizedPhone);
      const existingClient = item.existingClientId ? clients.find((client) => client.id === item.existingClientId) : clients.find((client) => (client.phone || '').replace(/\D/g, '').slice(-10) === normalizedPhone);
      if (existingClient) {
        const { existingClientId: _existingClientId, ...clientData } = item;
        const nonEmptyData = Object.fromEntries(
          Object.entries(clientData).filter(([, value]) => value !== undefined && value !== null && (typeof value !== 'string' || value.trim() !== ''))
        );
        updates.push({ id: existingClient.id, data: { ...nonEmptyData, phone: normalizedPhone } });
        updated += 1;
      } else {
        const { existingClientId: _existingClientId, ...clientData } = item;
        additions.push({ ...clientData, id: `cli-${Date.now()}-${additions.length}-${Math.random().toString(36).slice(2, 7)}`, phone: normalizedPhone, voiceRecordingIds: [] });
      }
    }
    if (additions.length) setClients((prev) => [...additions, ...prev]);
    if (updates.length) {
      setClients((prev) => prev.map((client) => {
        const update = updates.find((candidate) => candidate.id === client.id);
        return update ? { ...client, ...update.data, projectIds: [...new Set([...(client.projectIds || []), ...(update.data.projectIds || [])])] } : client;
      }));
      setProjects((prev) => prev.map((project) => {
        const linkedIds = updates.filter((update) => update.data.projectIds?.includes(project.id)).map((update) => update.id);
        return linkedIds.length ? { ...project, clientIds: [...new Set([...project.clientIds, ...linkedIds])] } : project;
      }));
    }
    if (additions.length) {
      setProjects((prev) => prev.map((project) => {
        const linkedIds = additions.filter((client) => client.projectIds.includes(project.id)).map((client) => client.id);
        return linkedIds.length ? { ...project, clientIds: [...new Set([...project.clientIds, ...linkedIds])] } : project;
      }));
    }
    const importedFollowUps = incoming
      .filter((item) => item.nextFollowUpDate)
      .map((item, index) => ({
        id: `fol-import-${Date.now()}-${index}`,
        title: `Imported follow-up${item.name ? `: ${item.name}` : ''}`,
        clientId: item.existingClientId || additions.find((client) => client.phone === item.phone)?.id,
        type: item.nextFollowUpType || 'call',
        priority: 'medium' as const,
        dueDate: item.nextFollowUpDate!,
        notes: item.notes || 'Imported follow-up',
        status: 'pending' as const,
      }))
      .filter((followUp) => Boolean(followUp.clientId));
    if (importedFollowUps.length) setFollowUps((prev) => [...importedFollowUps, ...prev]);
    return { created: additions.length, updated, duplicates, skipped };
  };

  const updateClient = (id: string, updates: Partial<Client>) => {
    setClients((prev) => {
      const current = prev.find((c) => c.id === id);
      if (!current) return prev;
      if (updates.projectIds) {
        const nextIds = updates.projectIds;
        setProjects((projectPrev) => projectPrev.map((p) => {
          const shouldLink = nextIds.includes(p.id);
          const wasLinked = current.projectIds.includes(p.id);
          if (shouldLink === wasLinked) return p;
          return { ...p, clientIds: shouldLink ? [...new Set([...p.clientIds, id])] : p.clientIds.filter((cid) => cid !== id) };
        }));
      }
      return prev.map((c) => (c.id === id ? { ...c, ...updates } : c));
    });
  };

  const deleteClient = (id: string) => {
    const clientRecordingIds = recordings.filter((recording) => recording.clientId === id).map((recording) => recording.id);
    setClients((prev) => prev.filter((c) => c.id !== id));
    setProjects((prev) => prev.map((p) => ({ ...p, clientIds: p.clientIds.filter((cid) => cid !== id) })));
    setFollowUps((prev) => prev.filter((followUp) => followUp.clientId !== id));
    setCommLogs((prev) => prev.filter((log) => log.clientId !== id));
    setRecordings((prev) => prev.filter((recording) => recording.clientId !== id));
    if (clientRecordingIds.length > 0) {
      setProjects((prev) => prev.map((project) => ({
        ...project,
        voiceRecordingIds: project.voiceRecordingIds.filter((recordingId) => !clientRecordingIds.includes(recordingId)),
      })));
    }
  };

  const getClientById = (id: string) => clients.find((c) => c.id === id);

  // FollowUp methods
  const addFollowUp = (data: Omit<FollowUp, 'id' | 'status'>): FollowUp => {
    const newFollowUp: FollowUp = {
      ...data,
      id: `fol-${Date.now()}`,
      status: 'pending',
    };
    setFollowUps((prev) => [newFollowUp, ...prev]);
    return newFollowUp;
  };

  const toggleFollowUpStatus = (id: string) => {
    setFollowUps((prev) =>
      prev.map((f) => {
        if (f.id === id) {
          const isPending = f.status === 'pending';
          return {
            ...f,
            status: isPending ? 'completed' : 'pending',
            completedAt: isPending ? new Date().toISOString() : undefined,
          };
        }
        return f;
      })
    );
  };

  const updateFollowUp = (id: string, updates: Partial<FollowUp>) => {
    setFollowUps((prev) => prev.map((f) => (f.id === id ? { ...f, ...updates } : f)));
  };

  const deleteFollowUp = (id: string) => {
    setFollowUps((prev) => prev.filter((f) => f.id !== id));
  };

  // Tag methods
  const addTag = (data: Omit<Tag, 'id' | 'createdAt'>): Tag => {
    const newTag: Tag = {
      ...data,
      id: `tag-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setTags((prev) => [...prev, newTag]);
    return newTag;
  };

  const updateTag = (id: string, updates: Partial<Tag>) => {
    setTags((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));
  };

  const deleteTag = (id: string) => {
    setTags((prev) => prev.filter((t) => t.id !== id));
    // Remove tag reference from projects and clients
    setProjects((prev) =>
      prev.map((p) => ({ ...p, tagIds: p.tagIds.filter((tId) => tId !== id) }))
    );
    setClients((prev) =>
      prev.map((c) => ({ ...c, tagIds: c.tagIds.filter((tId) => tId !== id) }))
    );
  };

  const getTagById = (id: string) => tags.find((t) => t.id === id);

  // Recording methods
  const addRecording = (data: Omit<VoiceRecording, 'id' | 'createdAt'>): VoiceRecording => {
    const newRecording: VoiceRecording = {
      ...data,
      id: `rec-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setRecordings((prev) => [newRecording, ...prev]);

    // Attach to client if selected
    if (data.clientId) {
      setClients((prev) =>
        prev.map((c) =>
          c.id === data.clientId
            ? { ...c, voiceRecordingIds: [...c.voiceRecordingIds, newRecording.id] }
            : c
        )
      );
    }

    // Attach to project if selected
    if (data.projectId) {
      setProjects((prev) =>
        prev.map((p) =>
          p.id === data.projectId
            ? { ...p, voiceRecordingIds: [...p.voiceRecordingIds, newRecording.id] }
            : p
        )
      );
    }

    return newRecording;
  };

  const deleteRecording = (id: string) => {
    const recording = recordings.find((item) => item.id === id);
    setRecordings((prev) => prev.filter((r) => r.id !== id));
    if (recording?.audioBlobId) deleteAudioBlob(recording.audioBlobId).catch(() => {});
    setClients((prev) => prev.map((c) => ({
      ...c,
      voiceRecordingIds: c.voiceRecordingIds.filter((rid) => rid !== id),
    })));
    setProjects((prev) => prev.map((p) => ({
      ...p,
      voiceRecordingIds: p.voiceRecordingIds.filter((rid) => rid !== id),
    })));
  };

  // CommLog methods
  const addCommLog = (data: Omit<CommLog, 'id' | 'timestamp'> & { timestamp?: string }): CommLog => {
    const newLog: CommLog = {
      ...data,
      id: `log-${Date.now()}`,
      timestamp: data.timestamp || new Date().toISOString(),
    };
    setCommLogs((prev) => [newLog, ...prev]);

    // Update client lastContactDate
    if (data.clientId) {
      setClients((prev) =>
        prev.map((c) =>
          c.id === data.clientId
            ? { ...c, lastContactDate: new Date().toISOString().split('T')[0] }
            : c
        )
      );
    }

    return newLog;
  };

  const updateCommLog = (id: string, updates: Partial<CommLog>) => {
    setCommLogs((prev) => prev.map((l) => (l.id === id ? { ...l, ...updates } : l)));
  };

  const clearClientActivityLogs = (clientId: string) => {
    const recordingIds = recordings.filter((rec) => rec.clientId === clientId).map((rec) => rec.id);
    setCommLogs(prev => prev.filter(log => log.clientId !== clientId));
    setRecordings(prev => prev.filter(rec => rec.clientId !== clientId));
    if (recordingIds.length > 0) {
      setClients(prev => prev.map(c => c.id === clientId
        ? { ...c, voiceRecordingIds: c.voiceRecordingIds.filter(id => !recordingIds.includes(id)) }
        : c
      ));
    }
  };

  const deleteCommLog = (id: string) => {
    setCommLogs((prev) => prev.filter((l) => l.id !== id));
  };

  // Data Lock & Backup Handlers
  const exportDataBackup = () => {
    try {
      const backupPayload = {
        version: '1.5.0',
        exportedAt: new Date().toISOString(),
        brand: 'Siyaram CRM Estate Management',
        data: {
          projects,
          clients,
          followUps,
          tags,
          recordings,
          commLogs,
        },
      };
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupPayload, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', `Siyaram-CRM-Backup-${new Date().toISOString().split('T')[0]}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    } catch (err) {
      console.error('Backup export failed:', err);
    }
  };

  const importDataBackup = (jsonString: string): boolean => {
    try {
      const parsed = JSON.parse(jsonString);
      const target = parsed.data || parsed;
      if (target.projects && Array.isArray(target.projects)) setProjects(target.projects);
      if (target.clients && Array.isArray(target.clients)) setClients(target.clients);
      if (target.followUps && Array.isArray(target.followUps)) setFollowUps(target.followUps);
      if (target.tags && Array.isArray(target.tags)) setTags(target.tags);
      if (target.recordings && Array.isArray(target.recordings)) setRecordings(target.recordings);
      if (target.commLogs && Array.isArray(target.commLogs)) setCommLogs(target.commLogs);
      return true;
    } catch (err) {
      console.error('Failed to parse backup JSON:', err);
      return false;
    }
  };

  const resetToMasterData = () => {
    setProjects(INITIAL_PROJECTS);
    setClients(INITIAL_CLIENTS);
    setFollowUps(INITIAL_FOLLOWUPS);
    setTags(INITIAL_TAGS);
    setRecordings(INITIAL_RECORDINGS);
    setCommLogs(INITIAL_COMM_LOGS);
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(INITIAL_PROJECTS));
    localStorage.setItem(CLIENTS_KEY, JSON.stringify(INITIAL_CLIENTS));
    localStorage.setItem(FOLLOWUPS_KEY, JSON.stringify(INITIAL_FOLLOWUPS));
    localStorage.setItem(TAGS_KEY, JSON.stringify(INITIAL_TAGS));
    localStorage.setItem(RECORDINGS_KEY, JSON.stringify(INITIAL_RECORDINGS));
    localStorage.setItem(COMMLOGS_KEY, JSON.stringify(INITIAL_COMM_LOGS));
  };

  // Stats calculation
  const stats = React.useMemo(() => {
    const activeProjects = projects.filter((p) => p.status === 'active' || p.status === 'in_review');
    const pendingFollowUps = followUps.filter((f) => f.status === 'pending');
    const urgentFollowUps = pendingFollowUps.filter((f) => f.priority === 'high');
    const todayStr = new Date().toISOString().split('T')[0];
    const dueOrOverdueFollowUpsCount = pendingFollowUps.filter((f) => f.dueDate <= todayStr).length;
    const totalActiveBudget = projects
      .filter((p) => p.status === 'active')
      .reduce((sum, p) => sum + p.budget, 0);

    return {
      activeProjectsCount: activeProjects.length,
      totalClientsCount: clients.length,
      pendingFollowUpsCount: pendingFollowUps.length,
      urgentFollowUpsCount: urgentFollowUps.length,
      dueOrOverdueFollowUpsCount,
      totalActiveBudget,
      totalRecordingsCount: recordings.length,
      totalCommLogsCount: commLogs.length,
    };
  }, [projects, clients.length, followUps, recordings.length, commLogs.length]);

  return (
    <DataContext.Provider
      value={{
        syncStatus: isOfflineMode ? 'offline' : syncStatus,
        isOfflineMode,
        toggleOfflineMode,
        triggerSync: simulateSync,
        syncConflict,
        resolveConflict,
        simulateSyncConflict,
        projects,
        clients,
        followUps,
        tags,
        recordings,
        commLogs,
        addProject,
        updateProject,
        deleteProject,
        getProjectById,
        addClient,
        importClients,
        updateClient,
        deleteClient,
        getClientById,
        addFollowUp,
        toggleFollowUpStatus,
        updateFollowUp,
        deleteFollowUp,
        addTag,
        updateTag,
        deleteTag,
        getTagById,
        addRecording,
        deleteRecording,
        addCommLog,
        updateCommLog,
        deleteCommLog,
        clearClientActivityLogs,
        exportDataBackup,
        importDataBackup,
        resetToMasterData,
        stats,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
