import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { ThemeMode, AccentColor, ThemePreference } from '../types';

interface ThemeContextType {
  theme: ThemeMode;
  preference: ThemePreference;
  isAutoTheme: boolean;
  systemTheme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  setPreference: (preference: ThemePreference) => void;
  setAutoTheme: (enabled: boolean) => void;
  accent: AccentColor;
  setAccent: (accent: AccentColor) => void;
  toggleTheme: () => void;
  // Dynamic color helper classes
  tokens: {
    bg: string;
    bgSubtle: string;
    surface: string;
    surfaceHover: string;
    surfaceElevated: string;
    border: string;
    borderSubtle: string;
    textPrimary: string;
    textSecondary: string;
    textMuted: string;
    accentWarmBeige: string;
    accentColor: string;
    accentBgTint: string;
    accentBorder: string;
    accentText: string;
    accentBtn: string;
  };
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const THEME_STORAGE_KEY = 'atelier_theme_mode';
const THEME_AUTO_STORAGE_KEY = 'atelier_theme_auto';
const ACCENT_STORAGE_KEY = 'atelier_accent_color';

const getSystemTheme = (): ThemeMode => {
  if (typeof window === 'undefined') return 'dark';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'dawn';
};

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAutoTheme, setIsAutoThemeState] = useState<boolean>(() => {
    const savedAuto = localStorage.getItem(THEME_AUTO_STORAGE_KEY);
    if (savedAuto !== null) {
      return savedAuto === 'true';
    }
    // Default to locked manual theme (false) so project appearance never randomly flips on fresh import
    return false;
  });

  const [systemTheme, setSystemTheme] = useState<ThemeMode>(() => getSystemTheme());

  const [theme, setThemeState] = useState<ThemeMode>(() => {
    const savedTheme = localStorage.getItem(THEME_STORAGE_KEY);
    if (savedTheme === 'dawn' || savedTheme === 'dark') return savedTheme;
    // Default locked theme is dark (Siyaram Executive Dark)
    return 'dark';
  });

  const [accent, setAccentState] = useState<AccentColor>(() => {
    const saved = localStorage.getItem(ACCENT_STORAGE_KEY);
    return saved === 'sage' ? 'sage' : 'ocean'; // Siyaram Ocean is the locked default brand accent
  });

  // Listen to browser's matchMedia('(prefers-color-scheme: dark)') in real time
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const handleSystemThemeChange = (e: MediaQueryListEvent | MediaQueryList) => {
      const detected: ThemeMode = e.matches ? 'dark' : 'dawn';
      setSystemTheme(detected);
      if (isAutoTheme) {
        setThemeState(detected);
      }
    };

    // Ensure state matches current media query immediately
    const currentDetected: ThemeMode = mediaQuery.matches ? 'dark' : 'dawn';
    setSystemTheme(currentDetected);
    if (isAutoTheme) {
      setThemeState(currentDetected);
    }

    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', handleSystemThemeChange);
      return () => mediaQuery.removeEventListener('change', handleSystemThemeChange);
    } else if ((mediaQuery as any).addListener) {
      (mediaQuery as any).addListener(handleSystemThemeChange);
      return () => (mediaQuery as any).removeListener(handleSystemThemeChange);
    }
  }, [isAutoTheme]);

  const setAutoTheme = useCallback((enabled: boolean) => {
    setIsAutoThemeState(enabled);
    localStorage.setItem(THEME_AUTO_STORAGE_KEY, enabled ? 'true' : 'false');
    if (enabled) {
      const currentSysTheme = getSystemTheme();
      setThemeState(currentSysTheme);
    }
  }, []);

  const setTheme = useCallback((newTheme: ThemeMode) => {
    setIsAutoThemeState(false);
    localStorage.setItem(THEME_AUTO_STORAGE_KEY, 'false');
    setThemeState(newTheme);
    localStorage.setItem(THEME_STORAGE_KEY, newTheme);
  }, []);

  const setPreference = useCallback((pref: ThemePreference) => {
    if (pref === 'system') {
      setAutoTheme(true);
    } else {
      setTheme(pref);
    }
  }, [setAutoTheme, setTheme]);

  const setAccent = (newAccent: AccentColor) => {
    setAccentState(newAccent);
    localStorage.setItem(ACCENT_STORAGE_KEY, newAccent);
  };

  const toggleTheme = () => {
    // Toggling switches to manual mode with opposite theme
    const nextTheme: ThemeMode = theme === 'dark' ? 'dawn' : 'dark';
    setTheme(nextTheme);
  };

  // Keep body classes / styles synced
  useEffect(() => {
    document.documentElement.classList.remove('theme-dark', 'theme-dawn');
    document.documentElement.classList.add(theme === 'dark' ? 'theme-dark' : 'theme-dawn');
    document.body.style.backgroundColor = 'transparent';
    document.body.style.color = theme === 'dark' ? '#F8FAFC' : '#0F172A';
  }, [theme]);

  const preference: ThemePreference = isAutoTheme ? 'system' : theme;

  // Siyaram Design System: single source of truth for brand, glass surfaces and semantic colors.
  // Keep component-level UI dependent on these tokens instead of inventing new colors.
  const isDark = theme === 'dark';
  const isSage = accent === 'sage';
  const brand = isSage
    ? { primary: '#10B981', primaryDark: '#059669', tint: 'rgba(16,185,129,0.18)' }
    : { primary: '#2563EB', primaryDark: '#1D4ED8', tint: 'rgba(37,99,235,0.18)' };

  const tokens = {
    bg: isDark ? 'bg-[#07111F]' : 'bg-[#F5F8FF]',
    bgSubtle: isDark ? 'bg-[#2563EB]/10' : 'bg-[#2563EB]/[0.06]',
    surface: isDark
      ? 'bg-[#0D1B2E]/95 backdrop-blur-[40px] border border-blue-100/[0.12] shadow-[inset_0_1px_1px_rgba(255,255,255,0.08),0_12px_40px_rgba(0,0,0,0.35)]'
      : 'bg-white/[0.68] backdrop-blur-[40px] border border-white/[0.85] shadow-[inset_0_1px_1px_rgba(255,255,255,0.95),0_12px_40px_rgba(15,23,42,0.07)]',
    surfaceHover: isDark
      ? 'hover:bg-[#112640]/95 hover:border-blue-200/[0.20] active:scale-[0.985] transition-all duration-200'
      : 'hover:bg-white/[0.82] hover:border-white active:scale-[0.985] transition-all duration-200',
    surfaceElevated: isDark
      ? 'bg-[#10243D]/98 backdrop-blur-[56px] border border-blue-100/[0.16] shadow-[inset_0_1px_1px_rgba(255,255,255,0.10),0_18px_50px_rgba(0,0,0,0.45)]'
      : 'bg-white/[0.78] backdrop-blur-[56px] border border-white/[0.9] shadow-[inset_0_1px_1px_rgba(255,255,255,1),0_18px_50px_rgba(15,23,42,0.10)]',
    border: isDark ? 'border-white/[0.12]' : 'border-slate-200/70',
    borderSubtle: isDark ? 'border-white/[0.07]' : 'border-slate-200/50',
    textPrimary: isDark ? 'text-[#F5F7FF]' : 'text-[#0F172A]',
    textSecondary: isDark ? 'text-[#B8C4D8]' : 'text-slate-600',
    textMuted: isDark ? 'text-[#8796AD]' : 'text-slate-500',
    accentWarmBeige: isDark ? '#FFFFFF' : '#0F172A',
    accentColor: brand.primary,
    accentBgTint: isDark ? 'bg-blue-500/[0.18]' : 'bg-blue-500/[0.10]',
    accentBorder: isDark ? 'border-blue-400/30' : 'border-blue-500/25',
    accentText: isDark ? 'text-blue-300' : 'text-blue-700',
    accentBtn: isDark
      ? 'bg-blue-500/20 hover:bg-blue-500/30 backdrop-blur-md text-blue-200 border border-blue-400/25 shadow-[inset_0_1px_1px_rgba(255,255,255,0.12),0_6px_18px_rgba(37,99,235,0.20)]'
      : 'bg-blue-500/10 hover:bg-blue-500/15 backdrop-blur-md text-blue-700 border border-blue-500/20 shadow-[inset_0_1px_1px_rgba(255,255,255,0.8),0_6px_18px_rgba(37,99,235,0.12)]',
  };

  return (
    <ThemeContext.Provider
      value={{
        theme,
        preference,
        isAutoTheme,
        systemTheme,
        setTheme,
        setPreference,
        setAutoTheme,
        accent,
        setAccent,
        toggleTheme,
        tokens,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
