
export interface ProjectContact {
  id: string;
  name: string;
  role?: string;
  phone: string;
  whatsapp?: string;
  email?: string;
}

export interface FloorMap {
  id: string;
  title: string;
  fileUrl: string;
  fileType: string;
  uploadedAt: string;
  notes?: string;
  category?: 'floor_map' | 'agreement' | 'brochure' | 'video' | 'other';
}
/**
 * Core types for Atelier Studio CRM
 */

export type ThemeMode = 'dark' | 'dawn';
export type ThemePreference = 'system' | 'dark' | 'dawn';
export type AccentColor = 'sage' | 'ocean';

export type ViewType = 
  | 'dashboard'
  | 'projects'
  | 'project_detail'
  | 'clients'
  | 'client_detail'
  | 'followups'
  | 'tags'
  | 'settings';

export interface Tag {
  id: string;
  name: string;
  color: string; // hex or semantic class
  description?: string;
  createdAt: string;
}

export type ProjectStatus = 'active' | 'in_review' | 'planning' | 'completed';

export type ProjectType = 'plot' | 'high_rises' | 'land' | 'commercial' | 'mixed';

export interface Milestone {
  id: string;
  title: string;
  completed: boolean;
  dueDate: string;
}

export interface Project {
  id: string;
  title: string;
  code: string;
  description: string;
  status: ProjectStatus;
  budget: number;
  spent: number;
  startDate: string;
  targetDate: string;
  clientIds: string[]; // clients linked to this project
  tagIds: string[];
  milestones: Milestone[];
  deliverables: string[];
  voiceRecordingIds: string[];
  floorMaps?: FloorMap[];
  notes?: string;
  // Real Estate / Property Fields
  location?: string;
  projectType?: ProjectType; // plot, high_rises, land, etc.
  plotDetails?: string; // e.g. "150 - 500 Sq. Yd. Plots"
  highRiseDetails?: string; // e.g. "G+32 Luxury Towers"
  landArea?: string; // e.g. "38.5 Acres"
  unitCount?: number;
  keyFeatures?: string[];
  contacts?: ProjectContact[];
}

export type ClientStatus = 'lead' | 'active' | 'vip' | 'past';

export interface Client {
  id: string;
  name: string;
  role: string;
  company: string;
  email: string;
  budget?: string;
  requirement?: string;
  leadSource?: string;
  phone: string;
  whatsappNumber?: string; // Manchaha WhatsApp number for instant open
  avatar: string;
  status: ClientStatus;
  tagIds: string[];
  projectIds: string[];
  lastContactDate: string;
  notes: string;
  voiceRecordingIds: string[];
  preferredContact: 'phone' | 'email' | 'in_person' | 'whatsapp';
  // User requested fields:
  location?: string; // e.g. "Sector 84, Gurugram" or "Delhi NCR"
  leadDate?: string; // YYYY-MM-DD; preserved from deterministic Excel/CSV imports when available
  importReview?: string; // deterministic review flag; never inferred by AI
  nextFollowUpDate?: string; // e.g. "2026-09-18"
  nextFollowUpTime?: string; // e.g. "14:30" or "02:30 PM"
  nextFollowUpType?: FollowUpType; // 'call' | 'whatsapp' | 'meeting' | 'sms'
  nextFollowUpNote?: string;
}

export type FollowUpType = 'call' | 'whatsapp' | 'sms' | 'email' | 'meeting' | 'review';
export type FollowUpPriority = 'high' | 'medium' | 'low';
export type FollowUpStatus = 'pending' | 'completed' | 'snoozed';

export interface FollowUp {
  id: string;
  title: string;
  clientId?: string;
  projectId?: string;
  type: FollowUpType;
  priority: FollowUpPriority;
  dueDate: string;
  scheduledTime?: string; // e.g. "14:30"
  status: FollowUpStatus;
  notes: string;
  completedAt?: string;
  customNumber?: string;
}

export type CommChannel = 'call' | 'whatsapp' | 'sms' | 'note';

export interface CommLog {
  id: string;
  channel: CommChannel; // 'call' | 'whatsapp' | 'sms'
  clientId: string;
  projectId?: string;
  phoneNumber: string;
  whatsappNumber?: string;
  timestamp: string;
  direction?: 'outgoing' | 'incoming';
  notes: string;
  recordingId?: string; // optional linked audio recording
  status: 'completed' | 'missed' | 'scheduled' | 'sent';
  messageBody?: string;
  durationSeconds?: number;
}

export interface VoiceRecording {
  id: string;
  title: string;
  audioBlobUrl?: string;
  durationSeconds: number;
  createdAt: string;
  clientId?: string;
  projectId?: string;
  followUpId?: string;
  summary: string;
  transcription: string;
  actionItems: string[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar: string;
  company: string;
  phone?: string;
}
