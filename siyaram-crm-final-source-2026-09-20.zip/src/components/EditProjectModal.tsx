import React, { useState, useEffect } from 'react';
import {
  X,
  Briefcase,
  MapPin,
  Building,
  Layers,
  DollarSign,
  Calendar,
  CheckCircle2,
  Plus,
  Trash2,
  Check
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { Project, ProjectType, ProjectStatus } from '../types';

interface EditProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
}

export const EditProjectModal: React.FC<EditProjectModalProps> = ({
  isOpen,
  onClose,
  project,
}) => {
  const { theme, tokens } = useTheme();
  const { updateProject } = useData();

  const [title, setTitle] = useState(project.title);
  const [code, setCode] = useState(project.code);
  const [location, setLocation] = useState(project.location || '');
  const [projectType, setProjectType] = useState<ProjectType>(project.projectType || 'high_rises');
  const [plotDetails, setPlotDetails] = useState(project.plotDetails || '');
  const [highRiseDetails, setHighRiseDetails] = useState(project.highRiseDetails || '');
  const [landArea, setLandArea] = useState(project.landArea || '');
  const [unitCount, setUnitCount] = useState(project.unitCount || 0);
  const [status, setStatus] = useState<ProjectStatus>(project.status);
  const [budget, setBudget] = useState(project.budget);
  const [description, setDescription] = useState(project.description);
  const [startDate, setStartDate] = useState(project.startDate);
  const [targetDate, setTargetDate] = useState(project.targetDate);
  const [notes, setNotes] = useState(project.notes || '');
  const [keyFeaturesText, setKeyFeaturesText] = useState((project.keyFeatures || []).join('\n'));
  const [contactsText, setContactsText] = useState((project.contacts || []).map(c => `${c.name} | ${c.role || ''} | ${c.phone} | ${c.whatsapp || ''}`).join('\n'));

  useEffect(() => {
    setTitle(project.title);
    setCode(project.code);
    setLocation(project.location || '');
    setProjectType(project.projectType || 'high_rises');
    setPlotDetails(project.plotDetails || '');
    setHighRiseDetails(project.highRiseDetails || '');
    setLandArea(project.landArea || '');
    setUnitCount(project.unitCount || 0);
    setStatus(project.status);
    setBudget(project.budget);
    setDescription(project.description);
    setStartDate(project.startDate);
    setTargetDate(project.targetDate);
    setNotes(project.notes || '');
    setKeyFeaturesText((project.keyFeatures || []).join('\n'));
    setContactsText((project.contacts || []).map(c => `${c.name} | ${c.role || ''} | ${c.phone} | ${c.whatsapp || ''}`).join('\n'));
  }, [project]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    updateProject(project.id, {
      title: title.trim(),
      code: code.trim(),
      location: location.trim(),
      projectType,
      plotDetails: plotDetails.trim(),
      highRiseDetails: highRiseDetails.trim(),
      landArea: landArea.trim(),
      unitCount: Number(unitCount),
      status,
      budget: Number(budget),
      description: description.trim(),
      startDate,
      targetDate,
      notes: notes.trim(),
      keyFeatures: keyFeaturesText.split('\n').map(v => v.trim()).filter(Boolean),
      contacts: contactsText.split('\n').map((line, i) => { const [name, role, phone, whatsapp] = line.split('|').map(v => v.trim()); return name && phone ? { id: project.contacts?.[i]?.id || `pc-${Date.now()}-${i}`, name, role: role || undefined, phone, whatsapp: whatsapp || undefined } : null; }).filter(Boolean) as any,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-2xl rounded-2xl border shadow-2xl overflow-hidden flex flex-col max-h-[92vh] ${tokens.surface} ${tokens.border}`}
      >
        {/* Header */}
        <div
          className={`px-6 py-4 border-b flex items-center justify-between ${tokens.border} ${tokens.bgSubtle}`}
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <Building className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-xl tracking-tight font-semibold">
                Edit Project & Property Specs
              </h3>
              <p className={`text-[11px] font-mono ${tokens.textSecondary}`}>
                Edit project name (Siyaram), location, plot, high-rises & land details
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-lg ${tokens.textMuted} hover:${tokens.textPrimary} transition-colors`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs">
          {/* Row 1: Project Name & Code */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Project Name (Title)
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Siyaram"
                className={`w-full px-3 py-2 rounded-xl border bg-transparent font-medium text-sm ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
              />
            </div>
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Project Code
              </label>
              <input
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="e.g. SYR-101"
                className={`w-full px-3 py-2 rounded-xl border bg-transparent font-mono text-sm ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
              />
            </div>
          </div>

          {/* Row 2: Location & Primary Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Project Location & Sector
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Sector 84, Express Highway Hub, NCR"
                  className={`w-full pl-8 pr-3 py-2 rounded-xl border bg-transparent text-xs ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
                />
                <MapPin className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-2.5" />
              </div>
            </div>

            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Property Type / Category
              </label>
              <select
                value={projectType}
                onChange={(e) => setProjectType(e.target.value as ProjectType)}
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs font-semibold ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
              >
                <option value="high_rises" className="bg-stone-900 text-stone-100">
                  🏢 High Rises (Luxury Towers / Apartments)
                </option>
                <option value="plot" className="bg-stone-900 text-stone-100">
                  🏡 Plot (Gated Residential & Commercial Plots)
                </option>
                <option value="land" className="bg-stone-900 text-stone-100">
                  🌾 Land (Agricultural, Commercial & Agro-Land)
                </option>
                <option value="commercial" className="bg-stone-900 text-stone-100">
                  🏬 Commercial / Retail High-Street
                </option>
                <option value="mixed" className="bg-stone-900 text-stone-100">
                  🌐 Mixed-Use Integrated Development
                </option>
              </select>
            </div>
          </div>

          {/* Special Property Specifications: Plot, High-Rise, and Land */}
          <div className="p-4 rounded-xl border border-stone-500/20 bg-stone-500/5 space-y-3">
            <h4 className="text-[11px] font-bold uppercase tracking-wider text-amber-500 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5" />
              <span>Real Estate Dimensions & Unit Configurations</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className={`block text-[10px] uppercase font-mono mb-1 ${tokens.textMuted}`}>
                  Plot Details / Sizes
                </label>
                <input
                  type="text"
                  value={plotDetails}
                  onChange={(e) => setPlotDetails(e.target.value)}
                  placeholder="e.g. 150, 250, 500 Sq. Yd. Plots"
                  className={`w-full px-3 py-1.5 rounded-lg border bg-transparent text-xs ${tokens.border}`}
                />
              </div>

              <div>
                <label className={`block text-[10px] uppercase font-mono mb-1 ${tokens.textMuted}`}>
                  High-Rise Towers
                </label>
                <input
                  type="text"
                  value={highRiseDetails}
                  onChange={(e) => setHighRiseDetails(e.target.value)}
                  placeholder="e.g. G+32 Luxury 3/4 BHK Towers"
                  className={`w-full px-3 py-1.5 rounded-lg border bg-transparent text-xs ${tokens.border}`}
                />
              </div>

              <div>
                <label className={`block text-[10px] uppercase font-mono mb-1 ${tokens.textMuted}`}>
                  Total Land Area / Acreage
                </label>
                <input
                  type="text"
                  value={landArea}
                  onChange={(e) => setLandArea(e.target.value)}
                  placeholder="e.g. 38.5 Acres Master-Township"
                  className={`w-full px-3 py-1.5 rounded-lg border bg-transparent text-xs ${tokens.border}`}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div>
                <label className={`block text-[10px] uppercase font-mono mb-1 ${tokens.textMuted}`}>
                  Total Units / Inventories
                </label>
                <input
                  type="number"
                  value={unitCount}
                  onChange={(e) => setUnitCount(Number(e.target.value))}
                  placeholder="e.g. 480"
                  className={`w-full px-3 py-1.5 rounded-lg border bg-transparent text-xs font-mono ${tokens.border}`}
                />
              </div>

              <div>
                <label className={`block text-[10px] uppercase font-mono mb-1 ${tokens.textMuted}`}>
                  Project Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as ProjectStatus)}
                  className={`w-full px-3 py-1.5 rounded-lg border bg-transparent text-xs font-semibold ${tokens.border}`}
                >
                  <option value="active" className="bg-stone-900 text-stone-100">
                    Active Development
                  </option>
                  <option value="in_review" className="bg-stone-900 text-stone-100">
                    In Review / Approvals
                  </option>
                  <option value="planning" className="bg-stone-900 text-stone-100">
                    Planning / Pre-Launch
                  </option>
                  <option value="completed" className="bg-stone-900 text-stone-100">
                    Completed / Handover
                  </option>
                </select>
              </div>

              <div>
                <label className={`block text-[10px] uppercase font-mono mb-1 ${tokens.textMuted}`}>
                  Budget / Valuation (€/₹)
                </label>
                <input
                  type="number"
                  value={budget}
                  onChange={(e) => setBudget(Number(e.target.value))}
                  className={`w-full px-3 py-1.5 rounded-lg border bg-transparent text-xs font-mono ${tokens.border}`}
                />
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
              Project Description & Highlights
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs leading-relaxed ${tokens.border}`}
            />
          </div>

          {/* Timeline Dates */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Launch / Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs font-mono ${tokens.border}`}
              />
            </div>
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Possession / Completion Date
              </label>
              <input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs font-mono ${tokens.border}`}
              />
            </div>
          </div>

          {/* Special notes */}
          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
              Confidential Site & Developer Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Master deed registration in progress. RERA certification active."
              className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs ${tokens.border}`}
            />
          </div>

          {/* Actions */}
          <div className={`pt-4 border-t flex items-center justify-end gap-2.5 ${tokens.border}`}>
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2 rounded-xl border text-xs font-semibold ${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary}`}
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md ${tokens.accentBtn}`}
            >
              <Check className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
