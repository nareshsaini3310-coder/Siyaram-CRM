import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { LucideIcon } from 'lucide-react';

interface EmptyStatePlaceholderProps {
  icon: LucideIcon;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  ActionIcon?: LucideIcon;
}

export function EmptyStatePlaceholder({
  icon: Icon,
  title,
  description,
  actionLabel,
  onAction,
  ActionIcon
}: EmptyStatePlaceholderProps) {
  const { tokens } = useTheme();

  return (
    <div className={`w-full p-8 md:p-12 rounded-[24px] border border-dashed flex flex-col items-center justify-center text-center transition-all duration-300 ${tokens.surface} ${tokens.border}`}>
      <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 ${tokens.accentBgTint} ${tokens.accentBorder} border`}>
        <Icon className={`w-8 h-8 ${tokens.accentText}`} />
      </div>
      <h3 className={`font-display text-xl sm:text-2xl tracking-tight mb-2 ${tokens.textPrimary}`}>
        {title}
      </h3>
      <p className={`text-sm max-w-md mx-auto mb-6 ${tokens.textSecondary}`}>
        {description}
      </p>
      
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className={`px-5 py-2.5 rounded-xl text-sm font-semibold flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-95 ${tokens.accentBtn}`}
        >
          {ActionIcon && <ActionIcon className="w-4 h-4" />}
          {actionLabel}
        </button>
      )}
    </div>
  );
}
