import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Phone,
  MessageSquare,
  Mail,
  Building,
  Check,
  Briefcase,
  MapPin,
  Calendar,
  Clock
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { Client, ClientStatus, FollowUpType } from '../types';

interface EditClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: Client;
}

export const EditClientModal: React.FC<EditClientModalProps> = ({
  isOpen,
  onClose,
  client,
}) => {
  const { theme, tokens } = useTheme();
  const { updateClient, addFollowUp, projects } = useData();

  const [name, setName] = useState(client.name);
  const [role, setRole] = useState(client.role);
  const [company, setCompany] = useState(client.company);
  const [location, setLocation] = useState(client.location || '');
  const [phone, setPhone] = useState(client.phone || '');
  const [whatsappNumber, setWhatsappNumber] = useState(client.whatsappNumber || client.phone || '');
  const [email, setEmail] = useState(client.email);
  const [budget, setBudget] = useState(client.budget || '');
  const [requirement, setRequirement] = useState(client.requirement || '');
  const [leadSource, setLeadSource] = useState(client.leadSource || '');
  const [status, setStatus] = useState<ClientStatus>(client.status);
  const [preferredContact, setPreferredContact] = useState<'whatsapp' | 'call' | 'email' | 'phone'>(
    client.preferredContact || 'whatsapp'
  );
  const [selectedProjectIds, setSelectedProjectIds] = useState<string[]>(client.projectIds || []);
  const [notes, setNotes] = useState(client.notes || '');

  // Next follow-up fields
  const [nextFollowUpDate, setNextFollowUpDate] = useState(client.nextFollowUpDate || '');
  const [nextFollowUpTime, setNextFollowUpTime] = useState(client.nextFollowUpTime || '11:00 AM');
  const [nextFollowUpType, setNextFollowUpType] = useState<FollowUpType>(client.nextFollowUpType || 'call');
  const [nextFollowUpNote, setNextFollowUpNote] = useState(client.nextFollowUpNote || '');

  useEffect(() => {
    setName(client.name);
    setRole(client.role);
    setCompany(client.company);
    setLocation(client.location || '');
    setPhone(client.phone || '');
    setWhatsappNumber(client.whatsappNumber || client.phone || '');
    setEmail(client.email);
    setBudget(client.budget || '');
    setRequirement(client.requirement || '');
    setLeadSource(client.leadSource || '');
    setStatus(client.status);
    setPreferredContact(client.preferredContact || 'whatsapp');
    setSelectedProjectIds(client.projectIds || []);
    setNotes(client.notes || '');
    setNextFollowUpDate(client.nextFollowUpDate || '');
    setNextFollowUpTime(client.nextFollowUpTime || '11:00 AM');
    setNextFollowUpType(client.nextFollowUpType || 'call');
    setNextFollowUpNote(client.nextFollowUpNote || '');
  }, [client]);

  if (!isOpen) return null;

  const handleApplyPreset = (presetKey: string) => {
    const now = new Date();
    if (presetKey === '2hours') {
      const later = new Date(now.getTime() + 2 * 60 * 60 * 1000);
      setNextFollowUpDate(later.toISOString().split('T')[0]);
      const hours = later.getHours();
      const minutes = later.getMinutes();
      const ampm = hours >= 12 ? 'PM' : 'AM';
      const formattedHours = hours % 12 || 12;
      const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
      setNextFollowUpTime(`${formattedHours}:${formattedMinutes} ${ampm}`);
    } else if (presetKey === 'tomorrow') {
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      setNextFollowUpDate(tomorrow.toISOString().split('T')[0]);
      setNextFollowUpTime('11:00 AM');
    } else if (presetKey === '3days') {
      const threeDays = new Date(now);
      threeDays.setDate(threeDays.getDate() + 3);
      setNextFollowUpDate(threeDays.toISOString().split('T')[0]);
      setNextFollowUpTime('03:30 PM');
    } else if (presetKey === 'nextweek') {
      const nextWk = new Date(now);
      nextWk.setDate(nextWk.getDate() + 7);
      setNextFollowUpDate(nextWk.toISOString().split('T')[0]);
      setNextFollowUpTime('11:30 AM');
    } else if (presetKey === '10days') {
      const tenDays = new Date(now);
      tenDays.setDate(tenDays.getDate() + 10);
      setNextFollowUpDate(tenDays.toISOString().split('T')[0]);
      setNextFollowUpTime('04:00 PM');
    }
  };

  const toggleProject = (pId: string) => {
    setSelectedProjectIds((prev) =>
      prev.includes(pId) ? prev.filter((id) => id !== pId) : [...prev, pId]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    updateClient(client.id, {
      name: name.trim(),
      role: role.trim(),
      company: company.trim(),
      location: location.trim(),
      phone: phone.trim(),
      whatsappNumber: whatsappNumber.trim(),
      email: email.trim(),
      budget: budget.trim() || undefined,
      requirement: requirement.trim() || undefined,
      leadSource: leadSource.trim() || undefined,
      status,
      preferredContact,
      projectIds: selectedProjectIds,
      notes: notes.trim(),
      nextFollowUpDate: nextFollowUpDate || undefined,
      nextFollowUpTime: nextFollowUpTime || undefined,
      nextFollowUpType: nextFollowUpType || undefined,
      nextFollowUpNote: nextFollowUpNote.trim() || undefined,
    });

    // If a follow-up date was set or updated, add an entry to followUps
    if (nextFollowUpDate && nextFollowUpDate !== client.nextFollowUpDate) {
      addFollowUp({
        title: `${nextFollowUpType === 'call' ? 'Call' : nextFollowUpType === 'whatsapp' ? 'WhatsApp' : 'Site Meeting'}: ${name.trim()}`,
        clientId: client.id,
        projectId: selectedProjectIds[0] || undefined,
        type: nextFollowUpType,
        priority: 'high',
        dueDate: nextFollowUpDate,
        scheduledTime: nextFollowUpTime,
        customNumber: nextFollowUpType === 'whatsapp' ? whatsappNumber : phone,
        notes: nextFollowUpNote.trim() || `Follow-up updated for ${name.trim()}`,
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-xl rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[92vh] ${
          theme === 'dark' ? 'tactile-card-dark bg-[#121418]/95' : 'tactile-card-dawn'
        }`}
      >
        {/* Header */}
        <div
          className={`px-6 py-4 border-b flex items-center justify-between backdrop-blur-xl ${
            theme === 'dark' ? 'border-white/10 bg-white/5' : 'border-slate-200/80 bg-white/60'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white font-bold shadow-md">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-xl tracking-tight font-semibold">
                Edit Client Profile & Schedule
              </h3>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Update details, mobile, location & next follow-up
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-2 rounded-xl transition-all ${
              theme === 'dark' ? 'hover:bg-white/10 text-stone-400 hover:text-white' : 'hover:bg-slate-100 text-slate-500'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs font-mono">
          {/* Name & Role */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Client Full Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Vikramaditya Singhania"
                className={`w-full px-3 py-2.5 rounded-xl border text-sm font-sans font-medium ${tokens.border} bg-transparent`}
              />
            </div>
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Location / Address *
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Sector 84 Gurugram / Delhi NCR"
                  className={`w-full pl-9 pr-3 py-2.5 rounded-xl border text-xs font-sans font-medium ${tokens.border} bg-transparent`}
                />
              </div>
            </div>
          </div>

          {/* Company & Role */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Designation / Role
              </label>
              <input
                type="text"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                placeholder="e.g. High-Rise Penthouse Buyer / Investor"
                className={`w-full px-3 py-2 rounded-xl border text-xs ${tokens.border} bg-transparent`}
              />
            </div>
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Relationship Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as ClientStatus)}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold ${tokens.border} bg-transparent`}
              >
                <option value="vip" className="bg-stone-900 text-stone-100">
                  ⭐ VIP Account
                </option>
                <option value="active" className="bg-stone-900 text-stone-100">
                  Active Client
                </option>
                <option value="lead" className="bg-stone-900 text-stone-100">
                  Hot Lead
                </option>
              </select>
            </div>
          </div>

          {/* Sales qualification fields */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>Budget</label>
              <input type="text" value={budget} onChange={(e) => setBudget(e.target.value)} placeholder="e.g. ₹75L – ₹1Cr" className={`w-full px-3 py-2.5 rounded-xl border text-xs font-sans ${tokens.border} bg-transparent`} />
            </div>
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>Requirement</label>
              <input type="text" value={requirement} onChange={(e) => setRequirement(e.target.value)} placeholder="Plot / Flat / Investment" className={`w-full px-3 py-2.5 rounded-xl border text-xs font-sans ${tokens.border} bg-transparent`} />
            </div>
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>Lead Source</label>
              <input type="text" value={leadSource} onChange={(e) => setLeadSource(e.target.value)} placeholder="WhatsApp / Call / Excel" className={`w-full px-3 py-2.5 rounded-xl border text-xs font-sans ${tokens.border} bg-transparent`} />
            </div>
          </div>

          {/* Manchaha WhatsApp & Calling Phone Number */}
          <div className="p-3.5 rounded-2xl border border-emerald-500/30 bg-emerald-500/5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] uppercase font-bold tracking-wider mb-1 text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Manchaha WhatsApp Number</span>
                </label>
                <input
                  type="text"
                  value={whatsappNumber}
                  onChange={(e) => setWhatsappNumber(e.target.value)}
                  placeholder="+91 98101 23456"
                  className={`w-full px-3 py-2 rounded-xl border text-sm font-mono font-medium ${tokens.border} bg-transparent`}
                />
              </div>

              <div>
                <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted} flex items-center gap-1.5`}>
                  <Phone className="w-3.5 h-3.5" />
                  <span>Calling Phone Number</span>
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98101 23456"
                  className={`w-full px-3 py-2 rounded-xl border text-sm font-mono ${tokens.border} bg-transparent`}
                />
              </div>
            </div>
          </div>

          {/* Section: Next Follow-Up Scheduling */}
          <div className={`p-4 rounded-2xl border ${theme === 'dark' ? 'bg-white/5 border-white/10' : 'bg-white/80 border-slate-200 shadow-sm'}`}>
            <div className="flex items-center gap-2 mb-2 pb-2 border-b border-inherit">
              <Calendar className="w-4 h-4 text-amber-500" />
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                Next Follow-Up Schedule (अगला फॉलो-अप)
              </span>
            </div>

            {/* Quick Presets */}
            <div className="grid grid-cols-5 gap-1.5 mb-3">
              <button
                type="button"
                onClick={() => handleApplyPreset('2hours')}
                className="py-1 px-1.5 rounded-lg border text-[10px] font-semibold text-center hover:bg-amber-500/20 cursor-pointer"
              >
                ⚡ 2 Hours
              </button>
              <button
                type="button"
                onClick={() => handleApplyPreset('tomorrow')}
                className="py-1 px-1.5 rounded-lg border text-[10px] font-semibold text-center hover:bg-amber-500/20 cursor-pointer"
              >
                🌅 Tomorrow
              </button>
              <button
                type="button"
                onClick={() => handleApplyPreset('3days')}
                className="py-1 px-1.5 rounded-lg border text-[10px] font-semibold text-center hover:bg-amber-500/20 cursor-pointer"
              >
                📅 3 Days
              </button>
              <button
                type="button"
                onClick={() => handleApplyPreset('nextweek')}
                className="py-1 px-1.5 rounded-lg border text-[10px] font-semibold text-center hover:bg-amber-500/20 cursor-pointer"
              >
                🗓️ Next Wk
              </button>
              <button
                type="button"
                onClick={() => handleApplyPreset('10days')}
                className="py-1 px-1.5 rounded-lg border text-[10px] font-semibold text-center hover:bg-amber-500/20 cursor-pointer"
              >
                🔟 10 Days
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-2">
              <div>
                <label className={`block text-[10px] uppercase font-mono mb-1 ${tokens.textMuted}`}>
                  Follow-Up Date
                </label>
                <input
                  type="date"
                  value={nextFollowUpDate}
                  onChange={(e) => setNextFollowUpDate(e.target.value)}
                  className={`w-full px-2.5 py-1.5 rounded-lg border text-xs ${tokens.border} bg-transparent`}
                />
              </div>

              <div>
                <label className={`block text-[10px] uppercase font-mono mb-1 ${tokens.textMuted}`}>
                  Time
                </label>
                <input
                  type="text"
                  value={nextFollowUpTime}
                  onChange={(e) => setNextFollowUpTime(e.target.value)}
                  placeholder="11:30 AM"
                  className={`w-full px-2.5 py-1.5 rounded-lg border text-xs ${tokens.border} bg-transparent`}
                />
              </div>

              <div>
                <label className={`block text-[10px] uppercase font-mono mb-1 ${tokens.textMuted}`}>
                  Channel
                </label>
                <select
                  value={nextFollowUpType}
                  onChange={(e) => setNextFollowUpType(e.target.value as FollowUpType)}
                  className={`w-full px-2.5 py-1.5 rounded-lg border text-xs ${tokens.border} bg-transparent`}
                >
                  <option value="call">Phone Call</option>
                  <option value="whatsapp">WhatsApp</option>
                  <option value="meeting">Site Meeting</option>
                </select>
              </div>
            </div>

            <div>
              <label className={`block text-[10px] uppercase font-mono mb-1 ${tokens.textMuted}`}>
                Follow-Up Note / Agenda
              </label>
              <input
                type="text"
                value={nextFollowUpNote}
                onChange={(e) => setNextFollowUpNote(e.target.value)}
                placeholder="e.g. Call regarding Siyaram Sector 84 plot documentation"
                className={`w-full px-3 py-1.5 rounded-lg border text-xs ${tokens.border} bg-transparent`}
              />
            </div>
          </div>

          {/* Linked Projects */}
          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1.5 ${tokens.textMuted}`}>
              Associated Projects (e.g. Siyaram)
            </label>
            <div className="flex flex-wrap gap-2">
              {projects.map((p) => {
                const isSelected = selectedProjectIds.includes(p.id);
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => toggleProject(p.id)}
                    className={`px-3 py-1.5 rounded-xl border text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/20 text-amber-600 dark:text-amber-300 border-amber-500'
                        : `${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary}`
                    }`}
                  >
                    <Building className="w-3 h-3" />
                    <span>{p.title}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Client Notes */}
          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
              Client Preferences & Site Notes
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Interested in Corner plot facing clubhouse or 4BHK Tower A top floor."
              className={`w-full px-3 py-2 rounded-xl border text-xs leading-relaxed ${tokens.border} bg-transparent`}
            />
          </div>

          {/* Footer */}
          <div className={`pt-4 border-t flex items-center justify-end gap-2.5 ${tokens.border}`}>
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2 rounded-xl border text-xs font-semibold ${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary}`}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md bg-slate-900 text-white dark:bg-amber-500 dark:text-slate-950 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Update Client Dossier</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

