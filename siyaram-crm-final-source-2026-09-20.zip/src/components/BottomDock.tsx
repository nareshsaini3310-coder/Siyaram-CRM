import React from 'react';
import { motion } from 'motion/react';
import {
  CalendarDays,
  Briefcase,
  Users,
  MapPin,
  Share2
} from 'lucide-react';
import { ViewType } from '../types';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';
import { useData } from '../context/DataContext';

interface BottomDockProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
}

export const BottomDock: React.FC<BottomDockProps> = ({ currentView, onNavigate }) => {
  const { theme, tokens } = useTheme();
  const { stats } = useData();

  const dockItems: {
    id: ViewType;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number | null;
    notificationDot?: number | null;
  }[] = [
    {
      id: 'dashboard',
      label: 'Aaj',
      icon: CalendarDays,
    },
    {
      id: 'projects',
      label: 'Projects',
      icon: Briefcase,
      badge: stats.activeProjectsCount > 0 ? stats.activeProjectsCount : null,
    },
    {
      id: 'clients',
      label: 'Leads',
      icon: Users,
    },
    {
      id: 'followups',
      label: 'Visit',
      icon: MapPin,
      badge: stats.urgentFollowUpsCount > 0 ? stats.urgentFollowUpsCount : null,
      notificationDot: stats.dueOrOverdueFollowUpsCount > 0 ? stats.dueOrOverdueFollowUpsCount : null,
    },
    {
      id: 'tags',
      label: 'Refer',
      icon: Share2,
    },
  ];

  // Also check if current view is sub-view (e.g. project_detail -> projects, client_detail -> clients)
  const isItemActive = (id: ViewType) => {
    if (currentView === id) return true;
    if (id === 'projects' && currentView === 'project_detail') return true;
    if (id === 'clients' && currentView === 'client_detail') return true;
    return false;
  };

  return (
    <nav
      aria-label="Bottom Navigation Dock"
      className="fixed bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 z-40 w-[calc(100%-2rem)] max-w-md pointer-events-none"
    >
      <div
        className={`pointer-events-auto p-1.5 sm:p-2 rounded-[25px] flex items-center justify-between gap-1 transition-all ${
          theme === 'dark' 
            ? 'bg-blue-500/10 backdrop-blur-[40px] border border-blue-400/20 shadow-[inset_0_1px_1px_rgba(255,255,255,0.12),inset_0_0_24px_rgba(37,99,235,0.12),0_12px_40px_rgba(0,0,0,0.6)]' 
            : 'bg-white/60 backdrop-blur-[40px] border border-blue-200/70 shadow-[inset_0_1px_1px_rgba(255,255,255,0.9),inset_0_0_24px_rgba(37,99,235,0.08),0_12px_40px_rgba(15,23,42,0.10)]'
        }`}
      >
        {dockItems.map((item) => {
          const active = isItemActive(item.id);
          const IconComponent = item.icon;

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => { haptics.selection(); onNavigate(item.id); }}
              className={`relative flex-1 flex flex-col items-center justify-center py-2 px-1 sm:px-2 rounded-full transition-all duration-150 cursor-pointer ${
                active
                  ? theme === 'dark'
                    ? 'text-blue-300'
                    : 'text-blue-700'
                  : `${tokens.textMuted} hover:${tokens.textPrimary} hover:bg-blue-500/10 active:scale-95`
              }`}
            >
              {active && (
                <motion.div
                  layoutId="active-dock-pill"
                  className={`absolute inset-0 rounded-full z-0 pointer-events-none ${
                    theme === 'dark'
                      ? 'bg-blue-500/[0.20] shadow-[inset_0_1px_1px_rgba(255,255,255,0.12)]'
                      : 'bg-blue-500/[0.10] shadow-[inset_0_1px_1px_rgba(255,255,255,0.7)]'
                  }`}
                  transition={{
                    type: 'spring',
                    stiffness: 550,
                    damping: 38,
                    mass: 0.35,
                  }}
                />
              )}
              <div className="relative z-10">
                <IconComponent
                  className={`w-5 h-5 transition-transform duration-150 ${
                    active ? 'stroke-[2.2] scale-105' : 'stroke-[1.8]'
                  }`}
                />
                {item.notificationDot ? (
                  <span className="absolute -top-1.5 -right-2 min-w-[14px] h-[14px] px-0.5 rounded-full text-[8px] font-mono font-bold bg-red-500 text-white flex items-center justify-center shadow-xs ring-1 ring-white/10">
                    {item.notificationDot}
                  </span>
                ) : item.badge && !active ? (
                  <span className="absolute -top-1 -right-2 min-w-[14px] h-[14px] px-1 rounded-full text-[9px] font-mono font-bold bg-rose-500 text-white flex items-center justify-center shadow-xs">
                    {item.badge}
                  </span>
                ) : null}
              </div>
              <span
                className={`relative z-10 text-[10px] mt-0.5 tracking-tight font-medium transition-all ${
                  active ? 'font-semibold' : 'opacity-80'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
