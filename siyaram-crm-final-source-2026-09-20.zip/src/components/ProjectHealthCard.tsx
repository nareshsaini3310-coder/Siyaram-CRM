import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Activity, CheckCircle2, Clock, PlayCircle, TrendingUp, DollarSign } from 'lucide-react';
import { Project } from '../types';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';

interface ProjectHealthCardProps {
  projects: Project[];
  activeFilter: string;
  onFilterChange: (status: string) => void;
}

export const ProjectHealthCard: React.FC<ProjectHealthCardProps> = ({
  projects,
  activeFilter,
  onFilterChange,
}) => {
  const { theme, tokens } = useTheme();

  const totalProjects = projects.length;
  const activeCount = projects.filter((p) => p.status === 'active').length;
  const pendingCount = projects.filter(
    (p) => p.status === 'in_review' || p.status === 'planning'
  ).length;
  const completedCount = projects.filter((p) => p.status === 'completed').length;

  const activePct = totalProjects > 0 ? Math.round((activeCount / totalProjects) * 100) : 0;
  const pendingPct = totalProjects > 0 ? Math.round((pendingCount / totalProjects) * 100) : 0;
  const completedPct = totalProjects > 0 ? Math.round((completedCount / totalProjects) * 100) : 0;

  // Portfolio health index: Completed (100%), Active (85%), Pending (60%)
  const healthIndex =
    totalProjects > 0
      ? Math.round(
          ((completedCount * 1.0 + activeCount * 0.85 + pendingCount * 0.6) / totalProjects) *
            100
        )
      : 100;

  const totalBudget = projects.reduce((sum, p) => sum + (p.budget || 0), 0);

  // Data for Recharts Donut
  const chartData = [
    {
      name: 'Active',
      value: activeCount,
      color: '#10B981', // Emerald
      bgLight: 'bg-emerald-500/10',
      textLight: 'text-emerald-500',
      borderLight: 'border-emerald-500/20',
      pct: activePct,
      filterKey: 'active',
      desc: 'Live on-site & under development',
    },
    {
      name: 'Pending',
      value: pendingCount,
      color: '#F59E0B', // Amber
      bgLight: 'bg-amber-500/10',
      textLight: 'text-amber-500',
      borderLight: 'border-amber-500/20',
      pct: pendingPct,
      filterKey: 'planning', // or in_review
      desc: 'Planning phases & architectural review',
    },
    {
      name: 'Completed',
      value: completedCount,
      color: '#3B82F6', // Blue
      bgLight: 'bg-blue-500/10',
      textLight: 'text-blue-500',
      borderLight: 'border-blue-500/20',
      pct: completedPct,
      filterKey: 'completed',
      desc: 'Delivered & handed over',
    },
  ];

  // If all counts are zero, show placeholder ring
  const hasData = totalProjects > 0;
  const pieData = hasData
    ? chartData.filter((d) => d.value > 0)
    : [{ name: 'No Projects', value: 1, color: theme === 'dark' ? '#374151' : '#E5E7EB' }];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      if (!hasData) return null;
      return (
        <div
          className={`px-3 py-2 rounded-xl border shadow-xl backdrop-blur-md text-xs z-50 ${
            theme === 'dark' ? 'bg-[#181a20]/95 border-white/10 text-stone-100' : 'bg-white/95 border-slate-200 text-slate-900'
          }`}
        >
          <div className="flex items-center gap-2 font-bold">
            <span
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: data.color }}
            />
            <span>{data.name} Projects</span>
          </div>
          <div className="mt-1 flex items-center justify-between gap-4 font-mono text-[11px] text-stone-400">
            <span>{data.value} projects</span>
            <span className="font-bold text-amber-500">{data.pct}%</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div
      id="project-health-summary-card"
      className={`p-4 sm:p-5 rounded-3xl border shadow-sm transition-all relative overflow-hidden ${tokens.surface} ${tokens.border}`}
    >
      {/* Background ambient gradient glow */}
      <div className="absolute -top-24 -right-24 w-64 h-64 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-64 h-64 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />

      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
        {/* Left info column: Header & Headline Metrics */}
        <div className="flex-1 min-w-0 space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-500 shrink-0">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display text-base sm:text-lg font-bold tracking-tight">
                  Project Health & Pipeline
                </h3>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25">
                  <TrendingUp className="w-3 h-3" />
                  {healthIndex}% Score
                </span>
              </div>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Real-time ratio of Active sites, Pending planning, and Completed deliveries
              </p>
            </div>
          </div>

          {/* Quick Snapshot Metrics */}
          <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
            <button
              type="button"
              onClick={() => {
                haptics.selection();
                onFilterChange('all');
              }}
              className={`px-3 py-1.5 rounded-xl border font-mono text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                activeFilter === 'all'
                  ? 'bg-stone-500/20 border-stone-400/40 text-stone-100 font-bold shadow-sm'
                  : `${tokens.surfaceElevated} ${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary}`
              }`}
              title="View all projects"
            >
              <span>Total:</span>
              <span className="font-bold text-amber-500">{totalProjects}</span>
            </button>

            <div className="h-4 w-px bg-stone-500/20 hidden sm:block" />

            <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-stone-500/10 border border-stone-500/15 text-[11px] font-mono">
              <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
              <span className={tokens.textSecondary}>Capital:</span>
              <span className={`font-semibold ${tokens.textPrimary}`}>
                €{totalBudget.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Center: Recharts Donut visualization */}
        <div className="flex items-center justify-center gap-4 shrink-0 px-2">
          <div className="w-32 h-32 relative flex items-center justify-center">
            <ResponsiveContainer width={128} height={128}>
              <PieChart>
                <Pie
                  data={pieData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={36}
                  outerRadius={52}
                  paddingAngle={hasData && pieData.length > 1 ? 4 : 0}
                  stroke="none"
                  isAnimationActive={true}
                >
                  {pieData.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>

            {/* Inner Ring Center Metric */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="font-display font-bold text-lg sm:text-xl leading-none tracking-tight">
                {activePct}%
              </span>
              <span className="text-[9px] font-mono uppercase tracking-widest text-stone-400 mt-0.5">
                Active
              </span>
            </div>
          </div>
        </div>

        {/* Right column: Interactive KPI Breakdown Cards */}
        <div className="grid grid-cols-3 gap-2.5 sm:gap-3 w-full lg:w-auto lg:min-w-[340px]">
          {/* Active Card */}
          <button
            type="button"
            onClick={() => {
              haptics.selection();
              onFilterChange(activeFilter === 'active' ? 'all' : 'active');
            }}
            className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeFilter === 'active'
                ? 'bg-emerald-500/20 border-emerald-500/60 ring-2 ring-emerald-500/30'
                : `${tokens.surfaceElevated} ${tokens.border} hover:border-emerald-500/40 hover:bg-emerald-500/5`
            }`}
            title="Filter by Active projects"
          >
            <div className="flex items-center justify-between gap-1 mb-1">
              <span className="text-[10px] font-mono uppercase font-bold text-emerald-500 flex items-center gap-1">
                <PlayCircle className="w-3 h-3" />
                Active
              </span>
              <span className="text-[10px] font-mono font-bold text-emerald-500/80">
                {activePct}%
              </span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="font-display text-lg font-bold">{activeCount}</span>
              <span className="text-[10px] text-stone-400 font-mono">projects</span>
            </div>
            {/* Progress bar */}
            <div className="w-full h-1 rounded-full bg-emerald-500/20 mt-2 overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                style={{ width: `${activePct}%` }}
              />
            </div>
          </button>

          {/* Pending Card */}
          <button
            type="button"
            onClick={() => {
              haptics.selection();
              onFilterChange(activeFilter === 'planning' || activeFilter === 'in_review' ? 'all' : 'planning');
            }}
            className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeFilter === 'planning' || activeFilter === 'in_review'
                ? 'bg-amber-500/20 border-amber-500/60 ring-2 ring-amber-500/30'
                : `${tokens.surfaceElevated} ${tokens.border} hover:border-amber-500/40 hover:bg-amber-500/5`
            }`}
            title="Filter by Pending (Planning & In Review) projects"
          >
            <div className="flex items-center justify-between gap-1 mb-1">
              <span className="text-[10px] font-mono uppercase font-bold text-amber-500 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Pending
              </span>
              <span className="text-[10px] font-mono font-bold text-amber-500/80">
                {pendingPct}%
              </span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="font-display text-lg font-bold">{pendingCount}</span>
              <span className="text-[10px] text-stone-400 font-mono">projects</span>
            </div>
            {/* Progress bar */}
            <div className="w-full h-1 rounded-full bg-amber-500/20 mt-2 overflow-hidden">
              <div
                className="h-full bg-amber-500 rounded-full transition-all duration-500"
                style={{ width: `${pendingPct}%` }}
              />
            </div>
          </button>

          {/* Completed Card */}
          <button
            type="button"
            onClick={() => {
              haptics.selection();
              onFilterChange(activeFilter === 'completed' ? 'all' : 'completed');
            }}
            className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
              activeFilter === 'completed'
                ? 'bg-blue-500/20 border-blue-500/60 ring-2 ring-blue-500/30'
                : `${tokens.surfaceElevated} ${tokens.border} hover:border-blue-500/40 hover:bg-blue-500/5`
            }`}
            title="Filter by Completed projects"
          >
            <div className="flex items-center justify-between gap-1 mb-1">
              <span className="text-[10px] font-mono uppercase font-bold text-blue-500 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                Done
              </span>
              <span className="text-[10px] font-mono font-bold text-blue-500/80">
                {completedPct}%
              </span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="font-display text-lg font-bold">{completedCount}</span>
              <span className="text-[10px] text-stone-400 font-mono">projects</span>
            </div>
            {/* Progress bar */}
            <div className="w-full h-1 rounded-full bg-blue-500/20 mt-2 overflow-hidden">
              <div
                className="h-full bg-blue-500 rounded-full transition-all duration-500"
                style={{ width: `${completedPct}%` }}
              />
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
