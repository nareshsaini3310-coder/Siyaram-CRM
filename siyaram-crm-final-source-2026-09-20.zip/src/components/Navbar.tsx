import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu,
  Search,
  Mic,
  Sun,
  Moon,
  Sparkles,
  ShieldCheck,
  Plus,
  Smartphone,
  Download,
  CloudOff,
  Cloud,
  Bell,
  RefreshCw, Clock, X, ArrowRight, CornerDownLeft,
  CalendarDays,
  Briefcase,
  Users,
  MapPin,
  Share2 } from 'lucide-react';
import { ViewType } from '../types';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { DownloadApkModal } from './DownloadApkModal';

interface NavbarProps {
  currentView: ViewType;
  onNavigate?: (view: ViewType) => void;
  onOpenMobileMenu: () => void;
  onOpenVoiceRecorder: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onQuickNewItem?: () => void;
  isScrolled?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenMobileMenu,
  onOpenVoiceRecorder,
  searchQuery,
  onSearchChange,
  onQuickNewItem,
  isScrolled = false,
}) => {
  const { theme, isAutoTheme, toggleTheme, tokens, accent } = useTheme();
  const { user, openAuthModal } = useAuth();
  const { syncStatus, stats } = useData();
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Detect macOS for ⌘K vs Ctrl+K indicator
  const [isMac, setIsMac] = useState(true);
  useEffect(() => {
    if (typeof window !== 'undefined' && typeof navigator !== 'undefined') {
      const platform = (navigator as any)?.userAgentData?.platform || navigator?.platform || '';
      setIsMac(/mac/i.test(platform));
    }
  }, []);

  // Persistent recent searches with sensible defaults
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('siyaram_recent_searches');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [
      'Sector 84 High-Rises',
      'Ananya S',
      'Commercial Plots',
      'Q3 Meeting Notes'
    ];
  });

  const saveSearchToRecent = (term: string) => {
    const trimmed = term.trim();
    if (!trimmed) return;
    setRecentSearches(prev => {
      const updated = [trimmed, ...prev.filter(s => s.toLowerCase() !== trimmed.toLowerCase())].slice(0, 6);
      try {
        localStorage.setItem('siyaram_recent_searches', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    try {
      localStorage.removeItem('siyaram_recent_searches');
    } catch {}
    haptics.selection();
  };

  // Global Keyboard Shortcuts: Cmd+K / Ctrl+K and '/' to focus and open Recent Searches
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const isCmdK = (e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K');

      if (isCmdK) {
        e.preventDefault();
        e.stopPropagation();
        haptics.selection();
        setIsSearchFocused(true);
        // Focus and select existing text in search input
        setTimeout(() => {
          if (searchInputRef.current) {
            searchInputRef.current.focus();
            searchInputRef.current.select();
          }
        }, 10);
        return;
      }

      // '/' shortcut to search (when user is not currently inside any editable input/textarea)
      if (e.key === '/' && !isSearchFocused) {
        const target = document.activeElement;
        const isEditing =
          target instanceof HTMLInputElement ||
          target instanceof HTMLTextAreaElement ||
          (target as HTMLElement)?.isContentEditable;

        if (!isEditing) {
          e.preventDefault();
          haptics.selection();
          setIsSearchFocused(true);
          setTimeout(() => {
            if (searchInputRef.current) {
              searchInputRef.current.focus();
              searchInputRef.current.select();
            }
          }, 10);
          return;
        }
      }

      // Escape key to dismiss search and blur
      if (e.key === 'Escape' && isSearchFocused) {
        e.preventDefault();
        setIsSearchFocused(false);
        searchInputRef.current?.blur();
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [isSearchFocused]);

  // Click outside to dismiss search dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(e.target as Node)
      ) {
        setIsSearchFocused(false);
      }
    };

    if (isSearchFocused) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isSearchFocused]);

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if (searchQuery.trim()) {
        saveSearchToRecent(searchQuery);
      }
      setIsSearchFocused(false);
      searchInputRef.current?.blur();
    } else if (e.key === 'Escape') {
      setIsSearchFocused(false);
      searchInputRef.current?.blur();
    }
  };

  const getBreadcrumbTitle = () => {
    switch (currentView) {
      case 'dashboard':
        return 'Aaj · Daily Agenda';
      case 'projects':
        return 'Projects Directory';
      case 'project_detail':
        return 'Project Specification';
      case 'clients':
        return 'Leads · Client Directory';
      case 'client_detail':
        return 'Client Profile';
      case 'followups':
        return 'Visit · Follow-ups & Calls';
      case 'tags':
        return 'Refer · Tags & Taxonomies';
      case 'settings':
        return 'Studio Configuration & Theme';
      default:
        return 'Studio';
    }
  };

  const headerNavItems: {
    id: ViewType;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    count?: number | null;
  }[] = [
    { id: 'dashboard', label: 'Aaj', icon: CalendarDays },
    { id: 'projects', label: 'Projects', icon: Briefcase, count: stats.activeProjectsCount },
    { id: 'clients', label: 'Leads', icon: Users, count: stats.totalClientsCount },
    { id: 'followups', label: 'Visit', icon: MapPin, count: stats.urgentFollowUpsCount > 0 ? stats.urgentFollowUpsCount : null },
    { id: 'tags', label: 'Refer', icon: Share2 },
  ];

  return (
    <header
      className={`sticky top-0 z-30 min-h-[3.75rem] py-1.5 border-b flex items-center justify-between px-2.5 sm:px-4 md:px-6 backdrop-blur-xl transition-all duration-300 ${tokens.border} ${
        theme === 'dark' ? 'bg-[#0f1115]/85 backdrop-blur-[40px]' : 'bg-white/80 backdrop-blur-[40px]'
      } ${
        isScrolled
          ? theme === 'dark'
            ? 'shadow-[0_10px_25px_-5px_rgba(0,0,0,0.85),0_4px_10px_-2px_rgba(37,99,235,0.12)] border-b-blue-400/20'
            : 'shadow-[0_10px_25px_-5px_rgba(0,0,0,0.08),0_4px_10px_-2px_rgba(212,163,58,0.12)] border-b-[#D4A33A]/30'
          : 'shadow-none'
      }`}
    >
      {/* Left: Mobile Menu + Grand Siyaram CRM Headline */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0 shrink-0">
        <button
          type="button"
          onClick={() => {
            haptics.selection();
            onOpenMobileMenu();
          }}
          className={`p-2 rounded-xl border lg:hidden shrink-0 ${tokens.border} ${tokens.surfaceHover}`}
          aria-label="Open menu"
        >
          <Menu className="w-4 h-4" />
        </button>

        {/* Grand Siyaram Emblem & Brand Headline */}
        <div
          onClick={() => onNavigate?.('dashboard')}
          className="flex items-center gap-2 sm:gap-2.5 min-w-0 cursor-pointer select-none group"
          title="Go to Siyaram CRM Dashboard"
        >
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-br from-blue-500 via-blue-600 to-violet-600 flex items-center justify-center text-white font-bold font-display text-lg sm:text-xl shadow-sm shrink-0 group-hover:scale-105 transition-transform">
            S
          </div>

          <div className="flex flex-col justify-center min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
              <span className="font-display text-xl sm:text-2xl font-bold tracking-tight text-blue-600 dark:text-blue-300 leading-none truncate select-none">
                SIYARAM
              </span>
              <span className="px-1.5 py-0.5 rounded text-[9px] sm:text-[10px] font-mono font-black uppercase tracking-wider bg-blue-500/15 text-blue-700 dark:text-blue-200 border border-blue-400/25 shrink-0">
                CRM
              </span>
            </div>

            {/* Current View Breadcrumb */}
            <span className={`text-[10px] sm:text-xs font-mono truncate hidden xs:block mt-0.5 ${tokens.textMuted}`}>
              {getBreadcrumbTitle()}
            </span>
          </div>
        </div>
      </div>

      {/* Center: Header Navigation Links (Properly padded with generous spacing to eliminate any visual overlap) */}
      {onNavigate && (
        <nav
          aria-label="Header Navigation Links"
          className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/5 dark:border-white/5 mx-2 lg:mx-4 shrink-0"
        >
          {headerNavItems.map((item) => {
            const isActive =
              currentView === item.id ||
              (item.id === 'projects' && currentView === 'project_detail') ||
              (item.id === 'clients' && currentView === 'client_detail');
            const IconComponent = item.icon;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  haptics.selection();
                  onNavigate(item.id);
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all duration-150 cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-500/15 text-blue-700 dark:text-blue-200 border border-blue-400/25 shadow-xs font-bold'
                    : `text-stone-600 dark:text-stone-400 hover:text-stone-950 dark:hover:text-stone-100 hover:bg-black/5 dark:hover:bg-white/5 border border-transparent`
                }`}
              >
                <IconComponent className="w-3.5 h-3.5 shrink-0" />
                <span>{item.label}</span>
                {item.count != null && item.count > 0 && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[9px] font-mono font-bold ${
                      isActive
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-black/10 dark:bg-white/10 text-stone-500 dark:text-stone-400'
                    }`}
                  >
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      )}

      {/* Middle/Right: Search, Status Indicators & Actions */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        {/* Mobile Search Button (Visible on < md) */}
        <button
          type="button"
          id="navbar-btn-mobile-search"
          onClick={() => {
            haptics.selection();
            setIsSearchFocused(true);
            setTimeout(() => {
              searchInputRef.current?.focus();
            }, 30);
          }}
          className={`p-2 rounded-xl border md:hidden transition-colors ${tokens.border} ${tokens.surfaceHover} ${tokens.textSecondary}`}
          aria-label="Search"
          title="Search (⌘K)"
        >
          <Search className="w-4 h-4" />
        </button>

        {/* Global Search Bar */}
        <div
          ref={searchContainerRef}
          className={`relative ${
            isSearchFocused
              ? 'fixed inset-x-3 top-2.5 z-50 md:static md:inset-auto md:z-20 md:block'
              : 'hidden md:block'
          } w-auto md:w-52 lg:w-64 transition-all duration-200`}
        >
          <Search className={`w-3.5 h-3.5 absolute left-3 top-2.5 ${tokens.textMuted} z-10 pointer-events-none`} />
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            onFocus={() => setIsSearchFocused(true)}
            onKeyDown={handleInputKeyDown}
            placeholder="Search projects, clients..."
            className={`relative z-10 w-full pl-8 pr-16 py-1.5 rounded-xl text-xs border transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500/30 shadow-sm ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
          />

          <div className="absolute right-2 top-2 z-20 flex items-center gap-1">
            {searchQuery ? (
              <button
                type="button"
                onClick={() => {
                  haptics.selection();
                  onSearchChange('');
                  searchInputRef.current?.focus();
                }}
                className="w-4 h-4 rounded-full flex items-center justify-center text-[10px] opacity-60 hover:opacity-100 hover:bg-black/10 dark:hover:bg-white/10 cursor-pointer"
                title="Clear search"
              >
                ✕
              </button>
            ) : (
              <kbd
                onClick={() => {
                  searchInputRef.current?.focus();
                  setIsSearchFocused(true);
                }}
                className={`hidden md:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-mono border cursor-pointer select-none transition-colors ${
                  theme === 'dark'
                    ? 'bg-white/5 border-white/10 text-stone-400 hover:text-stone-200'
                    : 'bg-stone-100 border-stone-200 text-stone-500 hover:text-stone-800'
                }`}
                title="Press Cmd+K or Ctrl+K to search"
              >
                <span>{isMac ? '⌘K' : 'Ctrl+K'}</span>
              </kbd>
            )}

            {/* Mobile close button when expanded as overlay on mobile */}
            {isSearchFocused && (
              <button
                type="button"
                onClick={() => {
                  setIsSearchFocused(false);
                  searchInputRef.current?.blur();
                }}
                className="p-0.5 text-stone-400 hover:text-stone-200 md:hidden ml-1 cursor-pointer"
                title="Close search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Floating Recent Searches Dropdown */}
          <AnimatePresence>
            {isSearchFocused && (
              <motion.div
                initial={{ opacity: 0, y: 5, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 5, scale: 0.98 }}
                transition={{ duration: 0.15, ease: 'easeOut' }}
                className={`absolute top-[120%] left-0 w-full min-w-[260px] sm:min-w-[280px] p-2 rounded-2xl border shadow-2xl z-[100] transition-colors ${
                  theme === 'dark' ? 'bg-[#1a1c23]/95 border-white/10 text-stone-200' : 'bg-white/95 border-black/10 text-slate-800'
                } backdrop-blur-2xl`}
              >
                <div className="px-2 py-1.5 mb-1 flex items-center justify-between border-b border-black/5 dark:border-white/5">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3 h-3 text-amber-500" />
                    <span className={`text-[10px] font-mono uppercase tracking-wider font-semibold ${tokens.textMuted}`}>
                      Recent Searches
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {recentSearches.length > 0 && (
                      <button
                        type="button"
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={clearRecentSearches}
                        className="text-[10px] font-mono text-amber-500 hover:underline cursor-pointer"
                      >
                        Clear
                      </button>
                    )}
                    <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/5 dark:bg-white/5 ${tokens.textMuted}`}>
                      ESC
                    </span>
                  </div>
                </div>

                <div className="space-y-0.5 mt-1">
                  {recentSearches.length > 0 ? (
                    recentSearches.map((search, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onMouseDown={(e) => e.preventDefault()} // Prevents input from losing focus immediately
                        onClick={() => {
                          haptics.selection();
                          onSearchChange(search);
                          saveSearchToRecent(search);
                          setIsSearchFocused(false);
                        }}
                        className={`w-full flex items-center justify-between px-2.5 py-2 text-xs rounded-xl transition-colors cursor-pointer group ${tokens.surfaceHover}`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <Clock className={`w-3.5 h-3.5 shrink-0 ${tokens.textMuted} group-hover:text-amber-500 transition-colors`} />
                          <span className={`truncate font-medium ${tokens.textPrimary}`}>{search}</span>
                        </div>
                        <span className="text-[10px] font-mono text-stone-400 opacity-0 group-hover:opacity-100 transition-opacity">
                          Select
                        </span>
                      </button>
                    ))
                  ) : (
                    <div className="px-3 py-4 text-center text-[11px] text-stone-400 font-mono">
                      No recent searches. Type and press Enter.
                    </div>
                  )}
                </div>

                {/* Footer shortcut helper hint */}
                <div className="mt-2 pt-2 border-t border-black/5 dark:border-white/5 px-2 flex items-center justify-between text-[10px] font-mono text-stone-400">
                  <span>Press <kbd className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10 font-bold">↵</kbd> to search</span>
                  <span><kbd className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10 font-bold">{isMac ? '⌘K' : 'Ctrl+K'}</kbd> toggle</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        
        {/* Dedicated Status Indicators: Properly padded to prevent any visual overlap with navigation links */}
        <div className="flex items-center gap-2 pl-2 sm:pl-3 pr-1 shrink-0 border-l border-black/10 dark:border-white/10">
          {/* Sync Status Badge */}
          <div
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-[10px] sm:text-xs font-mono font-medium shrink-0 border transition-all ${
              syncStatus === 'offline'
                ? 'bg-rose-500/10 text-rose-500 border-rose-500/30'
                : syncStatus === 'syncing'
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/40 shadow-xs'
                : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/25'
            }`}
            title={
              syncStatus === 'offline'
                ? 'Offline Mode: All data stored locally'
                : syncStatus === 'syncing'
                ? 'Syncing changes...'
                : 'Synced: All data saved locally'
            }
          >
            {syncStatus === 'offline' && <CloudOff className="w-3.5 h-3.5 shrink-0" />}
            {syncStatus === 'syncing' && <RefreshCw className="w-3.5 h-3.5 animate-spin shrink-0" />}
            {syncStatus === 'synced' && <Cloud className="w-3.5 h-3.5 shrink-0" />}
            <span
              className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                syncStatus === 'offline'
                  ? 'bg-rose-500'
                  : syncStatus === 'syncing'
                  ? 'bg-amber-400 animate-ping'
                  : 'bg-emerald-500'
              }`}
            />
            <span className="hidden sm:inline">
              {syncStatus === 'offline' ? 'Offline' : syncStatus === 'syncing' ? 'Syncing' : 'Synced'}
            </span>
          </div>

          {/* 2-Minute Call Alert / Follow-up Notification Trigger */}
          <button
            id="navbar-btn-followup-alert"
            type="button"
            onClick={() => {
              haptics.medium();
              if ((window as any).__triggerTest2MinAlert) {
                (window as any).__triggerTest2MinAlert();
              } else if ((window as any).__enableNotifications) {
                (window as any).__enableNotifications();
              }
            }}
            className={`p-2 rounded-xl border relative transition-all cursor-pointer shrink-0 ${tokens.border} ${tokens.surfaceHover} ${tokens.textPrimary}`}
            title="2-Minute Call Notification Alert & Sound (Click to Test Alert)"
          >
            <Bell className="w-4 h-4 text-amber-500" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500" />
          </button>
        </div>

        {/* Install on Mobile / APK Button */}
        <button
          id="navbar-btn-install-app"
          type="button"
          onClick={() => {
            haptics.selection();
            setIsApkModalOpen(true);
          }}
          className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border shadow-xs shrink-0 ${
            theme === 'dark'
              ? 'bg-amber-500/15 text-amber-400 border-amber-500/30 hover:bg-amber-500/25'
              : 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
          }`}
          title="Install Siyaram CRM on Phone (APK / WebAPK)"
        >
          <Smartphone className="w-3.5 h-3.5 text-amber-500 animate-pulse shrink-0" />
          <span className="hidden md:inline">Install App</span>
        </button>

        {/* Voice Recorder button in Navbar */}
        <button
          type="button"
          onClick={() => {
            haptics.medium();
            onOpenVoiceRecorder();
          }}
          className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shrink-0 ${tokens.accentBtn}`}
          title="Record Quick Client Voice Note"
        >
          <Mic className="w-3.5 h-3.5 shrink-0" />
          <span className="hidden md:inline">Voice Note</span>
        </button>

        {/* Theme Toggle Button */}
        <button
          type="button"
          onClick={() => {
            haptics.light();
            toggleTheme();
          }}
          className={`p-2 rounded-xl border transition-colors shrink-0 ${tokens.border} ${tokens.surfaceHover} ${tokens.textPrimary}`}
          title={
            isAutoTheme
              ? `Auto-sync active (${theme === 'dark' ? 'Dark' : 'Dawn'}) · Click to switch manually`
              : `Switch to ${theme === 'dark' ? 'Dawn mode' : 'Dark mode'}`
          }
        >
          {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-stone-700" />}
        </button>

        {/* User Account / Better-Auth Trigger */}
        <button
          type="button"
          onClick={() => {
            haptics.selection();
            openAuthModal();
          }}
          className={`flex items-center gap-1.5 p-1.5 sm:pr-2.5 rounded-xl border transition-colors shrink-0 ${tokens.border} ${tokens.surfaceHover}`}
        >
          {user ? (
            <>
              <img
                src={user.avatar}
                alt={user.name}
                className="w-6 h-6 rounded-full object-cover border border-stone-500/20 shrink-0"
              />
              <span className="text-xs font-medium max-w-[80px] truncate hidden md:inline">
                {user.name.split(' ')[0]}
              </span>
            </>
          ) : (
            <div className="flex items-center gap-1.5 text-xs">
              <ShieldCheck className="w-3.5 h-3.5 text-stone-400 shrink-0" />
              <span className="hidden sm:inline">Auth</span>
            </div>
          )}
        </button>
      </div>

      <DownloadApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </header>
  );
};
