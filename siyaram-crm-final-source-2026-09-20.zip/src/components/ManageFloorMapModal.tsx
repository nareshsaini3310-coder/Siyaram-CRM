import React, { useState, useEffect } from 'react';
import { X, Upload, Map, Link as LinkIcon, Trash2 } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { FloorMap } from '../types';
import { haptics } from '../utils/haptics';

interface ManageFloorMapModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (floorMap: Omit<FloorMap, 'id' | 'uploadedAt'>) => void;
  onDelete?: () => void;
  existingMap?: FloorMap;
}

export const ManageFloorMapModal: React.FC<ManageFloorMapModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  existingMap
}) => {
  const { theme, tokens, accent } = useTheme();
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [uploadMode, setUploadMode] = useState<'url' | 'file'>('url');
  const [category, setCategory] = useState<'floor_map' | 'agreement' | 'brochure' | 'video' | 'other'>('floor_map');

  useEffect(() => {
    if (existingMap) {
      setTitle(existingMap.title);
      setNotes(existingMap.notes || '');
      setFileUrl(existingMap.fileUrl);
      setCategory(existingMap.category || 'floor_map');
      setUploadMode('url');
    } else {
      setTitle('');
      setNotes('');
      setFileUrl('');
      setCategory('floor_map');
    }
  }, [existingMap, isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    if (!title.trim() || !fileUrl.trim()) {
      alert("Please provide both a title and an image URL.");
      return;
    }
    haptics.success();
    onSave({
      title: title.trim(),
      notes: notes.trim(),
      fileUrl: fileUrl.trim(),
      fileType: 'image',
      category,
    });
    onClose();
  };

  const handleDelete = () => {
    if (onDelete) {
      haptics.heavy();
      onDelete();
      onClose();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFileUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div className={`relative w-full max-w-md rounded-[28px] border overflow-hidden flex flex-col max-h-[90vh] shadow-2xl ${tokens.surface} ${tokens.border}`}>
        <div className={`px-6 py-4 border-b flex items-center justify-between ${tokens.border} ${tokens.bgSubtle}`}>
          <div className="flex items-center gap-3">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tokens.accentBgTint} ${tokens.accentText}`}>
              <Map className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-xl tracking-tight font-semibold">
                {existingMap ? 'Edit Document' : 'Add Document'}
              </h3>
            </div>
          </div>
          <button
            onClick={() => { haptics.selection(); onClose(); }}
            className={`p-2 rounded-full hover:bg-stone-500/10 transition-colors ${tokens.textSecondary} hover:${tokens.textPrimary}`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5">

          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1.5 ${tokens.textMuted}`}>Document Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as any)}
              className={`w-full px-4 py-3 rounded-xl border bg-transparent text-sm transition-colors ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
            >
              <option value="floor_map" className="bg-stone-900 text-white">Floor Map</option>
              <option value="agreement" className="bg-stone-900 text-white">Agreement</option>
              <option value="brochure" className="bg-stone-900 text-white">Brochure</option>
              <option value="video" className="bg-stone-900 text-white">Video</option>
              <option value="other" className="bg-stone-900 text-white">Other</option>
            </select>
          </div>

          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1.5 ${tokens.textMuted}`}>Document Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Tower B Floor Plan, Client Agreement..."
              className={`w-full px-4 py-3 rounded-xl border bg-transparent text-sm transition-colors ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
            />
          </div>

          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1.5 ${tokens.textMuted}`}>Image / Document File</label>
            <div className={`p-1 rounded-xl border flex gap-1 mb-3 ${tokens.border} ${tokens.bgSubtle}`}>
              <button
                type="button"
                onClick={() => { haptics.selection(); setUploadMode('url'); }}
                className={`flex-1 py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                  uploadMode === 'url' ? tokens.accentBgTint + ' ' + tokens.accentText + ' shadow-sm' : tokens.textSecondary + ' hover:' + tokens.textPrimary
                }`}
              >
                <LinkIcon className="w-3.5 h-3.5" /> URL
              </button>
              <button
                type="button"
                onClick={() => { haptics.selection(); setUploadMode('file'); }}
                className={`flex-1 py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                  uploadMode === 'file' ? tokens.accentBgTint + ' ' + tokens.accentText + ' shadow-sm' : tokens.textSecondary + ' hover:' + tokens.textPrimary
                }`}
              >
                <Upload className="w-3.5 h-3.5" /> Upload File
              </button>
            </div>
            
            {uploadMode === 'url' ? (
              <input
                type="url"
                value={fileUrl}
                onChange={(e) => setFileUrl(e.target.value)}
                placeholder="https://example.com/map.jpg"
                className={`w-full px-4 py-3 rounded-xl border bg-transparent text-sm transition-colors ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
              />
            ) : (
              <div className={`relative border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center text-center ${tokens.border}`}>
                <input
                  type="file"
                  accept="image/*,application/pdf,video/*"
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <Upload className={`w-6 h-6 mb-2 ${tokens.textMuted}`} />
                <p className={`text-xs font-semibold ${tokens.textPrimary}`}>Click or drag file to upload</p>
                <p className={`text-[10px] mt-1 ${tokens.textMuted}`}>Supported: Images, PDFs, and Videos</p>
              </div>
            )}
            {fileUrl && uploadMode === 'file' && (
              <div className="mt-3 relative rounded-xl overflow-hidden border border-stone-500/30">
                {(fileUrl.startsWith('data:video/') || fileUrl.match(/\.(mp4|webm|ogg|mov)$/i)) ? (
                  <video src={fileUrl} className="w-full h-32 object-cover" controls muted />
                ) : (
                  <img src={fileUrl} alt="Preview" className="w-full h-32 object-cover" />
                )}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity pointer-events-none">
                   <p className="text-white text-xs font-bold">Document Uploaded</p>
                </div>
              </div>
            )}
          </div>

          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1.5 ${tokens.textMuted}`}>Additional Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="E.g. Carpet Area: 1250 sqft. East facing."
              className={`w-full px-4 py-3 rounded-xl border bg-transparent text-sm transition-colors ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400 resize-none h-24`}
            />
          </div>
        </div>

        <div className={`px-6 py-4 border-t flex items-center justify-between gap-3 ${tokens.border} ${tokens.bgSubtle}`}>
          {existingMap && onDelete ? (
            <button
              type="button"
              onClick={handleDelete}
              className="px-4 py-2 rounded-xl text-xs font-bold text-red-500 hover:bg-red-500/10 transition-colors flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" /> Delete
            </button>
          ) : <div></div>}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => { haptics.selection(); onClose(); }}
              className={`px-4 py-2 rounded-xl text-xs font-bold border ${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary} transition-colors`}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${tokens.accentBtn}`}
            >
              {existingMap ? 'Save Changes' : 'Add Document'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
