import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Server, Smartphone, Check, X } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';

export const SyncConflictModal: React.FC = () => {
  const { theme, tokens } = useTheme();
  const { syncConflict, resolveConflict } = useData();

  if (!syncConflict) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-stone-900/40 backdrop-blur-sm"
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className={`relative w-full max-w-lg p-6 rounded-[24px] shadow-2xl border ${
            theme === 'dark' ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-200'
          }`}
        >
          {/* Header */}
          <div className="flex items-start gap-4 mb-6">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 bg-amber-500/10 border border-amber-500/20`}>
              <AlertTriangle className="w-6 h-6 text-amber-500" />
            </div>
            <div>
              <h2 className="font-display text-xl tracking-tight font-semibold text-amber-500">
                Version Conflict Detected
              </h2>
              <p className={`text-sm mt-1 ${tokens.textSecondary}`}>
                The server has a different version of <span className="font-semibold text-inherit">{syncConflict.itemType}</span>. Please choose which version to keep.
              </p>
            </div>
          </div>

          {/* Options Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            {/* Local Version */}
            <div className={`p-4 rounded-2xl border flex flex-col gap-3 ${tokens.surfaceElevated} ${tokens.border}`}>
              <div className="flex items-center gap-2">
                <Smartphone className={`w-4 h-4 ${tokens.textSecondary}`} />
                <span className={`text-xs font-mono uppercase tracking-wider font-semibold ${tokens.textMuted}`}>
                  Your Device (Local)
                </span>
              </div>
              <div className={`flex-1 text-sm whitespace-pre-line font-medium ${tokens.textPrimary}`}>
                {syncConflict.localPreview}
              </div>
              <button
                onClick={() => resolveConflict('local')}
                className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all ${tokens.accentBtn}`}
              >
                Keep Local
              </button>
            </div>

            {/* Server Version */}
            <div className={`p-4 rounded-2xl border flex flex-col gap-3 ${tokens.surfaceElevated} ${tokens.border}`}>
              <div className="flex items-center gap-2">
                <Server className={`w-4 h-4 ${tokens.textSecondary}`} />
                <span className={`text-xs font-mono uppercase tracking-wider font-semibold ${tokens.textMuted}`}>
                  Cloud (Server)
                </span>
              </div>
              <div className={`flex-1 text-sm whitespace-pre-line font-medium ${tokens.textPrimary}`}>
                {syncConflict.serverPreview}
              </div>
              <button
                onClick={() => resolveConflict('server')}
                className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all border hover:bg-stone-500/10 ${tokens.border} ${tokens.textPrimary}`}
              >
                Keep Server
              </button>
            </div>
          </div>

          <p className={`text-[10px] text-center font-mono ${tokens.textMuted}`}>
            The discarded version will be permanently overwritten.
          </p>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
