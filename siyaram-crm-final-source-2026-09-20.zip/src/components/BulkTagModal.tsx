import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Tag as TagIcon,
  Plus,
  Minus,
  Check,
  Search,
  Sparkles,
  Users,
  CheckCircle2,
  Trash2,
  AlertCircle
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { haptics } from '../utils/haptics';
import { Tag } from '../types';

interface BulkTagModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedClientIds: string[];
  initialMode?: 'apply' | 'remove';
  onSuccess: (message: string) => void;
}

const PRESET_COLORS = [
  '#E9C46A', // Amber / Gold
  '#2A9D8F', // Teal
  '#E76F51', // Terracotta / Coral
  '#264653', // Deep Slate
  '#10B981', // Emerald
  '#3B82F6', // Sapphire Blue
  '#8B5CF6', // Purple
  '#EC4899', // Pink
];

export const BulkTagModal: React.FC<BulkTagModalProps> = ({
  isOpen,
  onClose,
  selectedClientIds,
  initialMode = 'apply',
  onSuccess,
}) => {
  const { theme, tokens } = useTheme();
  const { clients, tags, updateClient, addTag } = useData();

  const [mode, setMode] = useState<'apply' | 'remove'>(initialMode);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTagIds, setSelectedTagIds] = useState<string[]>([]);
  const [isCreatingNewTag, setIsCreatingNewTag] = useState(false);
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState(PRESET_COLORS[0]);

  // Sync mode when initialMode changes or modal opens
  React.useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setSelectedTagIds([]);
      setSearchQuery('');
      setIsCreatingNewTag(false);
      setNewTagName('');
    }
  }, [isOpen, initialMode]);

  if (!isOpen) return null;

  const selectedClients = clients.filter((c) => selectedClientIds.includes(c.id));
  const totalSelectedCount = selectedClients.length;

  // Filter tags by search query
  const filteredTags = tags.filter((t) =>
    t.name.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  // Calculate tag presence among selected clients
  const getTagPresence = (tagId: string) => {
    const clientsWithTag = selectedClients.filter((c) => c.tagIds?.includes(tagId));
    return {
      count: clientsWithTag.length,
      isAll: clientsWithTag.length === totalSelectedCount && totalSelectedCount > 0,
      isPartial: clientsWithTag.length > 0 && clientsWithTag.length < totalSelectedCount,
      isNone: clientsWithTag.length === 0,
    };
  };

  const handleToggleTag = (tagId: string) => {
    haptics.selection();
    setSelectedTagIds((prev) =>
      prev.includes(tagId) ? prev.filter((id) => id !== tagId) : [...prev, tagId]
    );
  };

  // Execute bulk action
  const handleExecute = () => {
    if (selectedTagIds.length === 0 || selectedClients.length === 0) return;

    if (mode === 'apply') {
      // Apply selected tags to all selected clients
      selectedClients.forEach((client) => {
        const existingTags = client.tagIds || [];
        const mergedTags = Array.from(new Set([...existingTags, ...selectedTagIds]));
        updateClient(client.id, { tagIds: mergedTags });
      });
      haptics.success();
      onSuccess(
        `Applied ${selectedTagIds.length} tag${selectedTagIds.length > 1 ? 's' : ''} to ${totalSelectedCount} client${totalSelectedCount > 1 ? 's' : ''}`
      );
    } else {
      // Remove selected tags from all selected clients
      selectedClients.forEach((client) => {
        const existingTags = client.tagIds || [];
        const filteredTags = existingTags.filter((id) => !selectedTagIds.includes(id));
        updateClient(client.id, { tagIds: filteredTags });
      });
      haptics.success();
      onSuccess(
        `Removed ${selectedTagIds.length} tag${selectedTagIds.length > 1 ? 's' : ''} from ${totalSelectedCount} client${totalSelectedCount > 1 ? 's' : ''}`
      );
    }

    onClose();
  };

  // Create new tag and automatically apply to selected clients
  const handleCreateAndApplyTag = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newTagName.trim();
    if (!trimmed) return;

    // Check if tag already exists
    const existing = tags.find((t) => t.name.toLowerCase() === trimmed.toLowerCase());
    let targetTagId: string;

    if (existing) {
      targetTagId = existing.id;
    } else {
      const created = addTag({
        name: trimmed,
        color: newTagColor,
        description: 'Created via Bulk Actions',
      });
      targetTagId = created.id;
    }

    // Apply immediately to all selected clients
    selectedClients.forEach((client) => {
      const existingTags = client.tagIds || [];
      if (!existingTags.includes(targetTagId)) {
        updateClient(client.id, { tagIds: [...existingTags, targetTagId] });
      }
    });

    haptics.success();
    onSuccess(`Created "${trimmed}" and applied to ${totalSelectedCount} clients`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-md animate-fadeIn">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className={`w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] ${
          theme === 'dark'
            ? 'bg-[#181a20] border-white/10 text-stone-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-inherit flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                mode === 'apply'
                  ? 'bg-emerald-500/15 text-emerald-500 border border-emerald-500/30'
                  : 'bg-rose-500/15 text-rose-500 border border-rose-500/30'
              }`}
            >
              <TagIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold tracking-tight">
                Bulk Tag Manager
              </h3>
              <div className="flex items-center gap-1.5 text-xs text-stone-400 font-mono">
                <Users className="w-3.5 h-3.5 text-amber-500" />
                <span>
                  {totalSelectedCount} client{totalSelectedCount > 1 ? 's' : ''} selected
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-100 hover:bg-stone-500/15 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Mode Toggle (Apply vs Remove) */}
        <div className="p-3 sm:px-5 sm:pt-4 border-b border-inherit bg-stone-500/5">
          <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-stone-500/10 border border-inherit">
            <button
              type="button"
              onClick={() => {
                haptics.selection();
                setMode('apply');
                setSelectedTagIds([]);
              }}
              className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                mode === 'apply'
                  ? 'bg-emerald-500 text-white shadow-md font-bold'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Apply Tags to Selected</span>
            </button>

            <button
              type="button"
              onClick={() => {
                haptics.selection();
                setMode('remove');
                setSelectedTagIds([]);
              }}
              className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                mode === 'remove'
                  ? 'bg-rose-500 text-white shadow-md font-bold'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <Minus className="w-4 h-4 stroke-[2.5]" />
              <span>Remove Tags from Selected</span>
            </button>
          </div>
        </div>

        {/* Tag Search & Filter */}
        <div className="px-4 sm:px-5 pt-3 pb-2 flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-stone-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter tags by name..."
              className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500/30 ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
            />
          </div>

          {mode === 'apply' && (
            <button
              type="button"
              onClick={() => {
                haptics.selection();
                setIsCreatingNewTag((prev) => !prev);
              }}
              className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                isCreatingNewTag
                  ? 'bg-amber-500/20 text-amber-500 border-amber-500/40'
                  : `${tokens.surfaceElevated} ${tokens.border} text-stone-400 hover:text-amber-500`
              }`}
              title="Create new tag"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">New Tag</span>
            </button>
          )}
        </div>

        {/* Quick New Tag Inline Creator */}
        <AnimatePresence>
          {isCreatingNewTag && mode === 'apply' && (
            <motion.form
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              onSubmit={handleCreateAndApplyTag}
              className="px-4 sm:px-5 py-3 border-b border-inherit bg-amber-500/5 overflow-hidden"
            >
              <div className="text-xs font-bold text-amber-500 mb-2 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Create & Apply New Tag</span>
              </div>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <input
                  type="text"
                  value={newTagName}
                  onChange={(e) => setNewTagName(e.target.value)}
                  placeholder="e.g. VIP NRI, High Intent"
                  className={`flex-1 px-3 py-1.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500/30 ${tokens.surfaceElevated} ${tokens.border}`}
                  autoFocus
                />

                {/* Swatches */}
                <div className="flex items-center gap-1">
                  {PRESET_COLORS.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setNewTagColor(color)}
                      className={`w-6 h-6 rounded-lg transition-transform ${
                        newTagColor === color ? 'scale-110 ring-2 ring-white ring-offset-1' : 'opacity-70 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>

                <button
                  type="submit"
                  disabled={!newTagName.trim()}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 disabled:opacity-50 transition-all cursor-pointer"
                >
                  Create & Apply
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>

        {/* Tag Selection List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-2">
          {filteredTags.length === 0 ? (
            <div className="p-8 text-center text-stone-400">
              <TagIcon className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p className="text-xs font-medium">No tags matching "{searchQuery}"</p>
            </div>
          ) : (
            filteredTags.map((tag) => {
              const isSelected = selectedTagIds.includes(tag.id);
              const presence = getTagPresence(tag.id);

              return (
                <div
                  key={tag.id}
                  onClick={() => handleToggleTag(tag.id)}
                  className={`p-3 rounded-2xl border flex items-center justify-between gap-3 transition-all cursor-pointer ${
                    isSelected
                      ? mode === 'apply'
                        ? 'bg-emerald-500/15 border-emerald-500/50 shadow-sm'
                        : 'bg-rose-500/15 border-rose-500/50 shadow-sm'
                      : `${tokens.surfaceElevated} ${tokens.border} hover:bg-stone-500/10`
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Checkbox indicator */}
                    <div
                      className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                        isSelected
                          ? mode === 'apply'
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'bg-rose-500 border-rose-500 text-white'
                          : 'border-stone-400/40'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>

                    {/* Tag badge & name */}
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-3 h-3 rounded-full shrink-0"
                        style={{ backgroundColor: tag.color }}
                      />
                      <span className="font-semibold text-xs truncate">
                        {tag.name}
                      </span>
                    </div>
                  </div>

                  {/* Presence indicator badge */}
                  <div className="shrink-0 flex items-center gap-1.5 text-[11px] font-mono">
                    {presence.isAll ? (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25">
                        On all {totalSelectedCount}
                      </span>
                    ) : presence.isPartial ? (
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/25">
                        On {presence.count}/{totalSelectedCount}
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full bg-stone-500/10 text-stone-400">
                        Not applied
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer / Action Button */}
        <div className="p-4 sm:p-5 border-t border-inherit flex items-center justify-between gap-3 bg-stone-500/5">
          <div className="text-xs font-mono text-stone-400">
            {selectedTagIds.length} tag{selectedTagIds.length !== 1 ? 's' : ''} selected
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-stone-400 hover:text-stone-200 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleExecute}
              disabled={selectedTagIds.length === 0}
              className={`px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-40 disabled:cursor-not-allowed ${
                mode === 'apply'
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-white shadow-emerald-500/20'
                  : 'bg-rose-500 hover:bg-rose-400 text-white shadow-rose-500/20'
              }`}
            >
              {mode === 'apply' ? (
                <>
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                  <span>
                    Apply to {totalSelectedCount} Client{totalSelectedCount !== 1 ? 's' : ''}
                  </span>
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4" />
                  <span>
                    Remove from {totalSelectedCount} Client{totalSelectedCount !== 1 ? 's' : ''}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
