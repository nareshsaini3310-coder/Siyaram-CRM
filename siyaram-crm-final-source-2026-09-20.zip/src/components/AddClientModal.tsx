import React, { useState } from 'react';
import {
  X,
  User,
  Phone,
  MessageSquare,
  MapPin,
  Building2,
  Calendar,
  Clock,
  Check,
  Sparkles,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';
import { useData } from '../context/DataContext';
import { FollowUpType, ClientStatus } from '../types';

interface AddClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClientCreated?: (newClientId: string) => void;
  initialProjectId?: string;
}

export const AddClientModal: React.FC<AddClientModalProps> = ({
  isOpen,
  onClose,
  onClientCreated,
  initialProjectId,
}) => {
  const { theme, tokens } = useTheme();
  const { addClient, addFollowUp, projects } = useData();

  // Basic Information
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('+91 ');
  const [whatsappNumber, setWhatsappNumber] = useState('+91 ');
  const [isSameAsPhone, setIsSameAsPhone] = useState(true);
  const [location, setLocation] = useState('');
  const [projectId, setProjectId] = useState(initialProjectId || (projects[0]?.id || ''));
  const [role, setRole] = useState('Investor / Buyer');
  const [company, setCompany] = useState('');
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<ClientStatus>('active');
  const [notes, setNotes] = useState('');

  // Follow-up Scheduling Logic
  const [hasFollowUp, setHasFollowUp] = useState(true);
  const [followUpType, setFollowUpType] = useState<FollowUpType>('call');
  const [followUpDate, setFollowUpDate] = useState(() => {
    // Default tomorrow
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  });
  const [followUpTime, setFollowUpTime] = useState('11:00 AM');
  const [followUpNote, setFollowUpNote] = useState('');
  const [activePreset, setActivePreset] = useState<string>('tomorrow');

  if (!isOpen) return null;

  // Preset calculation helper
  const handleApplyPreset = (presetKey: string) => {
    setActivePreset(presetKey);
    const now = new Date();

    if (presetKey === '2hours') {
      // 2 hours later today
      const later = new Date(now.getTime() + 2 * 60 * 60 * 1000);
      setFollowUpDate(later.toISOString().split('T')[0]);
      const hours = later.getHours();
      const minutes = later.getMinutes();
      const ampm = hours >= 12 ? 'PM' : 'AM';
      const formattedHours = hours % 12 || 12;
      const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
      setFollowUpTime(`${formattedHours}:${formattedMinutes} ${ampm}`);
      if (!followUpNote) setFollowUpNote('Immediate call back in 2 hours for price inquiry');
    } else if (presetKey === 'tomorrow') {
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      setFollowUpDate(tomorrow.toISOString().split('T')[0]);
      setFollowUpTime('11:00 AM');
      if (!followUpNote) setFollowUpNote('Follow up tomorrow morning regarding site visit & layout plans');
    } else if (presetKey === '3days') {
      const threeDays = new Date(now);
      threeDays.setDate(threeDays.getDate() + 3);
      setFollowUpDate(threeDays.toISOString().split('T')[0]);
      setFollowUpTime('03:30 PM');
      if (!followUpNote) setFollowUpNote('Follow up in 3 days after client reviews the brochure');
    } else if (presetKey === 'nextweek') {
      const nextWk = new Date(now);
      nextWk.setDate(nextWk.getDate() + 7);
      setFollowUpDate(nextWk.toISOString().split('T')[0]);
      setFollowUpTime('11:30 AM');
      if (!followUpNote) setFollowUpNote('Next week status review for payment and documentation');
    } else if (presetKey === '10days') {
      const tenDays = new Date(now);
      tenDays.setDate(tenDays.getDate() + 10);
      setFollowUpDate(tenDays.toISOString().split('T')[0]);
      setFollowUpTime('04:00 PM');
      if (!followUpNote) setFollowUpNote('Follow-up in 10 days for registry & allotment approval');
    } else if (presetKey === 'nextmonth') {
      const nextMo = new Date(now);
      nextMo.setDate(nextMo.getDate() + 30);
      setFollowUpDate(nextMo.toISOString().split('T')[0]);
      setFollowUpTime('12:00 PM');
      if (!followUpNote) setFollowUpNote('Next month long-term investor follow-up');
    }
  };

  const handlePhoneChange = (val: string) => {
    setPhone(val);
    if (isSameAsPhone) {
      setWhatsappNumber(val);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    haptics.success();
    e.preventDefault();
    if (!name.trim()) return;

    const actualWhatsapp = isSameAsPhone ? phone : (whatsappNumber || phone);
    const chosenProject = projects.find((p) => p.id === projectId);

    // 1. Create client
    const newClient = addClient({
      name: name.trim(),
      phone: phone.trim(),
      whatsappNumber: actualWhatsapp.trim(),
      location: location.trim() || 'Sector 84, NCR',
      role: role.trim() || 'Real Estate Buyer',
      company: company.trim() || (chosenProject ? `Interested in ${chosenProject.title}` : 'Siyaram Enclave Investor'),
      email: email.trim() || `${name.toLowerCase().replace(/\s+/g, '.')}@client.in`,
      status,
      projectIds: projectId ? [projectId] : [],
      tagIds: ['tag-1'], // defaults to High Priority
      lastContactDate: new Date().toISOString().split('T')[0],
      notes: notes.trim() || `Client interested in Siyaram development. Location: ${location.trim() || 'NCR'}.`,
      avatar: `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 1000000)}?auto=format&fit=crop&w=400&q=80`,
      preferredContact: followUpType === 'whatsapp' ? 'whatsapp' : 'phone',
      nextFollowUpDate: hasFollowUp ? followUpDate : undefined,
      nextFollowUpTime: hasFollowUp ? followUpTime : undefined,
      nextFollowUpType: hasFollowUp ? followUpType : undefined,
      nextFollowUpNote: hasFollowUp ? followUpNote.trim() : undefined,
    });

    // 2. Automatically register the scheduled follow-up
    if (hasFollowUp && followUpDate) {
      addFollowUp({
        title: `${followUpType === 'call' ? 'Call' : followUpType === 'whatsapp' ? 'WhatsApp' : 'Site Meeting'}: ${newClient.name} (${chosenProject?.title || 'Siyaram'})`,
        clientId: newClient.id,
        projectId: projectId || undefined,
        type: followUpType,
        priority: 'high',
        dueDate: followUpDate,
        scheduledTime: followUpTime,
        customNumber: followUpType === 'whatsapp' ? actualWhatsapp : phone,
        notes: followUpNote.trim() || `Follow up with ${newClient.name} regarding project inquiry and site booking.`,
      });
    }

    if (onClientCreated) {
      onClientCreated(newClient.id);
    }

    onClose();
  };

  // Format preview date nicely
  const getReadableDatePreview = (dateStr: string) => {
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
        return d.toLocaleDateString('en-IN', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        });
      }
    } catch {}
    return dateStr;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
      {/* Apple-style Glass Modal Container */}
      <div
        className={`relative w-full max-w-2xl rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[92vh] ${
          theme === 'dark' ? 'tactile-card-dark bg-[#121418]/95' : 'tactile-card-dawn'
        }`}
      >
        {/* Header Bar */}
        <div
          className={`px-6 py-4 border-b flex items-center justify-between backdrop-blur-xl ${
            theme === 'dark' ? 'border-white/10 bg-white/5' : 'border-slate-200/80 bg-white/60'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center text-slate-950 font-bold shadow-md">
              <User className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-xl sm:text-2xl tracking-tight font-bold">
                  Add New Client
                </h2>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full font-bold bg-amber-500/20 text-amber-600 dark:text-amber-400">
                  Siyaram CRM
                </span>
              </div>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Client details, mobile number, project, location & next follow-up schedule
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className={`p-2 rounded-xl transition-all ${
              theme === 'dark'
                ? 'hover:bg-white/10 text-stone-400 hover:text-white'
                : 'hover:bg-slate-100 text-slate-500 hover:text-slate-900'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6">
          {/* Section 1: Core Client Information */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              <ShieldCheck className="w-4 h-4" />
              <span>1. Client & Contact Details (क्लाइंट व संपर्क)</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Client Name */}
              <div>
                <label className={`block text-xs font-semibold mb-1.5 ${tokens.textPrimary}`}>
                  Client Full Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Ramesh Chandra / Vikram Singhania"
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                      theme === 'dark'
                        ? 'bg-black/30 border-white/15 focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20'
                        : 'bg-white/80 border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 shadow-xs'
                    }`}
                  />
                </div>
              </div>

              {/* Location */}
              <div>
                <label className={`block text-xs font-semibold mb-1.5 ${tokens.textPrimary}`}>
                  Client Location / City <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Sector 84 Gurugram, Delhi NCR, Noida"
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                      theme === 'dark'
                        ? 'bg-black/30 border-white/15 focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20'
                        : 'bg-white/80 border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 shadow-xs'
                    }`}
                  />
                </div>
              </div>

              {/* Calling Phone Number */}
              <div>
                <label className={`block text-xs font-semibold mb-1.5 ${tokens.textPrimary}`}>
                  Mobile Number (Calling) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => handlePhoneChange(e.target.value)}
                    placeholder="+91 98200 41122"
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm font-medium font-mono transition-all ${
                      theme === 'dark'
                        ? 'bg-black/30 border-white/15 focus:border-amber-400'
                        : 'bg-white/80 border-slate-200 focus:border-blue-500 shadow-xs'
                    }`}
                  />
                </div>
              </div>

              {/* WhatsApp Number */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className={`text-xs font-semibold ${tokens.textPrimary}`}>
                    WhatsApp Number (मनचाहा नंबर)
                  </label>
                  <label className="flex items-center gap-1.5 text-[11px] cursor-pointer text-emerald-600 dark:text-emerald-400 font-medium">
                    <input
                      type="checkbox"
                      checked={isSameAsPhone}
                      onChange={(e) => {
                        setIsSameAsPhone(e.target.checked);
                        if (e.target.checked) setWhatsappNumber(phone);
                      }}
                      className="rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Same as Mobile</span>
                  </label>
                </div>
                <div className="relative">
                  <MessageSquare className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-500" />
                  <input
                    type="text"
                    disabled={isSameAsPhone}
                    value={isSameAsPhone ? phone : whatsappNumber}
                    onChange={(e) => setWhatsappNumber(e.target.value)}
                    placeholder="+91 98200 41122"
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm font-medium font-mono transition-all ${
                      isSameAsPhone
                        ? 'opacity-70 bg-slate-100 dark:bg-black/20 border-dashed border-slate-300 dark:border-white/10'
                        : theme === 'dark'
                        ? 'bg-black/30 border-white/15 focus:border-emerald-400'
                        : 'bg-white/80 border-slate-200 focus:border-emerald-500 shadow-xs'
                    }`}
                  />
                </div>
              </div>
            </div>

            {/* Project & Client Category */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              {/* Associated Project */}
              <div>
                <label className={`block text-xs font-semibold mb-1.5 ${tokens.textPrimary}`}>
                  Interested Project (प्रोजेक्ट)
                </label>
                <div className="relative">
                  <Building2 className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <select
                    value={projectId}
                    onChange={(e) => setProjectId(e.target.value)}
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                      theme === 'dark'
                        ? 'bg-black/40 border-white/15 text-white'
                        : 'bg-white/80 border-slate-200 text-slate-900 shadow-xs'
                    }`}
                  >
                    {projects.map((p) => (
                      <option key={p.id} value={p.id} className="bg-white text-slate-900 dark:bg-stone-900 dark:text-white">
                        {p.title} ({p.projectType === 'plot' ? 'Plotted Land' : p.projectType === 'high_rises' ? 'High-Rise Towers' : 'Land Parcel'})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Status / Category */}
              <div>
                <label className={`block text-xs font-semibold mb-1.5 ${tokens.textPrimary}`}>
                  Client Tier / Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as ClientStatus)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                    theme === 'dark'
                      ? 'bg-black/40 border-white/15 text-white'
                      : 'bg-white/80 border-slate-200 text-slate-900 shadow-xs'
                  }`}
                >
                  <option value="vip" className="bg-white text-slate-900 dark:bg-stone-900 dark:text-white">
                    ⭐ VIP High-Net-Worth Investor
                  </option>
                  <option value="active" className="bg-white text-slate-900 dark:bg-stone-900 dark:text-white">
                    Active Serious Buyer
                  </option>
                  <option value="lead" className="bg-white text-slate-900 dark:bg-stone-900 dark:text-white">
                    New Lead / Site Inquiry
                  </option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Next Follow-Up Schedule (अगला फॉलो-अप) */}
          <div
            className={`p-4 sm:p-5 rounded-2xl border transition-all ${
              theme === 'dark'
                ? 'bg-white/5 border-white/10'
                : 'bg-white/90 border-slate-200/90 shadow-md'
            }`}
          >
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-inherit">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="text-xs font-bold font-mono uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                  2. Next Follow-Up (अगला फॉलो-अप कब होना है)
                </span>
              </div>
              <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasFollowUp}
                  onChange={(e) => setHasFollowUp(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>Schedule Next Follow-Up Call/Message</span>
              </label>
            </div>

            {hasFollowUp && (
              <div className="space-y-4">
                {/* Smart Presets Bar */}
                <div>
                  <label className={`block text-[11px] font-semibold uppercase tracking-wider mb-2 ${tokens.textSecondary}`}>
                    Quick Timing Presets (त्वरित चयन):
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                    <button
                      type="button"
                      onClick={() => handleApplyPreset('2hours')}
                      className={`px-2.5 py-2 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1 cursor-pointer transition-all ${
                        activePreset === '2hours'
                          ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                          : theme === 'dark'
                          ? 'bg-white/5 border-white/10 text-stone-300 hover:bg-white/10'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
                      }`}
                    >
                      <span>⚡ 2 Hours</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleApplyPreset('tomorrow')}
                      className={`px-2.5 py-2 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1 cursor-pointer transition-all ${
                        activePreset === 'tomorrow'
                          ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                          : theme === 'dark'
                          ? 'bg-white/5 border-white/10 text-stone-300 hover:bg-white/10'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
                      }`}
                    >
                      <span>🌅 Tomorrow</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleApplyPreset('3days')}
                      className={`px-2.5 py-2 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1 cursor-pointer transition-all ${
                        activePreset === '3days'
                          ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                          : theme === 'dark'
                          ? 'bg-white/5 border-white/10 text-stone-300 hover:bg-white/10'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
                      }`}
                    >
                      <span>📅 In 3 Days</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleApplyPreset('nextweek')}
                      className={`px-2.5 py-2 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1 cursor-pointer transition-all ${
                        activePreset === 'nextweek'
                          ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                          : theme === 'dark'
                          ? 'bg-white/5 border-white/10 text-stone-300 hover:bg-white/10'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
                      }`}
                    >
                      <span>🗓️ Next Week</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleApplyPreset('10days')}
                      className={`px-2.5 py-2 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1 cursor-pointer transition-all ${
                        activePreset === '10days'
                          ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                          : theme === 'dark'
                          ? 'bg-white/5 border-white/10 text-stone-300 hover:bg-white/10'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
                      }`}
                    >
                      <span>🔟 10 Din Baad</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleApplyPreset('nextmonth')}
                      className={`px-2.5 py-2 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1 cursor-pointer transition-all ${
                        activePreset === 'nextmonth'
                          ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                          : theme === 'dark'
                          ? 'bg-white/5 border-white/10 text-stone-300 hover:bg-white/10'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
                      }`}
                    >
                      <span>📆 1 Month</span>
                    </button>
                  </div>
                </div>

                {/* Date & Time Inputs */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Calendar Date Picker */}
                  <div>
                    <label className={`block text-xs font-semibold mb-1.5 ${tokens.textPrimary}`}>
                      Follow-up Date (तारीख / कैलेंडर)
                    </label>
                    <div className="relative">
                      <Calendar className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="date"
                        required={hasFollowUp}
                        value={followUpDate}
                        onChange={(e) => {
                          setFollowUpDate(e.target.value);
                          setActivePreset('custom');
                        }}
                        className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                          theme === 'dark'
                            ? 'bg-black/30 border-white/15 text-white'
                            : 'bg-white border-slate-200 text-slate-900 shadow-xs'
                        }`}
                      />
                    </div>
                    <p className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 font-mono font-medium">
                      Selected: {getReadableDatePreview(followUpDate)}
                    </p>
                  </div>

                  {/* Time Picker */}
                  <div>
                    <label className={`block text-xs font-semibold mb-1.5 ${tokens.textPrimary}`}>
                      Follow-up Time (समय)
                    </label>
                    <div className="relative">
                      <Clock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={followUpTime}
                        onChange={(e) => {
                          setFollowUpTime(e.target.value);
                          setActivePreset('custom');
                        }}
                        placeholder="e.g. 11:30 AM or 04:00 PM"
                        className={`w-full pl-10 pr-3.5 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                          theme === 'dark'
                            ? 'bg-black/30 border-white/15 text-white'
                            : 'bg-white border-slate-200 text-slate-900 shadow-xs'
                        }`}
                      />
                    </div>
                    {/* Quick time pills */}
                    <div className="flex items-center gap-1.5 mt-1.5">
                      {['10:00 AM', '12:00 PM', '03:30 PM', '06:00 PM'].map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setFollowUpTime(t)}
                          className={`text-[10px] font-mono px-2 py-0.5 rounded-md border transition-colors ${
                            followUpTime === t
                              ? 'bg-emerald-500/20 text-emerald-600 border-emerald-500/40 font-bold'
                              : 'border-slate-200 text-slate-500 hover:text-slate-800'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Follow-up Type / Channel */}
                <div>
                  <label className={`block text-xs font-semibold mb-1.5 ${tokens.textPrimary}`}>
                    Communication Channel (बातचीत का माध्यम)
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setFollowUpType('call')}
                      className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-1.5 text-xs font-semibold transition-all ${
                        followUpType === 'call'
                          ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 border-amber-500 shadow-xs'
                          : 'border-slate-200 text-slate-600 dark:text-stone-300'
                      }`}
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Phone Call (कॉल)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setFollowUpType('whatsapp')}
                      className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-1.5 text-xs font-semibold transition-all ${
                        followUpType === 'whatsapp'
                          ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border-emerald-500 shadow-xs'
                          : 'border-slate-200 text-slate-600 dark:text-stone-300'
                      }`}
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>WhatsApp (व्हाट्सऐप)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setFollowUpType('meeting')}
                      className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-1.5 text-xs font-semibold transition-all ${
                        followUpType === 'meeting'
                          ? 'bg-purple-500/20 text-purple-600 dark:text-purple-400 border-purple-500 shadow-xs'
                          : 'border-slate-200 text-slate-600 dark:text-stone-300'
                      }`}
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      <span>Site Visit (मीटिंग)</span>
                    </button>
                  </div>
                </div>

                {/* Follow-up Note */}
                <div>
                  <label className={`block text-xs font-semibold mb-1 ${tokens.textPrimary}`}>
                    Follow-up Agenda / Note (बातचीत का विषय)
                  </label>
                  <input
                    type="text"
                    value={followUpNote}
                    onChange={(e) => setFollowUpNote(e.target.value)}
                    placeholder="e.g. Call regarding Siyaram 250 Sq. Yd. plot rate, send brochure on WhatsApp"
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-medium transition-all ${
                      theme === 'dark'
                        ? 'bg-black/30 border-white/15 text-white'
                        : 'bg-white border-slate-200 text-slate-900 shadow-xs'
                    }`}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Section 3: Additional Notes */}
          <div>
            <label className={`block text-xs font-semibold mb-1 ${tokens.textPrimary}`}>
              Internal Remarks & Requirements (टिप्पणी व जरूरतें)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Interested in High-Rise Tower A penthouse or 500 Sq. Yd. corner plot in Siyaram development."
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs leading-relaxed transition-all ${
                theme === 'dark'
                  ? 'bg-black/30 border-white/15 text-white'
                  : 'bg-white border-slate-200 text-slate-900 shadow-xs'
              }`}
            />
          </div>

          {/* Modal Actions */}
          <div className="pt-4 border-t border-slate-200/80 dark:border-white/10 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className={`px-5 py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                theme === 'dark'
                  ? 'border-white/15 text-stone-300 hover:bg-white/10'
                  : 'border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              Cancel
            </button>

            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-slate-900 hover:bg-black dark:bg-amber-500 dark:hover:bg-amber-400 dark:text-slate-950 flex items-center gap-2 shadow-lg transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Save Client & Set Follow-Up</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
