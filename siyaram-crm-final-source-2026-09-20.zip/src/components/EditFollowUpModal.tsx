import React, { useState, useEffect } from 'react';
import {
  X,
  Calendar,
  Clock,
  Phone,
  MessageSquare,
  Send,
  User,
  Building,
  Check,
  Flag
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { FollowUp, CommChannel } from '../types';

interface EditFollowUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  followUp?: FollowUp | null; // if null, creating new
  initialClientId?: string;
  initialProjectId?: string;
}

export const EditFollowUpModal: React.FC<EditFollowUpModalProps> = ({
  isOpen,
  onClose,
  followUp,
  initialClientId,
  initialProjectId,
}) => {
  const { tokens } = useTheme();
  const { addFollowUp, updateFollowUp, clients, projects } = useData();

  const [title, setTitle] = useState(followUp?.title || '');
  const [channel, setChannel] = useState<CommChannel>(followUp?.channel || 'call');
  const [dueDate, setDueDate] = useState(followUp?.dueDate || new Date().toISOString().split('T')[0]);
  const [scheduledTime, setScheduledTime] = useState(followUp?.scheduledTime || '11:00 AM');
  const [priority, setPriority] = useState<'high' | 'medium' | 'low'>(followUp?.priority || 'high');
  const [clientId, setClientId] = useState(followUp?.clientId || initialClientId || '');
  const [projectId, setProjectId] = useState(followUp?.projectId || initialProjectId || '');
  const [customNumber, setCustomNumber] = useState(followUp?.customNumber || '');
  const [notes, setNotes] = useState(followUp?.notes || '');

  useEffect(() => {
    if (followUp) {
      setTitle(followUp.title);
      setChannel(followUp.channel || 'call');
      setDueDate(followUp.dueDate);
      setScheduledTime(followUp.scheduledTime || '11:00 AM');
      setPriority(followUp.priority);
      setClientId(followUp.clientId || '');
      setProjectId(followUp.projectId || '');
      setCustomNumber(followUp.customNumber || '');
      setNotes(followUp.notes || '');
    } else {
      setTitle('');
      setChannel('call');
      setDueDate(new Date().toISOString().split('T')[0]);
      setScheduledTime('11:00 AM');
      setPriority('high');
      setClientId(initialClientId || '');
      setProjectId(initialProjectId || '');
      setCustomNumber('');
      setNotes('');
    }
  }, [followUp, initialClientId, initialProjectId]);

  // If client selected and customNumber empty, prefill client phone
  useEffect(() => {
    if (clientId) {
      const cli = clients.find((c) => c.id === clientId);
      if (cli && !customNumber) {
        setCustomNumber(channel === 'whatsapp' ? (cli.whatsappNumber || cli.phone || '') : (cli.phone || ''));
      }
    }
  }, [clientId, channel]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    if (followUp) {
      updateFollowUp(followUp.id, {
        title: title.trim(),
        channel,
        dueDate,
        scheduledTime,
        priority,
        clientId: clientId || undefined,
        projectId: projectId || undefined,
        customNumber: customNumber.trim() || undefined,
        notes: notes.trim(),
      });
    } else {
      addFollowUp({
        title: title.trim(),
        channel,
        dueDate,
        scheduledTime,
        priority,
        clientId: clientId || undefined,
        projectId: projectId || undefined,
        customNumber: customNumber.trim() || undefined,
        notes: notes.trim(),
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-lg rounded-2xl border shadow-2xl overflow-hidden flex flex-col max-h-[92vh] ${tokens.surface} ${tokens.border}`}
      >
        {/* Header */}
        <div
          className={`px-5 py-4 border-b flex items-center justify-between ${tokens.border} ${tokens.bgSubtle}`}
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-xl tracking-tight font-semibold">
                {followUp ? 'Edit Upcoming Call / Follow-up' : 'Schedule Call / Follow-up'}
              </h3>
              <p className={`text-[11px] font-mono ${tokens.textSecondary}`}>
                Set upcoming scheduled call, WhatsApp outreach or task
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-lg ${tokens.textMuted} hover:${tokens.textPrimary} transition-colors`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 text-xs font-mono">
          {/* Action Title */}
          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
              Follow-up Title / Call Agenda
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Call client regarding Siyaram 500 sq.yd corner plot allotment"
              className={`w-full px-3 py-2 rounded-xl border bg-transparent font-sans text-sm font-medium ${tokens.border}`}
            />
          </div>

          {/* Outreach Channel */}
          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1.5 ${tokens.textMuted}`}>
              Planned Communication Type
            </label>
            <div className="grid grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setChannel('call')}
                className={`py-2 px-2 rounded-lg border flex items-center justify-center gap-1.5 cursor-pointer text-xs font-semibold ${
                  channel === 'call'
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/50 shadow-xs'
                    : `${tokens.border} ${tokens.textSecondary}`
                }`}
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call</span>
              </button>

              <button
                type="button"
                onClick={() => setChannel('whatsapp')}
                className={`py-2 px-2 rounded-lg border flex items-center justify-center gap-1.5 cursor-pointer text-xs font-semibold ${
                  channel === 'whatsapp'
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50 shadow-xs'
                    : `${tokens.border} ${tokens.textSecondary}`
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={() => setChannel('sms')}
                className={`py-2 px-2 rounded-lg border flex items-center justify-center gap-1.5 cursor-pointer text-xs font-semibold ${
                  channel === 'sms'
                    ? 'bg-blue-500/20 text-blue-400 border-blue-500/50 shadow-xs'
                    : `${tokens.border} ${tokens.textSecondary}`
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                <span>SMS</span>
              </button>

              <button
                type="button"
                onClick={() => setChannel('meeting')}
                className={`py-2 px-2 rounded-lg border flex items-center justify-center gap-1.5 cursor-pointer text-xs font-semibold ${
                  channel === 'meeting'
                    ? 'bg-purple-500/20 text-purple-400 border-purple-500/50 shadow-xs'
                    : `${tokens.border} ${tokens.textSecondary}`
                }`}
              >
                <User className="w-3.5 h-3.5" />
                <span>Meeting</span>
              </button>
            </div>
          </div>

          {/* Client & Project Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Client Recipient
              </label>
              <select
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs ${tokens.border}`}
              >
                <option value="" className="bg-stone-900 text-stone-100">
                  -- Direct Contact / Guest --
                </option>
                {clients.map((c) => (
                  <option key={c.id} value={c.id} className="bg-stone-900 text-stone-100">
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Project (e.g. Siyaram)
              </label>
              <select
                value={projectId}
                onChange={(e) => setProjectId(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs ${tokens.border}`}
              >
                <option value="" className="bg-stone-900 text-stone-100">
                  -- Select Project --
                </option>
                {projects.map((p) => (
                  <option key={p.id} value={p.id} className="bg-stone-900 text-stone-100">
                    {p.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Date, Time & Priority */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Due Date
              </label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs ${tokens.border}`}
              />
            </div>

            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Scheduled Time
              </label>
              <input
                type="text"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
                placeholder="11:30 AM"
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs ${tokens.border}`}
              />
            </div>

            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs font-semibold ${tokens.border}`}
              >
                <option value="high" className="bg-stone-900 text-red-400">
                  High Priority
                </option>
                <option value="medium" className="bg-stone-900 text-amber-400">
                  Medium
                </option>
                <option value="low" className="bg-stone-900 text-stone-300">
                  Low
                </option>
              </select>
            </div>
          </div>

          {/* Custom Phone Number for Quick Dial */}
          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
              Direct Contact Number (Phone / WhatsApp)
            </label>
            <input
              type="text"
              value={customNumber}
              onChange={(e) => setCustomNumber(e.target.value)}
              placeholder="+91 98200 41122"
              className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs ${tokens.border}`}
            />
          </div>

          {/* Notes */}
          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
              Detailed Notes & Talking Points
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Follow up on site visit clearance pass and high-rise tower floor plans."
              className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs leading-relaxed ${tokens.border}`}
            />
          </div>

          {/* Footer */}
          <div className={`pt-4 border-t flex items-center justify-end gap-2.5 ${tokens.border}`}>
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2 rounded-xl border text-xs font-semibold ${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary}`}
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md ${tokens.accentBtn}`}
            >
              <Check className="w-4 h-4" />
              <span>{followUp ? 'Save Changes' : 'Create Follow-up'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
