import React from 'react';

interface PullToRefreshProps {
  children: React.ReactNode;
}

export const PullToRefresh: React.FC<PullToRefreshProps> = ({ children }) => {
  return <div className="relative flex min-h-0 flex-1 overflow-hidden">{children}</div>;
};
