import React, { useState, useEffect, useRef } from 'react';
import { motion, useAnimation } from 'motion/react';
import { RefreshCw } from 'lucide-react';
import { useData } from '../context/DataContext';
import { useTheme } from '../context/ThemeContext';

interface PullToRefreshProps {
  children: React.ReactNode;
}

export const PullToRefresh: React.FC<PullToRefreshProps> = ({ children }) => {
  const [pulling, setPulling] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const { syncStatus, triggerSync } = useData();
  const { tokens } = useTheme();
  
  const MAX_PULL = 120;
  const THRESHOLD = 80;
  
  const startY = useRef(0);
  const currentY = useRef(0);
  const isRefreshing = syncStatus === 'syncing';

  const handleTouchStart = (e: React.TouchEvent) => {
    // Only allow pull-to-refresh if we are at the very top of the page
    if (window.scrollY === 0) {
      startY.current = e.touches[0].clientY;
      setPulling(true);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!pulling || isRefreshing) return;
    
    currentY.current = e.touches[0].clientY;
    const diff = currentY.current - startY.current;
    
    if (diff > 0 && window.scrollY === 0) {
      // Add resistance to the pull
      const resistanceDiff = diff * 0.4;
      const newPullDistance = Math.min(resistanceDiff, MAX_PULL);
      
      // Optionally, you can attach a native non-passive listener in useEffect to prevent overscroll,
      // but letting the browser handle standard overscroll bounce is often fine on mobile.
      
      setPullDistance(newPullDistance);
    }
  };

  const handleTouchEnd = () => {
    if (!pulling) return;
    setPulling(false);
    
    if (pullDistance > THRESHOLD && !isRefreshing) {
      triggerSync();
    }
    
    // Animate back to 0 (or keep some space if refreshing)
    if (!isRefreshing) {
      setPullDistance(0);
    }
  };

  useEffect(() => {
    if (syncStatus === 'synced' || syncStatus === 'offline') {
      setPullDistance(0);
    }
  }, [syncStatus]);

  // Derive styles based on pull state
  const isReadyToRefresh = pullDistance > THRESHOLD;
  const progress = Math.min(pullDistance / THRESHOLD, 1);

  return (
    <div 
      className="relative w-full min-h-screen"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <motion.div 
        animate={{ y: isRefreshing ? 60 : pullDistance }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        className="w-full relative z-10"
      >
        {children}
      </motion.div>

      {/* Pull indicator positioned behind the content, revealed as content pulls down */}
      <div 
        className="absolute top-0 left-0 w-full h-24 flex items-center justify-center z-0"
      >
        <motion.div 
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ 
            opacity: pullDistance > 10 || isRefreshing ? 1 : 0, 
            scale: isRefreshing ? 1 : Math.max(0.5, progress),
            rotate: isRefreshing ? 360 : progress * 180
          }}
          transition={{ 
            rotate: { 
              duration: isRefreshing ? 1.5 : 0, 
              repeat: isRefreshing ? Infinity : 0, 
              ease: "linear" 
            } 
          }}
          className={`w-10 h-10 rounded-full flex items-center justify-center shadow-md backdrop-blur-md ${tokens.surfaceElevated} ${tokens.border} border`}
        >
          <RefreshCw className={`w-5 h-5 ${isReadyToRefresh || isRefreshing ? tokens.accentText : tokens.textSecondary}`} />
        </motion.div>
      </div>
    </div>
  );
};
