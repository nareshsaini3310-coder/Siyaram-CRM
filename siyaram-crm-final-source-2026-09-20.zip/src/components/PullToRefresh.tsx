import React from 'react';

interface PullToRefreshProps {
  children: React.ReactNode;
}

export const PullToRefresh: React.FC<PullToRefreshProps> = ({ children }) => {
  return <div className="siyaram-scroll-region relative w-full min-h-screen overscroll-y-contain">{children}</div>;
};
