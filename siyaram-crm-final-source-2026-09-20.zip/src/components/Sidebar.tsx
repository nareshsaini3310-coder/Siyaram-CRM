import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  LayoutDashboard,
  Briefcase,
  Users,
  CalendarClock,
  Tags,
  Settings,
  Mic,
  Sun,
  Moon,
  ChevronRight,
  ShieldCheck,
  Plus,
  Smartphone,
  Download
} from 'lucide-react';
import { ViewType } from '../types';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { haptics } from '../utils/haptics';
import { DownloadApkModal } from './DownloadApkModal';

interface SidebarProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  onOpenVoiceRecorder: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  onOpenVoiceRecorder,
  isMobileOpen,
  onCloseMobile,
}) => {
  const { theme, isAutoTheme, toggleTheme, tokens, accent } = useTheme();
  const { user, openAuthModal } = useAuth();
  const { stats } = useData();
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  const navItems = [
    {
      id: 'dashboard' as ViewType,
      label: 'Aaj',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'projects' as ViewType,
      label: 'Projects',
      icon: Briefcase,
      badge: stats.activeProjectsCount > 0 ? stats.activeProjectsCount : null,
      badgeColor: 'bg-stone-500/20 text-stone-300',
    },
    {
      id: 'clients' as ViewType,
      label: 'Leads',
      icon: Users,
      badge: stats.totalClientsCount,
      badgeColor: 'bg-stone-500/20 text-stone-300',
    },
    {
      id: 'followups' as ViewType,
      label: 'Visit',
      icon: CalendarClock,
      badge: stats.pendingFollowUpsCount > 0 ? stats.pendingFollowUpsCount : null,
      badgeColor: stats.urgentFollowUpsCount > 0 ? 'bg-[#c59b4e]/20 text-[#c59b4e]' : 'bg-stone-500/20 text-stone-300',
      notificationDot: stats.dueOrOverdueFollowUpsCount > 0 ? stats.dueOrOverdueFollowUpsCount : null,
    },
    {
      id: 'tags' as ViewType,
      label: 'Refer',
      icon: Tags,
      badge: null,
    },
    {
      id: 'settings' as ViewType,
      label: 'Settings',
      icon: Settings,
      badge: null,
    },
  ];

  const handleNavClick = (view: ViewType) => {
    haptics.selection();
    onNavigate(view);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          onClick={() => {
            haptics.selection();
            onCloseMobile();
          }}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs lg:hidden"
        />
      )}

      <aside
        id="atelier-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 border-r flex flex-col transition-transform duration-200 lg:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        } ${tokens.surface} ${tokens.border}`}
      >
        {/* Studio Branding */}
        <div className="p-5 border-b border-inherit flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 via-indigo-500 to-violet-600 flex items-center justify-center text-slate-950 font-bold font-display text-xl shadow-md shrink-0">
              S
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-display text-2xl tracking-tight font-bold text-blue-600 dark:text-blue-400 leading-none">
                  SIYARAM
                </span>
                <span className="text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded font-mono font-black bg-blue-500/15 text-blue-600 dark:text-blue-300 border border-blue-500/30 shrink-0">
                  CRM
                </span>
              </div>
              <p className={`text-[10px] mt-1 tracking-wider uppercase font-mono ${tokens.textMuted}`}>
                Plots · High Rises · Land Desk
              </p>
            </div>
          </div>
        </div>

        {/* Quick Voice Recording CTA */}
        <div className="px-4 pt-4 pb-2 space-y-2">
          <button
            type="button"
            onClick={() => {
              haptics.medium();
              onOpenVoiceRecorder();
            }}
            className={`w-full py-2.5 px-3.5 rounded-xl text-xs font-semibold tracking-wider uppercase flex items-center justify-between transition-all group ${tokens.accentBtn}`}
          >
            <span className="flex items-center gap-2">
              <Mic className="w-4 h-4 animate-pulse" />
              <span>Record Call</span>
            </span>
            <span className="text-[10px] opacity-75 font-mono">Audio Notes</span>
          </button>

          <button
            id="sidebar-btn-download-apk"
            type="button"
            onClick={() => {
              haptics.selection();
              setIsApkModalOpen(true);
              onCloseMobile();
            }}
            className={`w-full py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-between transition-all border ${
              theme === 'dark'
                ? 'bg-amber-500/10 text-amber-400 border-amber-500/25 hover:bg-amber-500/20'
                : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
            }`}
            title="Download Android APK"
          >
            <span className="flex items-center gap-2">
              <Smartphone className="w-3.5 h-3.5 text-amber-500" />
              <span className="text-[11px]">Download APK</span>
            </span>
            <span className="text-[10px] font-mono opacity-80">v1.4.2</span>
          </button>
        </div>

        {/* Navigation List */}
        <nav className="flex-1 px-3 py-3 space-y-1 overflow-y-auto">
          <div className={`px-3 py-1 text-[10px] font-mono tracking-widest uppercase ${tokens.textMuted}`}>
            Workspace
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              currentView === item.id ||
              (item.id === 'projects' && currentView === 'project_detail') ||
              (item.id === 'clients' && currentView === 'client_detail');

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavClick(item.id)}
                className={`relative w-full px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all group ${
                  isActive
                    ? `${tokens.textPrimary} font-semibold`
                    : `${tokens.textSecondary} hover:${tokens.textPrimary} ${tokens.surfaceHover}`
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="active-sidebar-pill"
                    className={`absolute inset-0 rounded-xl z-0 pointer-events-none ${tokens.surfaceElevated} shadow-xs ${tokens.accentBorder} border`}
                    transition={{
                      type: 'spring',
                      stiffness: 550,
                      damping: 38,
                      mass: 0.35,
                    }}
                  />
                )}
                <div className="flex items-center gap-3 relative z-10">
                  <div className="relative">
                    <Icon
                      className={`w-4 h-4 transition-colors ${
                        isActive ? tokens.accentText : 'text-stone-400 group-hover:text-stone-200'
                      }`}
                    />
                    {item.notificationDot && (
                      <span className="absolute -top-1.5 -right-1.5 min-w-[14px] h-[14px] rounded-full bg-red-500 flex items-center justify-center text-[8px] font-bold text-white shadow-sm ring-1 ring-white/10 px-0.5">
                        {item.notificationDot}
                      </span>
                    )}
                  </div>
                  <span>{item.label}</span>
                </div>
                {item.badge !== null && (
                  <span
                    className={`relative z-10 px-1.5 py-0.5 rounded-md text-[10px] font-mono font-medium ${
                      item.badgeColor || 'bg-stone-500/20 text-stone-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Mode & Accent Quick Status */}
        <div className={`px-4 py-3 border-t border-inherit flex items-center justify-between text-xs ${tokens.textSecondary}`}>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                haptics.light();
                toggleTheme();
              }}
              className={`p-1.5 rounded-lg border transition-colors ${tokens.border} ${tokens.surfaceHover} ${tokens.textPrimary}`}
              title={`Switch to ${theme === 'dark' ? 'Dawn (light)' : 'Dark'} mode`}
            >
              {theme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            </button>
            <span className="text-[11px] capitalize font-mono">
              {isAutoTheme ? `Auto (${theme})` : theme} · {accent}
            </span>
          </div>

          <button
            type="button"
            onClick={() => handleNavClick('settings')}
            className={`text-[11px] font-mono hover:${tokens.textPrimary} underline underline-offset-2`}
          >
            Customise
          </button>
        </div>

        {/* User Session Footer */}
        <div className={`p-3 border-t border-inherit ${theme === 'dark' ? 'bg-[#0f1114]' : 'bg-[#f0eae0]'}`}>
          <button
            type="button"
            onClick={() => {
              haptics.selection();
              openAuthModal();
            }}
            className={`w-full p-2 rounded-xl flex items-center gap-3 text-left transition-colors ${tokens.surfaceHover}`}
          >
            {user ? (
              <>
                <div className="relative">
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-8 h-8 rounded-full object-cover border border-stone-500/30"
                  />
                  <span className="w-2 h-2 rounded-full bg-emerald-500 absolute -bottom-0.5 -right-0.5 ring-2 ring-[#0b0c0e]" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-xs truncate leading-tight">{user.name}</div>
                  <div className={`text-[10px] truncate ${tokens.textMuted}`}>{user.role}</div>
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2.5 text-xs font-medium">
                <ShieldCheck className="w-4 h-4 text-stone-400" />
                <span>Sign in with better-auth</span>
              </div>
            )}
            <ChevronRight className="w-3.5 h-3.5 text-stone-400 shrink-0" />
          </button>
        </div>
      </aside>

      <DownloadApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </>
  );
};
