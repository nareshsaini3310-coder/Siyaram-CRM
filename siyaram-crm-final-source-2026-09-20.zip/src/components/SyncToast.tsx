import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';
import { useData } from '../context/DataContext';
import { useTheme } from '../context/ThemeContext';

export function SyncToast() {
  const { syncStatus } = useData();
  const { tokens } = useTheme();
  const [show, setShow] = useState(false);
  const prevStatus = useRef(syncStatus);

  useEffect(() => {
    if (prevStatus.current === 'syncing' && syncStatus === 'synced') {
      setShow(true);
      const timer = setTimeout(() => {
        setShow(false);
      }, 2500);
      return () => clearTimeout(timer);
    }
    prevStatus.current = syncStatus;
  }, [syncStatus]);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          transition={{ type: 'spring', stiffness: 400, damping: 25 }}
          className={`fixed bottom-24 right-4 sm:bottom-8 sm:right-8 z-[100] flex items-center gap-2.5 px-4 py-2.5 rounded-full border shadow-[0_12px_40px_rgba(0,0,0,0.6)] ${tokens.surfaceElevated} ${tokens.border}`}
        >
          <div className="w-6 h-6 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <span className={`text-xs font-semibold ${tokens.textPrimary}`}>
            Sync Complete
          </span>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
