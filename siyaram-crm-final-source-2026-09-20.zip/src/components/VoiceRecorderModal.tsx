import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Play,
  Pause,
  RotateCcw,
  Save,
  X,
  Volume2,
  Clock,
  User,
  Briefcase,
  FileText,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';
import { useData } from '../context/DataContext';
import { saveAudioBlob } from '../utils/audioStorage';

interface VoiceRecorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedClientId?: string;
  preselectedProjectId?: string;
  preselectedFollowUpId?: string;
}

export const VoiceRecorderModal: React.FC<VoiceRecorderModalProps> = ({
  isOpen,
  onClose,
  preselectedClientId,
  preselectedProjectId,
  preselectedFollowUpId,
}) => {
  const { theme, tokens, accent } = useTheme();
  const { clients, projects, addRecording, addCommLog } = useData();

  // Mode: 'note' for standalone voice notes / project reminders, 'call' for call recordings
  const [recordMode, setRecordMode] = useState<'note' | 'call'>('note');

  // Recording states
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [duration, setDuration] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackTime, setPlaybackTime] = useState(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [micError, setMicError] = useState<string | null>(null);

  // Form metadata
  const [title, setTitle] = useState('');
  const [clientId, setClientId] = useState(preselectedClientId || '');
  const [projectId, setProjectId] = useState(preselectedProjectId || '');
  const [summary, setSummary] = useState('');
  const [transcription, setTranscription] = useState('');
  const [actionItems, setActionItems] = useState<string[]>([]);

  // Refs for media and animation
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);

  // Sync preselected options when modal opens
  useEffect(() => {
    if (isOpen) {
      if (preselectedClientId) {
        setClientId(preselectedClientId);
        setRecordMode('call');
      }
      if (preselectedProjectId) setProjectId(preselectedProjectId);
      if (!title) {
        const client = clients.find((c) => c.id === preselectedClientId);
        const proj = projects.find((p) => p.id === preselectedProjectId);
        if (recordMode === 'call' && client) {
          setTitle(`Client Call Recording — ${client.name}`);
        } else if (proj) {
          setTitle(`Voice Note: ${proj.title} Site Assessment`);
        } else {
          setTitle(`Studio Voice Memo — ${new Date().toLocaleDateString()}`);
        }
      }
    } else {
      cleanupAudio();
    }
  }, [isOpen, preselectedClientId, preselectedProjectId, recordMode]);

  const cleanupAudio = () => {
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
    setIsPaused(false);
    setAudioBlob(null);
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
      setAudioUrl(null);
    }
  };

  // Start real microphone capture
  const startRecording = async () => {
    haptics.medium();
    setMicError(null);
    audioChunksRef.current = [];
    setDuration(0);
    setAudioBlob(null);
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioUrl(null);

    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error('Microphone capture is unavailable in this WebView.');
      }
      if (typeof MediaRecorder === 'undefined') {
        throw new Error('Audio recording is unavailable in this WebView.');
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      // Setup Web Audio analyser for visualizer
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioContextRef.current = audioCtx;
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 64;
      analyserRef.current = analyser;
      const source = audioCtx.createMediaStreamSource(stream);
      source.connect(analyser);

      // Setup MediaRecorder
      const supportedMimeTypes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/ogg;codecs=opus',
        'audio/mp4',
      ];
      const mimeType = supportedMimeTypes.find((candidate) => MediaRecorder.isTypeSupported(candidate));
      const mediaRecorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: mediaRecorder.mimeType || mimeType || 'audio/webm' });
        setAudioBlob(blob);
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start(250);
      setIsRecording(true);
      setIsPaused(false);

      // Start duration counter
      timerIntervalRef.current = setInterval(() => {
        setDuration((prev) => prev + 1);
      }, 1000);

      // Start visualizer loop
      drawWaveform();
    } catch (err: any) {
      console.warn('Microphone error or permission denied:', err);
      if (err?.name === 'NotAllowedError' || err?.name === 'SecurityError') {
        setMicError('Microphone permission is required for Voice Notes.');
      } else {
        setMicError(err?.message || 'Microphone access is unavailable on this device.');
      }
    }
  };

  const pauseRecording = () => {
    haptics.selection();
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.pause();
    }
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    setIsPaused(true);
  };

  const resumeRecording = () => {
    haptics.selection();
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
      mediaRecorderRef.current.resume();
    }
    timerIntervalRef.current = setInterval(() => {
      setDuration((prev) => prev + 1);
    }, 1000);
    setIsPaused(false);
    drawWaveform();
  };

  const stopRecording = () => {
    haptics.light();
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    setIsRecording(false);
    setIsPaused(false);

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  // Animated visualizer
  const drawWaveform = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const analyser = analyserRef.current;
    const bufferLength = analyser ? analyser.frequencyBinCount : 32;
    const dataArray = new Uint8Array(bufferLength);

    const render = () => {
      animationFrameRef.current = requestAnimationFrame(render);
      if (analyser) {
        analyser.getByteFrequencyData(dataArray);
      } else {
        dataArray.fill(0);
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const barWidth = (canvas.width / bufferLength) * 1.8;
      let x = 0;

      const strokeColor = accent === 'sage' ? 'rgba(108, 147, 119, 0.85)' : 'rgba(90, 129, 150, 0.85)';

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * (canvas.height - 10) + 4;
        ctx.fillStyle = strokeColor;
        ctx.beginPath();
        ctx.roundRect(
          x,
          (canvas.height - barHeight) / 2,
          barWidth - 2,
          barHeight,
          3
        );
        ctx.fill();
        x += barWidth + 2;
      }
    };

    render();
  };

  // Playback handlers
  const togglePlay = () => {
    if (!audioElementRef.current && audioUrl) {
      const audio = new Audio(audioUrl);
      audioElementRef.current = audio;
      audio.playbackRate = playbackSpeed;

      audio.ontimeupdate = () => {
        setPlaybackTime(Math.floor(audio.currentTime));
      };
      audio.onended = () => {
        setIsPlaying(false);
        setPlaybackTime(0);
      };
    }

    if (audioElementRef.current) {
      if (isPlaying) {
        audioElementRef.current.pause();
        setIsPlaying(false);
      } else {
        audioElementRef.current.playbackRate = playbackSpeed;
        audioElementRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }
    } else {
      setIsPlaying(false);
    }
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (audioElementRef.current) {
      audioElementRef.current.playbackRate = speed;
    }
  };

  const handleSave = async () => {
    haptics.success();
    if (!title.trim()) return;
    if (!audioBlob) {
      setMicError('Record a voice note before saving it to the archive.');
      return;
    }

    let audioBlobId: string;
    try {
      audioBlobId = await saveAudioBlob(audioBlob);
    } catch (error) {
      console.warn('Unable to persist audio recording:', error);
      setMicError('Unable to save this voice note locally. Please try again.');
      return;
    }

    const savedRec = addRecording({
      title: title.trim(),
      audioBlobId,
      durationSeconds: duration,
      clientId: clientId || undefined,
      projectId: projectId || undefined,
      followUpId: preselectedFollowUpId || undefined,
      summary: summary.trim(),
      transcription: transcription.trim(),
      actionItems,
    });

    // If client is selected or call recording mode, also log into CommLog
    if (clientId || recordMode === 'call') {
      const selectedClient = clients.find((c) => c.id === clientId);
      addCommLog({
        channel: 'call',
        clientId: clientId || 'guest',
        projectId: projectId || undefined,
        phoneNumber: selectedClient?.phone || selectedClient?.whatsappNumber || 'Direct Voice Note',
        direction: 'outgoing',
        status: 'completed',
        durationSeconds: duration,
        voiceRecordingId: savedRec.id,
        notes: summary || title.trim(),
        messageBody: `Audio Recorded (${Math.round((duration || 120) / 60)}m) · ${title.trim()}`,
      });
    }

    onClose();
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remaining.toString().padStart(2, '0')}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-2xl rounded-2xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] ${tokens.surface} ${tokens.border}`}
      >
        {/* Header */}
        <div
          className={`px-6 py-4 border-b flex items-center justify-between ${tokens.border} ${
            theme === 'dark' ? 'bg-[#0f1114]' : 'bg-[#f1ece2]'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center ${tokens.accentBgTint} ${tokens.accentText}`}
            >
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-xl tracking-tight leading-none">
                Studio Voice Recorder
              </h3>
              <p className={`text-xs mt-0.5 ${tokens.textSecondary}`}>
                Record client briefings, site audio memos, and your own action notes
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${tokens.textMuted} hover:${tokens.textPrimary} ${tokens.surfaceHover}`}
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Mode Switcher: Note Mode vs Call Recording Mode */}
          <div className="flex items-center justify-center">
            <div className={`p-1 rounded-xl border flex items-center gap-1.5 ${tokens.surfaceElevated} ${tokens.border}`}>
              <button
                type="button"
                onClick={() => {
                  setRecordMode('note');
                  if (!title || title.includes('Call')) {
                    setTitle(`Voice Note: Siyaram Site & Development Memo — ${new Date().toLocaleDateString()}`);
                  }
                }}
                className={`px-4 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                  recordMode === 'note'
                    ? `${tokens.accentBtn} shadow-xs`
                    : `${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Voice Note Mode</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setRecordMode('call');
                  const client = clients.find((c) => c.id === clientId);
                  setTitle(client ? `Client Call Recording — ${client.name}` : `Client Phone Call Recording`);
                }}
                className={`px-4 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                  recordMode === 'call'
                    ? `${tokens.accentBtn} shadow-xs`
                    : `${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                <Mic className="w-3.5 h-3.5" />
                <span>Call Recording Mode</span>
              </button>
            </div>
          </div>

          {micError && (
            <div className="p-3 rounded-xl bg-[#E25563]/[0.12] border border-[#E25563]/35 text-xs text-[#F28A94] flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{micError}</span>
            </div>
          )}

          {/* Recording Stage */}
              <div
            className={`rounded-xl p-5 border text-center relative overflow-hidden ${
              theme === 'dark' ? 'bg-[#0A1728]/95 border-blue-200/15' : 'bg-[#ece7de]/60 border-[#dad3c5]'
            }`}
          >
            {/* Visualizer Canvas */}
            <div className="h-20 w-full flex items-center justify-center my-2">
              {isRecording ? (
                <canvas
                  ref={canvasRef}
                  width={460}
                  height={80}
                  className="w-full max-w-md h-20"
                />
              ) : (
                <div className={`flex items-center gap-1.5 text-xs font-mono ${tokens.textSecondary}`}>
                  {audioBlob || audioUrl ? (
                    <div className="flex items-center gap-2 text-emerald-500 font-medium">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Audio captured successfully ({formatTime(duration)})</span>
                    </div>
                  ) : (
                    <span>Press record to capture live client discussion</span>
                  )}
                </div>
              )}
            </div>

            {/* Timer Display */}
            <div className="font-mono text-2xl font-bold tracking-wider my-2">
              {formatTime(duration)}
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-center gap-3 mt-4">
              {!isRecording && !audioBlob ? (
                <button
                  type="button"
                  onClick={startRecording}
                  className={`px-6 py-2.5 rounded-xl font-medium text-xs tracking-wider uppercase flex items-center gap-2 transition-all ${tokens.accentBtn}`}
                >
                  <Mic className="w-4 h-4" />
                  <span>Start Recording</span>
                </button>
              ) : isRecording ? (
                <>
                  {isPaused ? (
                    <button
                      type="button"
                      onClick={resumeRecording}
                      className="px-4 py-2 rounded-xl bg-stone-700 hover:bg-stone-600 text-white text-xs font-medium flex items-center gap-1.5 transition-colors"
                    >
                      <Play className="w-4 h-4" />
                      <span>Resume</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={pauseRecording}
                      className="px-4 py-2 rounded-xl bg-stone-700 hover:bg-stone-600 text-white text-xs font-medium flex items-center gap-1.5 transition-colors"
                    >
                      <Pause className="w-4 h-4" />
                      <span>Pause</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={stopRecording}
                    className="px-5 py-2 rounded-xl bg-[#E25563] hover:bg-[#B83D4A] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                  >
                    <Square className="w-4 h-4" />
                    <span>Stop Recording</span>
                  </button>
                </>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={togglePlay}
                    className={`px-4 py-2 rounded-xl text-xs font-medium flex items-center gap-1.5 ${tokens.accentBtn}`}
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    <span>{isPlaying ? 'Pause' : 'Play Audio'}</span>
                  </button>
                  <div className="flex items-center bg-stone-500/10 rounded-lg p-0.5 text-[11px] font-mono">
                    <button
                      type="button"
                      onClick={() => handleSpeedChange(1)}
                      className={`px-2 py-0.5 rounded ${playbackSpeed === 1 ? 'bg-stone-500/30 font-bold' : 'text-stone-400'}`}
                    >
                      1x
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSpeedChange(1.5)}
                      className={`px-2 py-0.5 rounded ${playbackSpeed === 1.5 ? 'bg-stone-500/30 font-bold' : 'text-stone-400'}`}
                    >
                      1.5x
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={startRecording}
                    className={`p-2 rounded-xl border text-stone-400 hover:text-stone-100 ${tokens.border}`}
                    title="Record Again"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Form Meta */}
          <div className="space-y-4">
            <div>
              <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                Recording Title
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Helena Vance — Travertine Finish & Millwork Review"
                className={`w-full px-3.5 py-2 rounded-xl text-xs border focus:outline-none transition-colors ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 flex items-center gap-1.5 ${tokens.textSecondary}`}>
                  <User className="w-3 h-3 text-stone-400" />
                  Link to Client
                </label>
                <select
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  className={`w-full px-3.5 py-2 rounded-xl text-xs border focus:outline-none transition-colors ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                >
                  <option value="">No Client Linked</option>
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.company})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 flex items-center gap-1.5 ${tokens.textSecondary}`}>
                  <Briefcase className="w-3 h-3 text-stone-400" />
                  Link to Project
                </label>
                <select
                  value={projectId}
                  onChange={(e) => setProjectId(e.target.value)}
                  className={`w-full px-3.5 py-2 rounded-xl text-xs border focus:outline-none transition-colors ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                >
                  <option value="">No Project Linked</option>
                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.code} — {p.title}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Manual Notes & Action Items */}
            <div
              className={`p-4 rounded-xl border space-y-3 ${tokens.surfaceElevated} ${tokens.border}`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 ${tokens.accentText}`}>
                  <FileText className="w-3.5 h-3.5" />
                  Manual Notes & Action Items
                </span>
              </div>

              <div>
                <label className={`block text-[11px] font-medium mb-1 ${tokens.textSecondary}`}>
                  Key Discussion Summary
                </label>
                <textarea
                  rows={2}
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  placeholder="Summary of agreed terms or briefing outcomes..."
                  className={`w-full px-3 py-2 rounded-lg text-xs border focus:outline-none transition-colors ${tokens.bgSubtle} ${tokens.border} ${tokens.textPrimary}`}
                />
              </div>

              <div>
                <label className={`block text-[11px] font-medium mb-1 ${tokens.textSecondary}`}>
                  Manual Transcript / Notes
                </label>
                <textarea
                  rows={2}
                  value={transcription}
                  onChange={(e) => setTranscription(e.target.value)}
                  placeholder="Type or paste your own transcript/notes..."
                  className={`w-full px-3 py-2 rounded-lg text-xs font-serif italic border focus:outline-none transition-colors ${tokens.bgSubtle} ${tokens.border} ${tokens.textPrimary}`}
                />
              </div>

              {actionItems.length > 0 && (
                <div>
                  <span className={`block text-[11px] font-medium mb-1.5 ${tokens.textSecondary}`}>
                    Extracted Action Items ({actionItems.length})
                  </span>
                  <ul className="space-y-1 text-xs">
                    {actionItems.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${tokens.accentText}`} />
                        <span className={tokens.textPrimary}>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div
          className={`px-6 py-4 border-t flex items-center justify-end gap-3 ${tokens.border} ${
            theme === 'dark' ? 'bg-[#0f1114]' : 'bg-[#f1ece2]'
          }`}
        >
          <button
            type="button"
            onClick={onClose}
            className={`px-4 py-2 rounded-xl text-xs font-medium transition-colors ${tokens.textSecondary} hover:${tokens.textPrimary}`}
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!title.trim()}
            className={`px-6 py-2 rounded-xl font-medium text-xs tracking-wider uppercase flex items-center gap-1.5 transition-all disabled:opacity-50 disabled:pointer-events-none ${tokens.accentBtn}`}
          >
            <Save className="w-4 h-4" />
            <span>Save to Archive</span>
          </button>
        </div>
      </div>
    </div>
  );
};
