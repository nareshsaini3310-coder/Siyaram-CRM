import React, { useEffect, useState, useCallback } from 'react';
import { Bell, BellOff, CheckCircle2, AlertTriangle, ShieldCheck, Phone } from 'lucide-react';
import { useData } from '../context/DataContext';
import { useTheme } from '../context/ThemeContext';
import {
  parseFollowUpDateTime,
  getLastConversationSummary,
  getLinkedProjectTitle,
  hasAlertFired,
  markAlertFired,
  isAlertSnoozed,
  snoozeAlert,
  showNativeNotification,
  requestNotificationPermission,
  getNotificationPermission,
  playUrgent2MinChime,
  vibrateDevice,
} from '../utils/notificationEngine';
import { Urgent2MinAlertModal, UrgentAlertData } from './Urgent2MinAlertModal';
import { Client, FollowUp } from '../types';

interface NotificationManagerProps {
  onSelectClient?: (clientId: string) => void;
}

export const NotificationManager: React.FC<NotificationManagerProps> = ({ onSelectClient }) => {
  const { theme } = useTheme();
  const { followUps, clients, projects, commLogs, toggleFollowUpStatus } = useData();

  const [permissionState, setPermissionState] = useState<NotificationPermission | 'unsupported'>('default');
  const [urgentAlert, setUrgentAlert] = useState<UrgentAlertData | null>(null);
  const [showPermissionBanner, setShowPermissionBanner] = useState<boolean>(false);

  // Initialize permission state
  useEffect(() => {
    const current = getNotificationPermission();
    setPermissionState(current);
    if (current === 'default') {
      setShowPermissionBanner(true);
    }
  }, []);

  const handleEnableNotifications = async () => {
    const granted = await requestNotificationPermission();
    const updated = getNotificationPermission();
    setPermissionState(updated);
    if (granted) {
      setShowPermissionBanner(false);
      // Play brief test chime
      playUrgent2MinChime();
      showNativeNotification('🔔 Notifications Enabled!', {
        body: 'Ab aapko call karne se 2 minut pahle background notification aur morning agenda alerts milenge.',
        tag: 'crm-setup-success',
      });
    }
  };

  // Main Background Notification Engine Heartbeat (Every 12 seconds)
  const checkFollowUps = useCallback(() => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    // Check all active pending follow-ups
    followUps.forEach((f) => {
      if (f.status === 'completed' || isAlertSnoozed(f.id)) return;

      const client = clients.find((c) => c.id === f.clientId);
      if (!client) return;

      const scheduledDate = parseFollowUpDateTime(f.dueDate, f.scheduledTime);
      const diffMs = scheduledDate.getTime() - now.getTime();
      const diffMinutes = diffMs / 60000;

      // 1. T-2 MINUTE ALERT: Trigger between 0 and 2.2 minutes before scheduled call
      if (diffMinutes > 0 && diffMinutes <= 2.2) {
        if (!hasAlertFired(f.id, '2min')) {
          markAlertFired(f.id, '2min');

          const projectTitle = getLinkedProjectTitle(f.projectId, projects);
          const lastSummary = getLastConversationSummary(client, commLogs);

          // Trigger native OS notification (works in background / offline)
          showNativeNotification(`⚠️ 2 Min Alert: Call ${client.name}!`, {
            body: `Project: ${projectTitle}\nScheduled: ${f.scheduledTime || 'Soon'}\nLast: "${lastSummary}"`,
            tag: `2min-${f.id}`,
            data: {
              phone: client.phone || f.customNumber,
              whatsapp: client.whatsappNumber || client.phone,
              url: '/',
            },
          });

          // Show interactive HUD modal
          setUrgentAlert({
            followUpId: f.id,
            client,
            projectTitle,
            scheduledTime: f.scheduledTime || 'In 2 minutes',
            dueDate: f.dueDate,
            lastConversationSummary: lastSummary,
            followUpNote: f.notes,
          });
        }
      }

      // 2. DUE NOW / MISSED ALERT: If due right now (between 0 and -10 minutes overdue)
      if (diffMinutes <= 0 && diffMinutes >= -10) {
        if (!hasAlertFired(f.id, 'due') && !hasAlertFired(f.id, '2min')) {
          markAlertFired(f.id, 'due');

          const projectTitle = getLinkedProjectTitle(f.projectId, projects);
          const lastSummary = getLastConversationSummary(client, commLogs);

          showNativeNotification(`⏰ Call Due Now: ${client.name}`, {
            body: `Project: ${projectTitle}\nLast Discussion: "${lastSummary}"`,
            tag: `due-${f.id}`,
            data: {
              phone: client.phone || f.customNumber,
              whatsapp: client.whatsappNumber || client.phone,
              url: '/',
            },
          });
        }
      }
    });
  }, [followUps, clients, projects, commLogs]);

  useEffect(() => {
    // Run immediate check
    checkFollowUps();

    // Heartbeat every 12 seconds
    const timer = setInterval(checkFollowUps, 12000);
    return () => clearInterval(timer);
  }, [checkFollowUps]);

  // Test 2-Min Alert function (Exposed for user demonstration)
  const triggerTest2MinAlert = () => {
    const testClient = clients[0] || {
      id: 'test-cli',
      name: 'Vikram Malhotra',
      phone: '+91 98765 43210',
      whatsappNumber: '+91 98765 43210',
      company: 'Apex Heights',
      role: 'Property Investor',
      status: 'hot',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      notes: 'Interested in 4BHK duplex plot at Siyaram Sector 84. Requested price quotation with revised payment schedule.',
      priority: 'high',
      tags: ['Investor', 'Sector 84'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      totalDealValue: 18500000,
    };

    const projectTitle = projects[0]?.title || 'Siyaram Sector 84 Luxury Towers';
    const lastSummary = getLastConversationSummary(testClient as Client, commLogs);

    // Trigger sound, vibration and native notification
    playUrgent2MinChime();
    vibrateDevice();

    showNativeNotification(`⚠️ 2 Min Alert: Call ${testClient.name}!`, {
      body: `Project: ${projectTitle}\nLast: "${lastSummary}"`,
      tag: 'test-2min-alert',
      data: {
        phone: testClient.phone,
        whatsapp: testClient.whatsappNumber,
        url: '/',
      },
    });

    // Show modal HUD
    setUrgentAlert({
      followUpId: 'test-alert-id',
      client: testClient as Client,
      projectTitle,
      scheduledTime: '11:30 AM (In 2 mins)',
      dueDate: new Date().toISOString().split('T')[0],
      lastConversationSummary: lastSummary,
    });
  };

  // Expose triggerTest2MinAlert globally so buttons across views can invoke it
  useEffect(() => {
    (window as any).__triggerTest2MinAlert = triggerTest2MinAlert;
    (window as any).__enableNotifications = handleEnableNotifications;
    return () => {
      delete (window as any).__triggerTest2MinAlert;
      delete (window as any).__enableNotifications;
    };
  }, [clients, projects, commLogs]);

  const handleMarkDone = (followUpId: string) => {
    if (followUpId !== 'test-alert-id') {
      toggleFollowUpStatus(followUpId);
    }
    setUrgentAlert(null);
  };

  const handleSnooze = (followUpId: string, minutes: number) => {
    if (followUpId !== 'test-alert-id') snoozeAlert(followUpId, minutes);
    setUrgentAlert(null);
    showNativeNotification('Snoozed for 5 minutes', {
      body: 'Reminder will pop up again in 5 minutes.',
      tag: 'snooze-ack',
    });
  };

  return (
    <>
      {/* Top Banner when permission is not yet granted */}
      {showPermissionBanner && permissionState === 'default' && (
        <div className={`siyaram-glass bg-gradient-to-r ${theme === 'dark' ? 'from-blue-600/25 via-violet-500/20 to-blue-600/25 text-white' : 'from-blue-50/90 via-violet-50/90 to-blue-50/90 text-slate-800'} px-4 py-2 text-xs font-medium flex items-center justify-between shadow-md z-[60] relative`} role="status" aria-live="polite">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 animate-bounce shrink-0" />
            <span>
              <strong>Background Call Alerts:</strong> Call karne se 2 minut pahle notification pane ke liye permission enable karein.
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleEnableNotifications}
              className="px-3 py-1.5 rounded-full bg-blue-600 text-white font-bold hover:bg-blue-700 transition-colors cursor-pointer text-xs shadow-sm"
            >
              Turn On Alerts
            </button>
            <button
              type="button"
              onClick={() => setShowPermissionBanner(false)}
              className={`${theme === 'dark' ? 'text-white/60 hover:text-white' : 'text-slate-500 hover:text-slate-900'} px-1 font-bold cursor-pointer`}
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* 2-Minute Call Alert Popup Modal */}
      <Urgent2MinAlertModal
        alertData={urgentAlert}
        onClose={() => setUrgentAlert(null)}
        onMarkDone={handleMarkDone}
        onSnooze={handleSnooze}
      />
    </>
  );
};
