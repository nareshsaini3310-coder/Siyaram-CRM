import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Lock,
  Mail,
  User,
  ArrowRight,
  LogOut,
  Sparkles,
  KeyRound
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

export const AuthModal: React.FC = () => {
  const { user, isAuthenticated, isLoading, login, signup, logout, closeAuthModal, isAuthModalOpen } = useAuth();
  const { theme, tokens } = useTheme();

  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('julian@atelierstudio.design');
  const [password, setPassword] = useState('••••••••••••');
  const [name, setName] = useState('Julian Vance');
  const [role, setRole] = useState('Studio Principal');

  if (!isAuthModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'signin') {
      await login(email, password);
    } else {
      await signup(name, email, role);
    }
  };

  const handleQuickDemo = async (demoRole: 'principal' | 'associate') => {
    if (demoRole === 'principal') {
      await login('julian@atelierstudio.design');
    } else {
      await signup('Claire Fontaine', 'claire@atelierstudio.design', 'Senior Project Architect');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-md rounded-2xl border shadow-2xl overflow-hidden flex flex-col ${tokens.surface} ${tokens.border}`}
      >
        {/* Header */}
        <div
          className={`px-6 py-5 border-b flex items-center justify-between ${tokens.border} ${
            theme === 'dark' ? 'bg-[#0f1114]' : 'bg-[#f1ece2]'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <img src="/brand-mark.svg" alt="Siyaram CRM" className="w-9 h-9 rounded-xl shadow-md" />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-[10px] tracking-wider uppercase text-stone-400">
                  SIYARAM CRM
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              </div>
              <h3 className="font-display text-lg tracking-tight leading-none">
                {isAuthenticated ? 'Active CRM Session' : 'Siyaram CRM Access'}
              </h3>
            </div>
          </div>
          <button
            onClick={closeAuthModal}
            className={`p-1.5 rounded-lg transition-colors ${tokens.textMuted} hover:${tokens.textPrimary} ${tokens.surfaceHover}`}
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {isAuthenticated && user ? (
            <div className="space-y-4">
              <div className={`p-4 rounded-xl border flex items-center gap-3.5 ${tokens.surfaceElevated} ${tokens.border}`}>
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-12 h-12 rounded-full object-cover border border-stone-500/20"
                />
                <div className="min-w-0 flex-1">
                  <h4 className="font-semibold text-sm truncate">{user.name}</h4>
                  <p className={`text-xs truncate ${tokens.textSecondary}`}>{user.role}</p>
                  <p className={`text-[11px] font-mono truncate ${tokens.textMuted}`}>{user.email}</p>
                </div>
              </div>

              <div className={`p-3 rounded-lg border text-xs space-y-1.5 ${tokens.bgSubtle} ${tokens.border}`}>
                <div className="flex items-center justify-between text-[11px]">
                  <span className={tokens.textSecondary}>Auth Engine:</span>
                  <span className="font-mono font-medium text-emerald-500">better-auth / session_v2</span>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className={tokens.textSecondary}>Tenant Organization:</span>
                  <span className="font-medium truncate">{user.company}</span>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className={tokens.textSecondary}>Access Tier:</span>
                  <span className="font-medium text-amber-500">Enterprise Studio</span>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={logout}
                  className="flex-1 py-2.5 rounded-xl bg-[#c85642]/15 hover:bg-[#c85642]/25 text-[#c85642] text-xs font-semibold flex items-center justify-center gap-2 transition-colors border border-[#c85642]/30"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out of Session</span>
                </button>
                <button
                  type="button"
                  onClick={closeAuthModal}
                  className={`px-5 py-2.5 rounded-xl text-xs font-medium border ${tokens.border} ${tokens.surfaceHover}`}
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Tabs */}
              <div className="flex rounded-xl p-1 bg-stone-500/10 text-xs">
                <button
                  type="button"
                  onClick={() => setMode('signin')}
                  className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
                    mode === 'signin'
                      ? `${tokens.surfaceElevated} ${tokens.textPrimary} shadow-xs font-semibold`
                      : tokens.textSecondary
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => setMode('signup')}
                  className={`flex-1 py-1.5 rounded-lg font-medium transition-all ${
                    mode === 'signup'
                      ? `${tokens.surfaceElevated} ${tokens.textPrimary} shadow-xs font-semibold`
                      : tokens.textSecondary
                  }`}
                >
                  New Member Account
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-3.5">
                {mode === 'signup' && (
                  <>
                    <div>
                      <label className={`block text-[11px] font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                        Full Name
                      </label>
                      <div className="relative">
                        <User className={`w-3.5 h-3.5 absolute left-3 top-2.5 ${tokens.textMuted}`} />
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Julian Vance"
                          className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none transition-colors ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                        />
                      </div>
                    </div>

                    <div>
                      <label className={`block text-[11px] font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                        Studio Role
                      </label>
                      <input
                        type="text"
                        value={role}
                        onChange={(e) => setRole(e.target.value)}
                        placeholder="Studio Principal, Architect, etc."
                        className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none transition-colors ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                      />
                    </div>
                  </>
                )}

                <div>
                  <label className={`block text-[11px] font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                    Work Email
                  </label>
                  <div className="relative">
                    <Mail className={`w-3.5 h-3.5 absolute left-3 top-2.5 ${tokens.textMuted}`} />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@atelierstudio.design"
                      className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none transition-colors ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                    />
                  </div>
                </div>

                <div>
                  <label className={`block text-[11px] font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                    Password
                  </label>
                  <div className="relative">
                    <Lock className={`w-3.5 h-3.5 absolute left-3 top-2.5 ${tokens.textMuted}`} />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none transition-colors ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full py-2.5 rounded-xl font-medium text-xs tracking-wider uppercase flex items-center justify-center gap-2 transition-all mt-4 ${tokens.accentBtn}`}
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>{mode === 'signin' ? 'Authenticate Session' : 'Create Studio Account'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </form>

              {/* Demo 1-Click Fast Auth */}
              <div className="pt-3 border-t border-stone-500/15">
                <span className={`block text-[10px] font-mono uppercase tracking-wider mb-2 text-center ${tokens.textMuted}`}>
                  Fast Demo Access
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickDemo('principal')}
                    className={`p-2 rounded-xl border text-left text-xs transition-colors ${tokens.surfaceElevated} ${tokens.border} hover:border-amber-500/40`}
                  >
                    <div className="font-medium text-[11px]">Julian Vance</div>
                    <div className={`text-[10px] truncate ${tokens.textMuted}`}>Studio Principal</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickDemo('associate')}
                    className={`p-2 rounded-xl border text-left text-xs transition-colors ${tokens.surfaceElevated} ${tokens.border} hover:border-amber-500/40`}
                  >
                    <div className="font-medium text-[11px]">Claire Fontaine</div>
                    <div className={`text-[10px] truncate ${tokens.textMuted}`}>Senior Architect</div>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
