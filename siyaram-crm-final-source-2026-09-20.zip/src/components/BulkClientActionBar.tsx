import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckSquare,
  Square,
  Tag,
  Plus,
  Minus,
  X,
  Sparkles,
  Users
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';

interface BulkClientActionBarProps {
  selectedCount: number;
  totalFilteredCount: number;
  isAllSelected: boolean;
  onToggleSelectAll: () => void;
  onOpenBulkTagModal: (mode: 'apply' | 'remove') => void;
  onClearSelection: () => void;
}

export const BulkClientActionBar: React.FC<BulkClientActionBarProps> = ({
  selectedCount,
  totalFilteredCount,
  isAllSelected,
  onToggleSelectAll,
  onOpenBulkTagModal,
  onClearSelection,
}) => {
  const { theme, tokens } = useTheme();

  return (
    <AnimatePresence>
      {selectedCount > 0 && (
        <div className="fixed bottom-22 sm:bottom-24 left-1/2 -translate-x-1/2 z-40 w-[calc(100%-2rem)] max-w-lg pointer-events-none">
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className={`pointer-events-auto p-2 sm:p-2.5 rounded-2xl sm:rounded-[22px] flex items-center justify-between gap-2 shadow-2xl border backdrop-blur-2xl transition-all ${
              theme === 'dark'
                ? 'bg-[#181a20]/95 border-amber-500/30 text-stone-100 shadow-[0_12px_40px_rgba(0,0,0,0.8),0_0_20px_rgba(233,196,106,0.15)]'
                : 'bg-white/95 border-amber-500/40 text-slate-900 shadow-[0_12px_40px_rgba(0,0,0,0.15),0_0_20px_rgba(212,163,58,0.15)]'
            }`}
          >
            {/* Left: Count Badge & Select All */}
            <div className="flex items-center gap-2 pl-1 sm:pl-2 min-w-0">
              <span className="w-7 h-7 rounded-xl bg-amber-500 text-slate-950 font-bold font-mono text-xs flex items-center justify-center shrink-0 shadow-sm">
                {selectedCount}
              </span>

              <div className="flex flex-col min-w-0">
                <span className="text-xs font-bold truncate leading-tight">
                  {selectedCount === 1 ? '1 Client' : `${selectedCount} Clients`}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    haptics.selection();
                    onToggleSelectAll();
                  }}
                  className="text-[10px] font-mono text-amber-600 dark:text-amber-400 hover:underline text-left cursor-pointer truncate"
                >
                  {isAllSelected ? 'Deselect All' : `Select All (${totalFilteredCount})`}
                </button>
              </div>
            </div>

            {/* Middle / Right: Tag Actions & Clear */}
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {/* Apply Tag Button */}
              <button
                type="button"
                id="btn-bulk-apply-tags"
                onClick={() => {
                  haptics.selection();
                  onOpenBulkTagModal('apply');
                }}
                className="px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer bg-emerald-500 hover:bg-emerald-400 text-white shadow-sm shadow-emerald-500/20 active:scale-95"
                title="Apply tags to selected clients"
              >
                <Tag className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Apply</span>
                <span>Tags</span>
              </button>

              {/* Remove Tag Button */}
              <button
                type="button"
                id="btn-bulk-remove-tags"
                onClick={() => {
                  haptics.selection();
                  onOpenBulkTagModal('remove');
                }}
                className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border active:scale-95 ${
                  theme === 'dark'
                    ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border-rose-500/30'
                    : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-300'
                }`}
                title="Remove tags from selected clients"
              >
                <Minus className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Remove</span>
                <span>Tags</span>
              </button>

              {/* Clear / Dismiss Selection */}
              <button
                type="button"
                onClick={() => {
                  haptics.selection();
                  onClearSelection();
                }}
                className="p-1.5 rounded-xl text-stone-400 hover:text-stone-200 hover:bg-stone-500/20 transition-colors cursor-pointer"
                title="Clear selection"
                aria-label="Clear selection"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
