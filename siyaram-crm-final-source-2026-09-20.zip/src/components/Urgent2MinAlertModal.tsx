import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Phone,
  MessageSquare,
  Clock,
  Briefcase,
  AlertTriangle,
  X,
  CheckCircle2,
  ExternalLink,
  MapPin,
  Volume2
} from 'lucide-react';
import { Client, FollowUp, Project } from '../types';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';

export interface UrgentAlertData {
  followUpId: string;
  client: Client;
  projectTitle: string;
  scheduledTime: string;
  dueDate: string;
  lastConversationSummary: string;
  followUpNote?: string;
}

interface Urgent2MinAlertModalProps {
  alertData: UrgentAlertData | null;
  onClose: () => void;
  onMarkDone: (followUpId: string) => void;
  onSnooze: (followUpId: string, minutes: number) => void;
}

export const Urgent2MinAlertModal: React.FC<Urgent2MinAlertModalProps> = ({
  alertData,
  onClose,
  onMarkDone,
  onSnooze,
}) => {
  const { theme, tokens } = useTheme();

  if (!alertData) return null;

  const { client, projectTitle, scheduledTime, lastConversationSummary, followUpId } = alertData;

  const handleCall = () => {
    haptics.selection();
    const phone = client.phone || client.whatsappNumber;
    if (phone) {
      const cleanNum = phone.replace(/[^0-9+]/g, '');
      window.location.href = `tel:${cleanNum}`;
    }
  };

  const handleWhatsApp = () => {
    haptics.selection();
    const phone = client.whatsappNumber || client.phone;
    if (phone) {
      const cleanNum = phone.replace(/[^0-9]/g, '');
      const text = encodeURIComponent(
        `Namaste ${client.name}, following up as scheduled regarding ${projectTitle}.`
      );
      window.open(`https://wa.me/${cleanNum}?text=${text}`, '_blank');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fadeIn">
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        transition={{ type: 'spring', damping: 25, stiffness: 400 }}
        className={`w-full max-w-lg rounded-3xl border shadow-[0_20px_60px_rgba(0,0,0,0.6)] overflow-hidden flex flex-col ${
          theme === 'dark'
            ? 'bg-[#181a20] border-amber-500/50 text-stone-100 ring-2 ring-amber-500/30'
            : 'bg-white border-amber-500/60 text-slate-900 ring-2 ring-amber-500/20'
        }`}
      >
        {/* Urgent Header Banner */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-slate-950 text-amber-400 flex items-center justify-center shadow-md animate-pulse">
              <AlertTriangle className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest font-extrabold opacity-90">
                2-Minute Call Alert · Siyaram CRM
              </span>
              <h3 className="font-display text-lg font-black tracking-tight leading-tight">
                Call in 2 Minutes! (2 Minut Baad Call Hai)
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-950/70 hover:text-slate-950 hover:bg-black/10 transition-colors cursor-pointer"
            aria-label="Dismiss alert"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Client & Follow-up Details */}
        <div className="p-5 space-y-4">
          {/* Client Profile Row */}
          <div className="flex items-start gap-3.5 p-3.5 rounded-2xl bg-stone-500/10 border border-inherit">
            <img
              src={client.avatar}
              alt={client.name}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-500/40 shadow-sm shrink-0"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-display text-base font-bold truncate">
                  {client.name}
                </h4>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                  {client.status}
                </span>
              </div>

              <p className="text-xs text-stone-400 truncate">{client.role} · {client.company}</p>

              <div className="flex items-center gap-3 mt-1.5 text-xs font-mono">
                <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Scheduled: {scheduledTime}</span>
                </div>
                {client.location && (
                  <div className="flex items-center gap-1 text-stone-400">
                    <MapPin className="w-3 h-3 text-rose-500" />
                    <span className="truncate max-w-[120px]">{client.location}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Linked Project Box */}
          <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs font-medium text-amber-700 dark:text-amber-400 min-w-0">
              <Briefcase className="w-4 h-4 shrink-0 text-amber-500" />
              <div className="truncate">
                <span className="font-bold text-[11px] font-mono uppercase block text-stone-400">Related Project:</span>
                <span className="font-bold text-xs truncate">{projectTitle}</span>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-amber-500 text-slate-950 font-bold shrink-0">
              Active Site
            </span>
          </div>

          {/* Pichli Baat-Cheet (Last Conversation Summary) */}
          <div className="p-3.5 rounded-2xl bg-stone-500/5 border border-inherit space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400">
              <Volume2 className="w-3.5 h-3.5" />
              <span>Pichli Baat-Cheet Ki Summary (Last Discussion):</span>
            </div>
            <p className="text-xs text-stone-300 dark:text-stone-200 bg-stone-500/10 p-2.5 rounded-xl italic leading-relaxed border border-inherit">
              "{lastConversationSummary}"
            </p>
          </div>

          {/* Phone Numbers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
            <div className="p-2.5 rounded-xl bg-stone-500/10 border border-inherit flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-stone-300">
                <Phone className="w-3.5 h-3.5 text-stone-400" />
                <span>{client.phone}</span>
              </div>
            </div>
            {client.whatsappNumber && (
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between text-emerald-600 dark:text-emerald-400">
                <div className="flex items-center gap-1.5 font-semibold">
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>{client.whatsappNumber}</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 sm:p-5 border-t border-inherit bg-stone-500/5 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSnooze(followUpId, 5)}
              className="px-3 py-2 rounded-xl text-xs font-mono text-stone-400 hover:text-stone-100 hover:bg-stone-500/15 transition-colors cursor-pointer"
            >
              Snooze 5 Min
            </button>
            <button
              type="button"
              onClick={() => onMarkDone(followUpId)}
              className="px-3 py-2 rounded-xl text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/15 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Mark Done</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleWhatsApp}
              className="px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-400 text-white transition-all shadow-md shadow-emerald-500/20 cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </button>

            <button
              type="button"
              onClick={handleCall}
              className="px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all shadow-md shadow-amber-500/20 cursor-pointer"
            >
              <Phone className="w-3.5 h-3.5 fill-current" />
              <span>Call Now</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
