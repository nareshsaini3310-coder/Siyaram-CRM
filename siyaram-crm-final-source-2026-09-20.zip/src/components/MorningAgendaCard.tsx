import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sun,
  Calendar,
  Clock,
  Phone,
  MessageSquare,
  AlertTriangle,
  CheckCircle2,
  Bell,
  Briefcase,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ExternalLink,
  Volume2,
  ShieldCheck
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { haptics } from '../utils/haptics';
import {
  getLastConversationSummary,
  getLinkedProjectTitle,
  showNativeNotification,
  playUrgent2MinChime,
  requestNotificationPermission
} from '../utils/notificationEngine';
import { FollowUp, Client } from '../types';

interface MorningAgendaCardProps {
  onSelectClient: (clientId: string) => void;
  onSelectProject: (projectId: string) => void;
  onTest2MinAlert: () => void;
}

export const MorningAgendaCard: React.FC<MorningAgendaCardProps> = ({
  onSelectClient,
  onSelectProject,
  onTest2MinAlert,
}) => {
  const { theme, tokens } = useTheme();
  const { followUps, clients, projects, commLogs, toggleFollowUpStatus } = useData();

  const [isExpanded, setIsExpanded] = useState(true);
  const [sentBriefingToast, setSentBriefingToast] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  // Follow-ups due today
  const todayFollowUps = followUps.filter(
    (f) => f.dueDate === todayStr && f.status !== 'completed'
  );

  // Overdue follow-ups (must not be missed!)
  const overdueFollowUps = followUps.filter(
    (f) => f.dueDate < todayStr && f.status !== 'completed'
  );

  // Also include any clients with nextFollowUpDate === todayStr who might not have a formal followUp record
  const clientsDueToday = clients.filter(
    (c) => c.nextFollowUpDate === todayStr
  );

  const totalActionCount = todayFollowUps.length + overdueFollowUps.length;

  // Send Morning Agenda Briefing as Native OS Notification
  const handleSendMorningNotification = async () => {
    haptics.selection();
    await requestNotificationPermission();

    const clientNames = todayFollowUps
      .map((f) => {
        const client = clients.find((c) => c.id === f.clientId);
        return client?.name || f.title;
      })
      .slice(0, 3)
      .join(', ');

    const bodyText =
      todayFollowUps.length > 0
        ? `Aaj ${todayFollowUps.length} follow-ups scheduled hain: ${clientNames}${
            todayFollowUps.length > 3 ? '...' : ''
          }. 2-Minut pehle call alert active hai.`
        : 'Aaj koi pending follow-up nahi hai. Shandar din rahe!';

    await showNativeNotification('🌅 Subah Ka Follow-up Schedule (Morning Briefing)', {
      body: bodyText,
      tag: 'morning-briefing',
    });

    setSentBriefingToast(true);
    setTimeout(() => setSentBriefingToast(false), 4000);
  };

  const handleCall = (phoneNumber?: string) => {
    if (!phoneNumber) return;
    const cleanNum = phoneNumber.replace(/[^0-9+]/g, '');
    window.location.href = `tel:${cleanNum}`;
  };

  const handleWhatsApp = (whatsappNumber?: string, name?: string) => {
    if (!whatsappNumber) return;
    const cleanNum = whatsappNumber.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(
      `Namaste ${name || ''}, greeting from Siyaram Estates. Following up as scheduled.`
    );
    window.open(`https://wa.me/${cleanNum}?text=${text}`, '_blank');
  };

  return (
    <div
      className={`rounded-3xl border shadow-lg overflow-hidden transition-all ${
        theme === 'dark'
          ? 'bg-[#181a20] border-blue-500/30'
          : 'bg-white border-blue-500/40'
      }`}
    >
      {/* Card Header */}
      <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-inherit bg-gradient-to-r from-blue-500/10 via-violet-500/5 to-transparent">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-blue-500/20 text-blue-400 border border-blue-500/40 flex items-center justify-center shadow-sm shrink-0">
            <Sun className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400">
                Daily Morning Agenda · Siyaram Desk
              </span>
              <span className="px-2 py-0.2 rounded-full text-[9px] font-mono font-extrabold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                🔔 2-Min Alert Active
              </span>
            </div>
            <h3 className="font-display text-lg font-bold tracking-tight mt-0.5">
              Subah Ka Schedule: Aaj Kis-Kis Ko Follow Karna Hai
            </h3>
            <p className="text-xs text-stone-400">
              {todayFollowUps.length} calls & meetings scheduled today
              {overdueFollowUps.length > 0 && ` · ${overdueFollowUps.length} overdue`}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onTest2MinAlert}
            className="px-3 py-1.5 rounded-xl text-xs font-mono font-semibold flex items-center gap-1.5 border border-cyan-500/40 text-cyan-600 dark:text-cyan-400 bg-cyan-500/10 hover:bg-cyan-500/20 transition-all cursor-pointer"
            title="Test 2-Minute Call Alert Notification & Sound"
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Test 2-Min Alert</span>
          </button>

          <button
            type="button"
            onClick={handleSendMorningNotification}
            className="px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white transition-all shadow-sm shadow-blue-500/20 cursor-pointer"
            title="Receive native notification of morning schedule"
          >
            <Sun className="w-3.5 h-3.5" />
            <span>Subah Ka Notification</span>
          </button>

          <button
            type="button"
            onClick={() => setIsExpanded((prev) => !prev)}
            className="p-1.5 rounded-xl text-stone-400 hover:text-stone-200 hover:bg-stone-500/15 transition-colors cursor-pointer"
            aria-label={isExpanded ? 'Collapse' : 'Expand'}
          >
            {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Briefing Notification Toast */}
      {sentBriefingToast && (
        <div className="p-3 bg-emerald-500/15 border-b border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-medium flex items-center justify-between px-5">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            Subah ka notification bhej diya gaya hai! Background alerts online & offline active hain.
          </span>
        </div>
      )}

      {/* Expandable Content */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="p-4 sm:p-5 space-y-4"
          >
            {/* OVERDUE ALERTS (Do not miss any followup!) */}
            {overdueFollowUps.length > 0 && (
              <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider font-mono">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Missed / Overdue Follow-ups ({overdueFollowUps.length}) - Inhe turant call karein!</span>
                  </div>
                  <span className="text-[10px] font-mono font-bold text-rose-500">Urgent</span>
                </div>

                <div className="space-y-2">
                  {overdueFollowUps.map((item) => {
                    const client = clients.find((c) => c.id === item.clientId);
                    const projectTitle = getLinkedProjectTitle(item.projectId, projects);
                    const lastSummary = getLastConversationSummary(client, commLogs);

                    return (
                      <div
                        key={item.id}
                        className="p-3 rounded-xl bg-white/60 dark:bg-black/20 border border-rose-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs hover:underline cursor-pointer" onClick={() => client && onSelectClient(client.id)}>
                              {client?.name || item.title}
                            </span>
                            <span className="text-[10px] font-mono text-rose-600 dark:text-rose-400 font-semibold">
                              Was due: {item.dueDate} {item.scheduledTime || ''}
                            </span>
                          </div>
                          <p className="text-[11px] text-stone-400 truncate mt-0.5">
                            Project: <strong className="text-stone-300">{projectTitle}</strong> · Last: "{lastSummary}"
                          </p>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleCall(client?.phone || client?.whatsappNumber)}
                            className="px-3 py-1 rounded-lg text-xs font-bold bg-rose-500 hover:bg-rose-400 text-white flex items-center gap-1 cursor-pointer"
                          >
                            <Phone className="w-3 h-3 fill-current" />
                            <span>Call</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => toggleFollowUpStatus(item.id)}
                            className="p-1 rounded-lg text-stone-400 hover:text-emerald-500 hover:bg-emerald-500/10 cursor-pointer"
                            title="Mark Completed"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TODAY'S SCHEDULED ROSTER */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-mono text-stone-400">
                <span className="uppercase font-bold tracking-wider text-blue-600 dark:text-blue-400">
                  Aaj Ke Scheduled Follow-ups ({todayFollowUps.length})
                </span>
                <span>Sorted by Time</span>
              </div>

              {todayFollowUps.length === 0 ? (
                <div className="p-6 rounded-2xl bg-stone-500/5 border border-dashed border-inherit text-center text-stone-400 space-y-1">
                  <p className="text-xs font-medium">Aaj ke liye koi pending follow-up scheduled nahi hai.</p>
                  <p className="text-[11px]">Naye clients add karein ya upcoming schedule check karein.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {todayFollowUps.map((item) => {
                    const client = clients.find((c) => c.id === item.clientId);
                    const projectTitle = getLinkedProjectTitle(item.projectId, projects);
                    const lastSummary = getLastConversationSummary(client, commLogs);

                    return (
                      <div
                        key={item.id}
                        className="p-4 rounded-2xl bg-stone-500/5 border border-inherit flex flex-col justify-between space-y-3 hover:border-blue-500/50 transition-all"
                      >
                        <div>
                          {/* Time badge + Client row */}
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <div className="flex items-center gap-2.5">
                              {client?.avatar && (
                                <img
                                  src={client.avatar}
                                  alt={client.name}
                                  onClick={() => client && onSelectClient(client.id)}
                                  className="w-10 h-10 rounded-xl object-cover border border-white/20 cursor-pointer"
                                />
                              )}
                              <div>
                                <h4
                                  onClick={() => client && onSelectClient(client.id)}
                                  className="font-bold text-xs hover:underline cursor-pointer"
                                >
                                  {client?.name || item.title}
                                </h4>
                                <span className="text-[10px] font-mono text-stone-400">
                                  {client?.role || 'Lead'} · {client?.company || 'Investor'}
                                </span>
                              </div>
                            </div>

                            <span className="px-2 py-1 rounded-xl text-[11px] font-mono font-bold bg-blue-500/15 text-blue-600 dark:text-blue-400 border border-blue-500/30 flex items-center gap-1 shrink-0">
                              <Clock className="w-3 h-3" />
                              {item.scheduledTime || 'Today'}
                            </span>
                          </div>

                          {/* Related Project */}
                          <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-[11px] font-medium text-cyan-700 dark:text-cyan-300 flex items-center gap-1.5">
                            <Briefcase className="w-3.5 h-3.5 shrink-0 text-cyan-500" />
                            <span className="truncate">{projectTitle}</span>
                          </div>

                          {/* Last Conversation Summary */}
                          <div className="mt-2 text-[11px] text-stone-400 bg-stone-500/10 p-2 rounded-xl border border-inherit">
                            <span className="text-stone-300 font-bold block mb-0.5">Pichli Baat:</span>
                            <p className="italic line-clamp-2">"{lastSummary}"</p>
                          </div>
                        </div>

                        {/* Quick Action Buttons */}
                        <div className="flex items-center justify-between pt-2 border-t border-inherit gap-2">
                          <div className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                            <Bell className="w-3 h-3" />
                            <span>2-Min Alert Armed</span>
                          </div>

                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleWhatsApp(client?.whatsappNumber || client?.phone, client?.name)}
                              className="p-2 rounded-xl text-emerald-600 bg-emerald-500/15 hover:bg-emerald-500/25 transition-colors cursor-pointer"
                              title="Send WhatsApp"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleCall(client?.phone || client?.whatsappNumber)}
                              className="px-3 py-1.5 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1 cursor-pointer transition-all shadow-sm"
                            >
                              <Phone className="w-3 h-3 fill-current" />
                              <span>Call</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => toggleFollowUpStatus(item.id)}
                              className="p-1.5 rounded-xl text-stone-400 hover:text-emerald-500 hover:bg-emerald-500/10 cursor-pointer"
                              title="Mark Complete"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
