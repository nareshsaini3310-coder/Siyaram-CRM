import React, { useRef, useState } from 'react';
import { FileSpreadsheet, Upload, X, CheckCircle2, AlertTriangle, Copy, Database } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { mapClientRows, rowsFromSheetMatrix, toClientRecord, RawImportRow } from '../utils/clientImport';
import { haptics } from '../utils/haptics';
import * as XLSX from 'xlsx';
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.mjs';

interface Props { isOpen: boolean; onClose: () => void; }

export const ExcelImportModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { tokens } = useTheme();
  const { projects, clients, importClients } = useData();
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [fileName, setFileName] = useState('');
  const [summary, setSummary] = useState<ReturnType<typeof mapClientRows> | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (!isOpen) return null;

  const reset = () => { setFileName(''); setSummary(null); setError(''); setBusy(false); };
  const close = () => { reset(); onClose(); };

  const extractPdfRow = async (buffer: ArrayBuffer): Promise<RawImportRow[]> => {
    const document = await pdfjsLib.getDocument({ data: new Uint8Array(buffer) }).promise;
    const pages: string[] = [];
    for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent();
      pages.push(content.items.map((item) => ('str' in item ? item.str : '')).join(' '));
    }
    const text = pages.join('\n').replace(/\s+/g, ' ').trim();
    if (!text) throw new Error('Scanned PDF - OCR/text extraction required. No text layer was found.');
    const field = (labels: string[]) => {
      const pattern = labels.join('|');
      const match = text.match(new RegExp(`(?:${pattern})\\s*[:=-]\\s*([^|,;]+?)(?=\\s+(?:Name|Client|Mobile|Phone|Location|City|Requirement|Project|Comment|Notes|Status|Source|Follow[- ]?Up)\\s*[:=-]|$)`, 'i'));
      return match?.[1]?.trim() || '';
    };
    return [{
      Name: field(['Name', 'Client Name', 'Customer Name']),
      Mobile: field(['Mobile', 'Mobile Number', 'Phone', 'Phone Number', 'Contact']),
      Location: field(['Location', 'City', 'Area', 'Address']),
      Requirement: field(['Requirement', 'Interest', 'Property Type']),
      Project: field(['Project', 'Project Name']),
      Notes: field(['Comment', 'Comments', 'Remark', 'Notes']),
      Status: field(['Status', 'Lead Status', 'Stage']),
      Source: field(['Source', 'Lead Source']),
      'Follow Up': field(['Follow Up', 'Follow-up', 'Followup']),
    }];
  };

  const handleFile = async (file?: File) => {
    if (!file) return;
    setBusy(true); setError(''); setSummary(null); setFileName(file.name);
    try {
      const buffer = await file.arrayBuffer();
      if (file.name.toLowerCase().endsWith('.pdf') || file.type === 'application/pdf') {
        setSummary(mapClientRows(await extractPdfRow(buffer), projects, clients));
        return;
      }
      const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      if (!firstSheet) throw new Error('Workbook me koi sheet nahi mili.');
      const matrix = XLSX.utils.sheet_to_json<unknown[]>(firstSheet, { header: 1, defval: '' });
      const rows = rowsFromSheetMatrix(matrix);
      if (!rows.length) throw new Error('Sheet empty hai. Header + data rows chahiye.');
      setSummary(mapClientRows(rows, projects, clients));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'File read nahi ho payi.');
    } finally { setBusy(false); }
  };

  const commit = () => {
    if (!summary) return;
    haptics.success();
    importClients(summary.clients.map(toClientRecord));
    close();
  };

  return <div className="fixed inset-0 z-[100] bg-black/55 backdrop-blur-md flex items-center justify-center p-4" role="dialog" aria-modal="true">
    <div className={`w-full max-w-2xl max-h-[90vh] overflow-hidden rounded-[28px] border shadow-2xl ${tokens.surface} ${tokens.border}`}>
      <div className={`px-5 py-4 border-b flex items-center justify-between ${tokens.border}`}>
        <div className="flex items-center gap-3"><div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${tokens.accentBgTint} ${tokens.accentText}`}><FileSpreadsheet className="w-5 h-5"/></div><div><h2 className="font-display text-lg">Excel Import</h2><p className={`text-xs ${tokens.textSecondary}`}>Deterministic mapping — no AI, no guessing</p></div></div>
        <button onClick={close} className="p-2 rounded-xl hover:bg-stone-500/10"><X className="w-5 h-5"/></button>
      </div>
      <div className="p-5 space-y-4 overflow-y-auto max-h-[70vh]">
        <input ref={inputRef} type="file" accept=".xlsx,.xls,.csv,.tsv,.pdf,application/pdf" className="hidden" onChange={(e)=>handleFile(e.target.files?.[0])}/>
        <button onClick={()=>inputRef.current?.click()} disabled={busy} className={`w-full rounded-2xl border-2 border-dashed p-7 text-center transition-all ${tokens.border} hover:border-blue-500/50 hover:bg-blue-500/5`}>
          <Upload className={`w-7 h-7 mx-auto mb-2 ${tokens.accentText}`}/><div className="font-semibold text-sm">{busy ? 'Reading file…' : fileName || 'Choose Excel / CSV / PDF file'}</div><div className={`text-[11px] mt-1 ${tokens.textSecondary}`}>.xlsx, .xls, .csv, .tsv, and text-based .pdf supported</div>
        </button>
        {error && <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/25 text-red-400 text-xs">{error}</div>}
        {summary && <>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {[['Rows',summary.total,Database],['New',summary.valid - summary.existing,CheckCircle2],['Existing',summary.existing,CheckCircle2],['Duplicates',summary.duplicates,Copy],['Missing',summary.missingData,AlertTriangle],['Review',summary.needsReview,AlertTriangle]].map(([label,value,Icon])=><div key={String(label)} className={`p-3 rounded-2xl border ${tokens.surfaceElevated} ${tokens.border}`}><Icon className={`w-4 h-4 mb-1 ${tokens.accentText}`}/><div className="text-lg font-bold">{value as number}</div><div className={`text-[10px] ${tokens.textSecondary}`}>{label}</div></div>)}
          </div>
          <div className={`rounded-2xl border overflow-hidden ${tokens.border}`}>
            <div className={`px-4 py-3 text-xs font-semibold ${tokens.surfaceElevated}`}>Preview ({summary.clients.length})</div>
            <div className="max-h-56 overflow-auto">
              {summary.clients.slice(0,50).map((c,i)=><div key={`${c.phone}-${i}`} className="px-4 py-2.5 border-t border-inherit text-xs flex items-center justify-between gap-3"><span className="font-semibold truncate">{c.name}</span><span className="font-mono shrink-0">{c.phone}</span><span className={c.importReview ? 'text-amber-400' : 'text-emerald-400'}>{c.importReview ? 'Needs Review' : 'Ready'}</span></div>)}
            </div>
          </div>
          <div className={`text-[11px] ${tokens.textSecondary}`}>Mapping: Name/Client/Buyer Name → Client Name · Mobile/Phone/Contact → Mobile Number. Project is linked only on an exact single match; otherwise it is marked <b>Needs Review</b>.</div>
        </>}
      </div>
      <div className={`px-5 py-4 border-t flex justify-end gap-2 ${tokens.border}`}>
        <button onClick={close} className={`px-4 py-2 rounded-xl text-xs ${tokens.textSecondary}`}>Cancel</button>
        <button onClick={commit} disabled={!summary || !summary.valid} className={`px-5 py-2 rounded-xl text-xs font-semibold disabled:opacity-40 ${tokens.accentBtn}`}>Import {summary?.valid || 0} Leads</button>
      </div>
    </div>
  </div>;
};
