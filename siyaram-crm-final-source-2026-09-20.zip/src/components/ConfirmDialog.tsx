import React from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';

interface ConfirmDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDestructive?: boolean;
}

export const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  isDestructive = false,
}) => {
  const { theme, tokens } = useTheme();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-stone-900/60 backdrop-blur-sm"
        onClick={() => { haptics.selection(); onClose(); }}
      />
      
      <div
        className={`relative w-full max-w-md rounded-2xl shadow-2xl overflow-hidden ${tokens.surfaceElevated} border ${tokens.border}`}
      >
        {/* Header */}
        <div
          className={`px-6 py-5 border-b flex items-center justify-between ${tokens.border} ${
            theme === 'dark' ? 'bg-[#0f1114]' : 'bg-[#f1ece2]'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                isDestructive
                  ? 'bg-red-500/10 text-red-500'
                  : 'bg-amber-500/10 text-amber-500'
              }`}
            >
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="font-display text-lg tracking-tight leading-none">
              {title}
            </h3>
          </div>
          <button
            onClick={() => { haptics.selection(); onClose(); }}
            className={`p-1.5 rounded-lg transition-colors ${tokens.textMuted} hover:${tokens.textPrimary} ${tokens.surfaceHover}`}
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <p className={`${tokens.textSecondary} text-sm leading-relaxed`}>
            {message}
          </p>
        </div>

        {/* Actions */}
        <div
          className={`px-6 py-4 border-t flex flex-col sm:flex-row items-center justify-end gap-3 ${tokens.border} ${
            theme === 'dark' ? 'bg-[#0a0a0b]' : 'bg-[#e8e2d4]/50'
          }`}
        >
          <button
            type="button"
            onClick={() => { haptics.selection(); onClose(); }}
            className={`w-full sm:w-auto px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${tokens.textSecondary} hover:${tokens.textPrimary} ${tokens.surfaceHover}`}
          >
            {cancelText}
          </button>
          <button
            type="button"
            onClick={() => {
              if (isDestructive) haptics.heavy(); else haptics.light();
              onConfirm();
              onClose();
            }}
            className={`w-full sm:w-auto px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${
              isDestructive
                ? 'bg-red-500/20 text-red-500 hover:bg-red-500/30'
                : tokens.accentBtn
            }`}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};
