import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Phone,
  MessageSquare,
  Calendar,
  Mic,
  ArrowRight,
  User,
  FolderOpen,
  MapPin,
  DollarSign,
  Star,
  ExternalLink,
  Sparkles,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { Client, Project } from '../types';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';

interface CardContextMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'client' | 'project';
  client?: Client | null;
  project?: Project | null;
  linkedClients?: Client[];
  onSelectClient?: (id: string) => void;
  onSelectProject?: (id: string) => void;
  onOpenFollowUp?: (clientId?: string, projectId?: string) => void;
  onOpenVoiceRecorder?: (clientId?: string, projectId?: string) => void;
  onOpenQuickComm?: (clientId?: string, projectId?: string, channel?: 'call' | 'whatsapp') => void;
}

export const CardContextMenuModal: React.FC<CardContextMenuModalProps> = ({
  isOpen,
  onClose,
  type,
  client,
  project,
  linkedClients = [],
  onSelectClient,
  onSelectProject,
  onOpenFollowUp,
  onOpenVoiceRecorder,
  onOpenQuickComm,
}) => {
  const { theme, tokens } = useTheme();

  if (!isOpen) return null;

  // Determine effective contact information
  const targetClient = type === 'client' ? client : linkedClients[0] || null;
  const phoneNumber = targetClient?.phone || targetClient?.whatsappNumber;
  const whatsappNumber = targetClient?.whatsappNumber || targetClient?.phone;

  const handleCall = () => {
    haptics.medium();
    onClose();
    if (phoneNumber) {
      const clean = phoneNumber.replace(/[^0-9+]/g, '');
      if (clean) {
        window.location.href = `tel:${clean}`;
        return;
      }
    }
    // Fallback to quick communication modal if no direct phone or wants selection
    if (onOpenQuickComm) {
      onOpenQuickComm(targetClient?.id, project?.id, 'call');
    }
  };

  const handleMessage = () => {
    haptics.medium();
    onClose();
    if (whatsappNumber) {
      const clean = whatsappNumber.replace(/[^0-9]/g, '');
      const greeting =
        type === 'project' && project
          ? `Namaste ${targetClient?.name || ''}, greeting from Siyaram Estates. I'm following up regarding the ${project.title} project.`
          : `Namaste ${targetClient?.name || ''}, greeting from Siyaram Estates. Checking in with you regarding your property requirements.`;
      const encoded = encodeURIComponent(greeting);
      window.open(`https://wa.me/${clean}?text=${encoded}`, '_blank');
      return;
    }
    if (onOpenQuickComm) {
      onOpenQuickComm(targetClient?.id, project?.id, 'whatsapp');
    }
  };

  const handleAddFollowUp = () => {
    haptics.selection();
    onClose();
    if (onOpenFollowUp) {
      onOpenFollowUp(targetClient?.id, project?.id);
    }
  };

  const handleVoiceMemo = () => {
    haptics.medium();
    onClose();
    if (onOpenVoiceRecorder) {
      onOpenVoiceRecorder(targetClient?.id, project?.id);
    }
  };

  const handleViewDetails = () => {
    haptics.selection();
    onClose();
    if (type === 'client' && client && onSelectClient) {
      onSelectClient(client.id);
    } else if (type === 'project' && project && onSelectProject) {
      onSelectProject(project.id);
    }
  };

  return (
    <AnimatePresence>
      <div
        id="card-context-menu-backdrop"
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm"
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            haptics.selection();
            onClose();
          }
        }}
      >
        <motion.div
          id="card-context-menu-sheet"
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
          className={`w-full max-w-md rounded-3xl p-5 shadow-2xl border transition-all ${
            theme === 'dark'
              ? 'bg-[#14161a] border-stone-800 text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.8)]'
              : 'bg-white border-stone-200 text-stone-900 shadow-[0_20px_50px_rgba(0,0,0,0.15)]'
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header indicator */}
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-inherit/20">
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1 text-[11px] font-mono tracking-widest uppercase font-semibold px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                <Sparkles className="w-3 h-3" />
                Quick Actions
              </span>
              <span className="text-xs text-stone-400 font-mono">
                {type === 'client' ? 'Client Dossier' : 'Project Commission'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                haptics.selection();
                onClose();
              }}
              className="p-1.5 rounded-xl text-stone-400 hover:text-stone-100 hover:bg-stone-500/15 transition-colors"
              aria-label="Close menu"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Target Info Summary */}
          {type === 'client' && client && (
            <div className="flex items-center gap-3.5 mb-5 p-3 rounded-2xl bg-stone-500/10 border border-inherit/30">
              <div className="relative shrink-0">
                <img
                  src={client.avatar}
                  alt={client.name}
                  className="w-12 h-12 rounded-2xl object-cover border-2 border-amber-500/40 shadow-sm"
                />
                {client.status === 'vip' && (
                  <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center text-[10px]">
                    <Star className="w-2.5 h-2.5 fill-current" />
                  </span>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="font-display font-bold text-base tracking-tight truncate">
                  {client.name}
                </h4>
                <p className="text-xs text-stone-400 truncate">
                  {client.role} · {client.company}
                </p>
                {client.location && (
                  <div className="flex items-center gap-1 text-[11px] text-stone-400 mt-0.5">
                    <MapPin className="w-3 h-3 text-rose-500 shrink-0" />
                    <span className="truncate">{client.location}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {type === 'project' && project && (
            <div className="mb-5 p-3 rounded-2xl bg-stone-500/10 border border-inherit/30">
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-stone-500/20 text-stone-400 font-semibold">
                  {project.code}
                </span>
                <span className="text-xs font-mono font-bold text-amber-600 dark:text-amber-400">
                  €{project.budget.toLocaleString()}
                </span>
              </div>
              <h4 className="font-display font-bold text-base tracking-tight truncate">
                {project.title}
              </h4>
              <p className="text-xs text-stone-400 line-clamp-1 mt-0.5">
                {project.description}
              </p>
              {linkedClients.length > 0 && (
                <div className="flex items-center gap-2 mt-2 pt-2 border-t border-inherit/20 text-[11px] text-stone-400">
                  <User className="w-3 h-3 text-amber-500 shrink-0" />
                  <span className="truncate">
                    Primary: {linkedClients[0].name} ({linkedClients[0].company})
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Rapid Action Buttons */}
          <div className="grid grid-cols-2 gap-2.5 mb-3">
            {/* Call Action */}
            <button
              type="button"
              onClick={handleCall}
              className={`p-3 rounded-2xl flex items-center gap-3 font-semibold text-xs transition-all shadow-sm cursor-pointer ${
                theme === 'dark'
                  ? 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200'
              }`}
            >
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
                <Phone className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="text-left min-w-0">
                <div className="leading-none font-bold">Call</div>
                <div className="text-[10px] opacity-75 truncate mt-0.5">
                  {phoneNumber || 'Quick Dial'}
                </div>
              </div>
            </button>

            {/* Message Action */}
            <button
              type="button"
              onClick={handleMessage}
              className={`p-3 rounded-2xl flex items-center gap-3 font-semibold text-xs transition-all shadow-sm cursor-pointer ${
                theme === 'dark'
                  ? 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200'
              }`}
            >
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
                <MessageSquare className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="text-left min-w-0">
                <div className="leading-none font-bold">Message</div>
                <div className="text-[10px] opacity-75 truncate mt-0.5">
                  WhatsApp Direct
                </div>
              </div>
            </button>

            {/* Add Follow-up Action */}
            <button
              type="button"
              onClick={handleAddFollowUp}
              className={`p-3 rounded-2xl flex items-center gap-3 font-semibold text-xs transition-all shadow-sm cursor-pointer ${
                theme === 'dark'
                  ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/30'
                  : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200'
              }`}
            >
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 flex items-center justify-center shrink-0">
                <Calendar className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-left min-w-0">
                <div className="leading-none font-bold">Add Follow-up</div>
                <div className="text-[10px] opacity-75 truncate mt-0.5">
                  Schedule Task
                </div>
              </div>
            </button>

            {/* Voice Memo Action */}
            <button
              type="button"
              onClick={handleVoiceMemo}
              className={`p-3 rounded-2xl flex items-center gap-3 font-semibold text-xs transition-all shadow-sm cursor-pointer ${
                theme === 'dark'
                  ? 'bg-purple-500/15 hover:bg-purple-500/25 text-purple-400 border border-purple-500/30'
                  : 'bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200'
              }`}
            >
              <div className="w-8 h-8 rounded-xl bg-purple-500/20 flex items-center justify-center shrink-0">
                <Mic className="w-4 h-4 text-purple-500" />
              </div>
              <div className="text-left min-w-0">
                <div className="leading-none font-bold">Voice Memo</div>
                <div className="text-[10px] opacity-75 truncate mt-0.5">
                  Audio Note
                </div>
              </div>
            </button>
          </div>

          {/* Full Details Navigation Action */}
          <button
            type="button"
            onClick={handleViewDetails}
            className={`w-full py-3 px-4 rounded-2xl font-bold text-xs uppercase tracking-wider flex items-center justify-between transition-all cursor-pointer shadow-sm ${
              theme === 'dark'
                ? 'bg-stone-800 hover:bg-stone-700 text-stone-100 border border-stone-700'
                : 'bg-stone-100 hover:bg-stone-200 text-stone-900 border border-stone-300'
            }`}
          >
            <span className="flex items-center gap-2">
              {type === 'client' ? <User className="w-4 h-4 text-amber-500" /> : <FolderOpen className="w-4 h-4 text-amber-500" />}
              {type === 'client' ? 'View Full Client Dossier' : 'Open Project Workspace'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
