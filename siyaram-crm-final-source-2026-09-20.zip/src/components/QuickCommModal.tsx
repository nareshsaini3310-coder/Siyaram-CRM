import React, { useState, useEffect } from 'react';
import {
  X,
  Phone,
  MessageSquare,
  Send,
  ExternalLink,
  Copy,
  Check,
  Mic,
  Calendar,
  Building,
  User,
  Sparkles,
  FileText
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';
import { useData } from '../context/DataContext';
import { CommChannel } from '../types';

interface QuickCommModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialClientId?: string;
  initialProjectId?: string;
  initialChannel?: CommChannel;
  initialCustomNumber?: string;
  onOpenVoiceRecorder?: (clientId?: string, projectId?: string) => void;
}

export const QuickCommModal: React.FC<QuickCommModalProps> = ({
  isOpen,
  onClose,
  initialClientId,
  initialProjectId,
  initialChannel = 'whatsapp',
  initialCustomNumber,
  onOpenVoiceRecorder,
}) => {
  const { theme, tokens, accent } = useTheme();
  const { clients, projects, addCommLog, updateClient, addFollowUp } = useData();

  const [selectedClientId, setSelectedClientId] = useState<string>(initialClientId || '');
  const [selectedProjectId, setSelectedProjectId] = useState<string>(initialProjectId || '');
  const [channel, setChannel] = useState<CommChannel>(initialChannel);
  const [phoneNumber, setPhoneNumber] = useState<string>(initialCustomNumber || '');
  const [messageText, setMessageText] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [quickRemindDays, setQuickRemindDays] = useState<number | null>(null);
  const [callDuration, setCallDuration] = useState<number>(3); // minutes
  const [copied, setCopied] = useState(false);
  const [saveAsClientDefault, setSaveAsClientDefault] = useState(false);

  const selectedClient = clients.find((c) => c.id === selectedClientId);

  // Sync phone number when client changes
  useEffect(() => {
    if (selectedClient) {
      if (channel === 'whatsapp') {
        setPhoneNumber(selectedClient.whatsappNumber || selectedClient.phone || '');
      } else {
        setPhoneNumber(selectedClient.phone || selectedClient.whatsappNumber || '');
      }
      if (!selectedProjectId && selectedClient.projectIds.length > 0) {
        setSelectedProjectId(selectedClient.projectIds[0]);
      }
    }
  }, [selectedClientId, channel]);

  // Set default message template
  const templates = [
    {
      title: 'Siyaram Project Overview & Brochure',
      text: `Namaste ${selectedClient?.name ? selectedClient.name.split(' ')[0] : 'Sir/Ma’am'}, sharing the official project details, masterplan, and brochure for Siyaram (Sector 84, Express Highway). Please let me know if you would like to schedule a site briefing.`,
    },
    {
      title: 'Plot Inventory & Sizing Options',
      text: `Hello ${selectedClient?.name ? selectedClient.name.split(' ')[0] : 'Sir/Ma’am'}, regarding Siyaram plotted developments: we currently have prime 150, 250, and 500 Sq. Yd. gated plots with immediate registry and registry-ready demarcations. Sharing plot layout.`,
    },
    {
      title: 'High-Rise Tower A / B Specifications',
      text: `Dear ${selectedClient?.name ? selectedClient.name.split(' ')[0] : 'Sir/Ma’am'}, Siyaram G+32 Iconic Luxury Towers featuring 3 & 4 BHK sky mansions with 270° panoramic decks are now open for priority allocations. Would love to walk you through the floorplans.`,
    },
    {
      title: 'Scheduled Site Visit Confirmation',
      text: `Dear ${selectedClient?.name ? selectedClient.name.split(' ')[0] : 'Sir/Ma’am'}, your site visit at project Siyaram is confirmed for tomorrow. Our private sales lounge concierge will receive you at Gate 1 with your security clearance pass.`,
    },
    {
      title: 'Payment Milestone & Documentation Update',
      text: `Namaste ${selectedClient?.name ? selectedClient.name.split(' ')[0] : 'Sir/Ma’am'}, the construction milestone report and payment schedule for your Siyaram allotment is ready for your review. Please confirm receipt.`,
    },
  ];

  if (!isOpen) return null;

  // Clean phone number for wa.me / tel / sms
  const cleanPhoneForUrl = (phone: string) => {
    return phone.replace(/[^0-9]/g, '');
  };

  const handleOpenWhatsApp = () => {
    const rawNumber = cleanPhoneForUrl(phoneNumber);
    if (!rawNumber) {
      alert('Please enter or select a valid WhatsApp phone number.');
      return;
    }
    const encodedMsg = encodeURIComponent(messageText);
    const waUrl = `https://wa.me/${rawNumber}${messageText ? `?text=${encodedMsg}` : ''}`;

    // Log to unified communication log
    addCommLog({
      channel: 'whatsapp',
      clientId: selectedClientId || 'guest',
      projectId: selectedProjectId || undefined,
      phoneNumber: phoneNumber,
      whatsappNumber: phoneNumber,
      direction: 'outgoing',
      status: 'sent',
      notes: notes || `WhatsApp opened for ${selectedClient?.name || phoneNumber}`,
      messageBody: messageText || 'WhatsApp conversation initiated',
    });

    // Save as client default if toggled
    if (saveAsClientDefault && selectedClient) {
      updateClient(selectedClient.id, { whatsappNumber: phoneNumber });
    }

    
    if (quickRemindDays !== null && selectedClient) {
      const followUpDate = new Date();
      followUpDate.setDate(followUpDate.getDate() + quickRemindDays);
      const followUpDateStr = followUpDate.toISOString().split('T')[0];
      
      updateClient(selectedClient.id, {
        nextFollowUpDate: followUpDateStr,
        nextFollowUpNote: notes.trim(),
        nextFollowUpType: channel
      });
      
      addFollowUp({
        title: `Follow up: ${selectedClient.name}`,
        clientId: selectedClient.id,
        projectId: selectedProjectId || undefined,
        type: channel === 'call' ? 'call' : channel === 'whatsapp' ? 'whatsapp' : 'email',
        priority: quickRemindDays <= 1 ? 'high' : 'medium',
        dueDate: followUpDateStr,
        notes: notes.trim()
      });
    }
  
    window.open(waUrl, '_blank', 'noopener,noreferrer');
    onClose();
  };

  const handleSendSMS = () => {
    const rawNumber = cleanPhoneForUrl(phoneNumber);
    if (!rawNumber) {
      alert('Please enter or select a phone number.');
      return;
    }
    const encodedBody = encodeURIComponent(messageText);
    const smsUrl = `sms:${rawNumber}?body=${encodedBody}`;

    // Log to unified communication log
    addCommLog({
      channel: 'sms',
      clientId: selectedClientId || 'guest',
      projectId: selectedProjectId || undefined,
      phoneNumber: phoneNumber,
      direction: 'outgoing',
      status: 'sent',
      notes: notes || `SMS sent to ${selectedClient?.name || phoneNumber}`,
      messageBody: messageText || 'SMS message sent',
    });

    // Also copy to clipboard for convenience
    if (navigator.clipboard && messageText) {
      navigator.clipboard.writeText(messageText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }

    
    if (quickRemindDays !== null && selectedClient) {
      const followUpDate = new Date();
      followUpDate.setDate(followUpDate.getDate() + quickRemindDays);
      const followUpDateStr = followUpDate.toISOString().split('T')[0];
      
      updateClient(selectedClient.id, {
        nextFollowUpDate: followUpDateStr,
        nextFollowUpNote: notes.trim(),
        nextFollowUpType: channel
      });
      
      addFollowUp({
        title: `Follow up: ${selectedClient.name}`,
        clientId: selectedClient.id,
        projectId: selectedProjectId || undefined,
        type: channel === 'call' ? 'call' : channel === 'whatsapp' ? 'whatsapp' : 'email',
        priority: quickRemindDays <= 1 ? 'high' : 'medium',
        dueDate: followUpDateStr,
        notes: notes.trim()
      });
    }
  
    window.location.href = smsUrl;
    setTimeout(() => {
      onClose();
    }, 500);
  };

  const handleLogCall = () => {
    const rawNumber = phoneNumber;
    if (!rawNumber) {
      alert('Please enter or select a phone number.');
      return;
    }

    addCommLog({
      channel: 'call',
      clientId: selectedClientId || 'guest',
      projectId: selectedProjectId || undefined,
      phoneNumber: rawNumber,
      direction: 'outgoing',
      status: 'completed',
      durationSeconds: callDuration * 60,
      notes: notes || `Call completed with ${selectedClient?.name || phoneNumber}. Duration: ${callDuration} mins.`,
      messageBody: `Call duration: ${callDuration} minutes · Connected`,
    });

    
    if (quickRemindDays !== null && selectedClient) {
      const followUpDate = new Date();
      followUpDate.setDate(followUpDate.getDate() + quickRemindDays);
      const followUpDateStr = followUpDate.toISOString().split('T')[0];
      
      updateClient(selectedClient.id, {
        nextFollowUpDate: followUpDateStr,
        nextFollowUpNote: notes.trim(),
        nextFollowUpType: channel
      });
      
      addFollowUp({
        title: `Follow up: ${selectedClient.name}`,
        clientId: selectedClient.id,
        projectId: selectedProjectId || undefined,
        type: channel === 'call' ? 'call' : channel === 'whatsapp' ? 'whatsapp' : 'email',
        priority: quickRemindDays <= 1 ? 'high' : 'medium',
        dueDate: followUpDateStr,
        notes: notes.trim()
      });
    }
  
    onClose();
  };

  const handleDialNumber = () => {
    if (!phoneNumber) return;
    window.location.href = `tel:${cleanPhoneForUrl(phoneNumber)}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-xl rounded-2xl border shadow-2xl overflow-hidden flex flex-col max-h-[92vh] ${tokens.surface} ${tokens.border}`}
      >
        {/* Header */}
        <div
          className={`px-5 py-3.5 border-b flex items-center justify-between ${tokens.border} ${tokens.bgSubtle}`}
        >
          <div className="flex items-center gap-2.5">
            <div
              className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                channel === 'whatsapp'
                  ? 'bg-emerald-500/20 text-emerald-400'
                  : channel === 'sms'
                  ? 'bg-blue-500/20 text-blue-400'
                  : 'bg-amber-500/20 text-amber-400'
              }`}
            >
              {channel === 'whatsapp' && <MessageSquare className="w-4 h-4" />}
              {channel === 'sms' && <Send className="w-4 h-4" />}
              {channel === 'call' && <Phone className="w-4 h-4" />}
            </div>
            <div>
              <h3 className="font-display text-lg tracking-tight font-semibold">
                Universal Communication Hub
              </h3>
              <p className={`text-[11px] font-mono ${tokens.textSecondary}`}>
                Direct WhatsApp, SMS text & Call logging from one place
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-lg ${tokens.textMuted} hover:${tokens.textPrimary} transition-colors`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs font-mono">
          {/* Channel Selector: WhatsApp | SMS | Phone Call */}
          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1.5 ${tokens.textMuted}`}>
              Communication Channel
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setChannel('whatsapp')}
                className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 transition-all cursor-pointer font-semibold ${
                  channel === 'whatsapp'
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50 shadow-xs'
                    : `${tokens.surfaceElevated} ${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                <span>WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={() => setChannel('sms')}
                className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 transition-all cursor-pointer font-semibold ${
                  channel === 'sms'
                    ? 'bg-blue-500/20 text-blue-400 border-blue-500/50 shadow-xs'
                    : `${tokens.surfaceElevated} ${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                <Send className="w-3.5 h-3.5 text-blue-400" />
                <span>SMS Text</span>
              </button>

              <button
                type="button"
                onClick={() => setChannel('call')}
                className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 transition-all cursor-pointer font-semibold ${
                  channel === 'call'
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/50 shadow-xs'
                    : `${tokens.surfaceElevated} ${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>Call Log</span>
              </button>
            </div>
          </div>

          {/* Client & Project Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Client Recipient
              </label>
              <select
                value={selectedClientId}
                onChange={(e) => setSelectedClientId(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
              >
                <option value="" className="bg-stone-900 text-stone-100">
                  -- Custom / Direct Number --
                </option>
                {clients.map((c) => (
                  <option key={c.id} value={c.id} className="bg-stone-900 text-stone-100">
                    {c.name} ({c.company})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                Related Project
              </label>
              <select
                value={selectedProjectId}
                onChange={(e) => setSelectedProjectId(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
              >
                <option value="" className="bg-stone-900 text-stone-100">
                  -- Select Project --
                </option>
                {projects.map((p) => (
                  <option key={p.id} value={p.id} className="bg-stone-900 text-stone-100">
                    {p.title} ({p.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Manchaha WhatsApp / Phone Number Input */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className={`text-[10px] uppercase font-bold tracking-wider ${tokens.textMuted}`}>
                {channel === 'whatsapp'
                  ? 'Manchaha WhatsApp Number (Custom or Client)'
                  : 'Recipient Mobile Number'}
              </label>
              {selectedClient && selectedClient.whatsappNumber && channel === 'whatsapp' && (
                <span className="text-[10px] text-emerald-400 font-mono">
                  Saved: {selectedClient.whatsappNumber}
                </span>
              )}
            </div>
            <div className="relative">
              <input
                type="text"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="+91 98200 41122 or any country code number"
                className={`w-full px-3 py-2.5 rounded-xl border bg-transparent text-sm font-mono font-medium ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
              />
              <div className="absolute right-2 top-2 flex items-center gap-1">
                <button
                  type="button"
                  onClick={handleDialNumber}
                  className="p-1 rounded bg-stone-500/20 text-stone-300 hover:text-white"
                  title="Direct Phone Dial"
                >
                  <Phone className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {selectedClient && (
              <label className="flex items-center gap-2 mt-1.5 text-[11px] text-stone-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={saveAsClientDefault}
                  onChange={(e) => setSaveAsClientDefault(e.target.checked)}
                  className="rounded border-stone-500"
                />
                <span>Save this number as permanent WhatsApp number for {selectedClient.name}</span>
              </label>
            )}
          </div>

          {/* Quick Message Templates (for WhatsApp & SMS) */}
          {channel !== 'call' && (
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className={`text-[10px] uppercase font-bold tracking-wider ${tokens.textMuted}`}>
                  Quick Siyaram Message Templates
                </label>
                <span className="text-[10px] text-stone-400">Click to load</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {templates.map((tpl, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setMessageText(tpl.text)}
                    className={`px-2.5 py-1 rounded-lg border text-[11px] font-medium transition-all text-left ${tokens.surfaceElevated} ${tokens.border} hover:border-stone-400`}
                  >
                    {tpl.title}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Message Body (for WhatsApp & SMS) */}
          {channel !== 'call' && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className={`text-[10px] uppercase font-bold tracking-wider ${tokens.textMuted}`}>
                  Message Content
                </label>
                {copied && (
                  <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
                    <Check className="w-3 h-3" /> Copied to clipboard
                  </span>
                )}
              </div>
              <textarea
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                rows={4}
                placeholder="Type your WhatsApp message or SMS text here..."
                className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs leading-relaxed font-sans ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
              />
            </div>
          )}

          {/* Call specifics (Duration & Audio Notes) */}
          {channel === 'call' && (
            <div className="grid grid-cols-2 gap-3 p-3 rounded-xl bg-stone-500/10 border border-inherit">
              <div>
                <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                  Call Duration (Minutes)
                </label>
                <input
                  type="number"
                  min={1}
                  max={120}
                  value={callDuration}
                  onChange={(e) => setCallDuration(Number(e.target.value))}
                  className={`w-full px-3 py-2 rounded-lg border bg-transparent text-xs font-mono ${tokens.border}`}
                />
              </div>

              <div>
                <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
                  Record Audio Note
                </label>
                <button
                  type="button"
                  onClick={() => {
                    if (onOpenVoiceRecorder) {
                      onOpenVoiceRecorder(selectedClientId, selectedProjectId);
                      onClose();
                    }
                  }}
                  className={`w-full py-2 px-3 rounded-lg border flex items-center justify-center gap-1.5 font-semibold text-xs transition-colors ${tokens.accentBtn}`}
                >
                  <Mic className="w-3.5 h-3.5" />
                  <span>Start Voice Recording</span>
                </button>
              </div>
            </div>
          )}

          {/* Internal Log Notes */}
          <div>
            <label className={`block text-[10px] uppercase font-bold tracking-wider mb-1 ${tokens.textMuted}`}>
              CRM Call / Interaction Summary Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Inquired about Siyaram 250 sq.yd plot price, requested site visit tomorrow"
              className={`w-full px-3 py-2 rounded-xl border bg-transparent text-xs ${tokens.border} focus:outline-hidden focus:ring-1 focus:ring-stone-400`}
            />
          </div>
          <div className="flex items-center gap-2 mt-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500">Quick Remind:</span>
            {[
              { label: '+1 Day', days: 1 },
              { label: '+3 Days', days: 3 },
              { label: '+1 Week', days: 7 }
            ].map(opt => (
              <button
                key={opt.days}
                type="button"
                onClick={() => setQuickRemindDays(quickRemindDays === opt.days ? null : opt.days)}
                className={`px-2 py-1 rounded border text-[10px] font-semibold transition-colors ${
                  quickRemindDays === opt.days 
                    ? `${tokens.accentBgTint} ${tokens.accentText} border-current`
                    : `bg-transparent ${tokens.border} ${tokens.textSecondary} hover:${tokens.surfaceHover}`
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Modal Footer / Action Buttons */}
        <div
          className={`px-5 py-3.5 border-t flex flex-wrap items-center justify-between gap-3 ${tokens.border} ${tokens.bgSubtle}`}
        >
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className={`px-3 py-2 rounded-xl border text-xs font-semibold ${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary}`}
            >
              Cancel
            </button>
          </div>

          <div className="flex items-center gap-2">
            {channel === 'whatsapp' && (
              <button
                type="button"
                onClick={handleOpenWhatsApp}
                className="px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white shadow-md transition-all cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Open in WhatsApp & Log</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            )}

            {channel === 'sms' && (
              <button
                type="button"
                onClick={handleSendSMS}
                className="px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white shadow-md transition-all cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Send SMS & Save Log</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            )}

            {channel === 'call' && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDialNumber}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold border flex items-center gap-1.5 ${tokens.border}`}
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Dial Now</span>
                </button>
                <button
                  type="button"
                  onClick={handleLogCall}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md ${tokens.accentBtn}`}
                >
                  <Check className="w-4 h-4" />
                  <span>Save Call Log</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
