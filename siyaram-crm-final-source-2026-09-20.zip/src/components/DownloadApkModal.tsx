import React, { useState } from 'react';
import {
  Smartphone,
  Copy,
  Check,
  X,
  Info,
  Sparkles,
  QrCode,
  CheckCircle2,
  Share2
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface DownloadApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadApkModal: React.FC<DownloadApkModalProps> = ({ isOpen, onClose }) => {
  const { theme, tokens } = useTheme();
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [copiedAppUrl, setCopiedAppUrl] = useState(false);
  const [activeTab, setActiveTab] = useState<'install' | 'qr'>('install');

  if (!isOpen) return null;

  const currentAppUrl = typeof window !== 'undefined' ? window.location.origin : '';

  // QR Code URL using public QR API
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=10&data=${encodeURIComponent(
    currentAppUrl
  )}`;

  const handleCopyAppUrl = async () => {
    try {
      await navigator.clipboard.writeText(currentAppUrl);
      setCopiedAppUrl(true);
      setTimeout(() => setCopiedAppUrl(false), 2500);
    } catch {
      setCopiedAppUrl(true);
      setTimeout(() => setCopiedAppUrl(false), 2500);
    }
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(`Siyaram Estates CRM App (Phone me open karke Install karein):\n${currentAppUrl}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const card3D = `${tokens.surface} ${tokens.border} ${tokens.surfaceHover}`;

  return (
    <div
      id="apk-download-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className={`relative w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[92vh] ${
          theme === 'dark'
            ? 'bg-[#0f1115]/95 border-white/10 text-stone-100'
            : 'bg-white/95 border-slate-200/80 text-slate-900'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className={`px-5 py-4 border-b flex items-center justify-between ${
            theme === 'dark' ? 'border-white/10 bg-white/5' : 'border-slate-200 bg-slate-50/80'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-500 shadow-sm">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-display text-lg font-bold tracking-tight">
                  Install Siyaram CRM on Phone
                </h3>
                <span className="text-[10px] font-mono font-bold uppercase px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                  Android & WebAPK
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-stone-400">
                Install directly via Chrome PWA (Add to Home screen) or scan QR code
              </p>
            </div>
          </div>

          <button
            id="close-apk-modal-btn"
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 text-slate-400 hover:text-slate-700 dark:hover:text-stone-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher - only 'install' and 'qr' tabs */}
        <div className="px-5 pt-3">
          <div className="flex items-center p-1 rounded-2xl bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10">
            <button
              type="button"
              id="tab-install-pwa"
              onClick={() => setActiveTab('install')}
              className={`flex-1 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'install'
                  ? 'bg-amber-500 text-slate-950 shadow-sm font-bold'
                  : 'text-slate-500 hover:text-slate-800 dark:text-stone-400'
              }`}
            >
              1-Click Install
            </button>
            <button
              type="button"
              id="tab-qr-code"
              onClick={() => setActiveTab('qr')}
              className={`flex-1 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'qr'
                  ? 'bg-amber-500 text-slate-950 shadow-sm font-bold'
                  : 'text-slate-500 hover:text-slate-800 dark:text-stone-400'
              }`}
            >
              Scan QR Code
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* TAB 1: 1-Click Install */}
          {activeTab === 'install' && (
            <div className="space-y-3">
              <div className={`p-4 rounded-2xl border ${card3D} space-y-3`}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" /> Official Android WebAPK
                    </span>
                    <h4 className="font-bold text-sm text-slate-900 dark:text-stone-100 mt-1">
                      Phone me direct app install karein
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-stone-400 mt-0.5 leading-relaxed">
                      Android par Google Chrome is app ko automatic signed APK me convert karke home screen par install kar deta hai (No file download needed).
                    </p>
                  </div>
                </div>

                {/* If install prompt is ready */}
                {isInstallable ? (
                  <button
                    id="btn-install-app-pwa"
                    type="button"
                    onClick={install}
                    className="w-full py-3 px-4 rounded-2xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20 transition-all"
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>Install Siyaram CRM on this Phone</span>
                  </button>
                ) : isInstalled ? (
                  <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center gap-2 font-medium">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>App already installed on this device!</span>
                  </div>
                ) : (
                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 space-y-1.5 text-slate-700 dark:text-stone-300">
                    <div className="font-bold text-xs text-amber-700 dark:text-amber-400 flex items-center gap-1.5">
                      <Info className="w-4 h-4" />
                      <span>Phone me install karne ke 3 simple steps:</span>
                    </div>
                    <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-600 dark:text-stone-300 leading-relaxed">
                      <li>
                        Apne phone ke <strong>Google Chrome</strong> me yeh URL open karein.
                      </li>
                      <li>
                        Upar right side me <strong>3 dots menu (⋮)</strong> par tap karein.
                      </li>
                      <li>
                        <strong>"Install app"</strong> ya <strong>"Add to Home screen"</strong> par tap karein.
                      </li>
                    </ol>
                  </div>
                )}

                {/* WhatsApp Share Action */}
                <button
                  type="button"
                  onClick={handleShareWhatsApp}
                  className="w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-sm"
                >
                  <Share2 className="w-4 h-4" />
                  <span>WhatsApp par App Link Bhejein (Phone me Install karein)</span>
                </button>

                {/* App URL Copy Box */}
                <div className="pt-2">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-slate-400 dark:text-stone-400 mb-1">
                    App URL (Apne phone me open karein):
                  </label>
                  <div className="flex items-center gap-1.5 p-1.5 rounded-xl bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 font-mono text-[11px]">
                    <input
                      type="text"
                      readOnly
                      value={currentAppUrl}
                      className="bg-transparent border-none outline-none flex-1 truncate px-1 text-slate-700 dark:text-stone-300"
                    />
                    <button
                      type="button"
                      onClick={handleCopyAppUrl}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 bg-amber-500 text-slate-950 hover:bg-amber-400 cursor-pointer transition-all"
                    >
                      {copiedAppUrl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedAppUrl ? 'Copied' : 'Copy URL'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Scan QR Code */}
          {activeTab === 'qr' && (
            <div className="space-y-3">
              <div className={`p-4 rounded-2xl border ${card3D} flex flex-col items-center text-center space-y-3`}>
                <div className="text-xs font-bold text-slate-900 dark:text-stone-100 flex items-center gap-1.5">
                  <QrCode className="w-4 h-4 text-amber-500" />
                  <span>Phone camera se QR Code scan karein</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-stone-400 max-w-xs">
                  Apne phone ka Camera ya Google Lens open karke is QR Code ko scan karein, link direct aapke phone par khul jayega:
                </p>

                <div className="p-3 bg-white rounded-2xl border-2 border-amber-500/30 shadow-md">
                  <img
                    src={qrCodeUrl}
                    alt="Scan QR Code to open on phone"
                    className="w-44 h-44 rounded-xl"
                  />
                </div>

                <div className="text-[11px] font-mono text-slate-500 dark:text-stone-400">
                  Scan karne ke baad Chrome me <strong>"Install"</strong> par tap karein.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div
          className={`px-5 py-3 border-t flex items-center justify-between text-[11px] font-mono ${
            theme === 'dark' ? 'border-white/10 bg-white/5 text-stone-400' : 'border-slate-200 bg-slate-50 text-slate-500'
          }`}
        >
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-slate-700 dark:text-stone-300 font-semibold">Ready for Mobile Install</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl font-medium text-xs bg-slate-200 dark:bg-white/10 text-slate-800 dark:text-white hover:bg-slate-300 dark:hover:bg-white/20 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
