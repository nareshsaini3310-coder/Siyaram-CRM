import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Mic,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  Clock,
  Calendar,
  Volume2,
  CheckCircle2,
  ListTodo,
  FileText,
  FastForward,
} from 'lucide-react';
import { VoiceRecording } from '../types';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';

interface ExpandableVoiceRecordingItemProps {
  recording: VoiceRecording;
  clientName?: string;
  projectName?: string;
  initialExpanded?: boolean;
  onOpenVoiceRecorder?: (clientId?: string, projectId?: string) => void;
  className?: string;
}

export const ExpandableVoiceRecordingItem: React.FC<ExpandableVoiceRecordingItemProps> = ({
  recording,
  clientName,
  projectName,
  initialExpanded = false,
  onOpenVoiceRecorder,
  className = '',
}) => {
  const { tokens, theme, accent } = useTheme();
  const [isExpanded, setIsExpanded] = useState(initialExpanded);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [playbackRate, setPlaybackRate] = useState<number>(1.0);
  const [copied, setCopied] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<number | null>(null);
  const waveformRef = useRef<HTMLDivElement | null>(null);

  const totalDuration = Math.max(recording.durationSeconds || 45, 1);

  // Generate a deterministic waveform bar height profile (40 bars) based on recording id
  const waveformBars = useMemo(() => {
    const seedStr = recording.id + recording.title + (recording.transcription || '');
    let hash = 0;
    for (let i = 0; i < seedStr.length; i++) {
      hash = (hash << 5) - hash + seedStr.charCodeAt(i);
      hash |= 0;
    }

    const bars: number[] = [];
    const count = 38;
    for (let i = 0; i < count; i++) {
      // Create a natural speech pattern: quieter at ends, varied dynamics in middle
      const posRatio = Math.sin((i / (count - 1)) * Math.PI);
      const pseudoRand = Math.abs(Math.sin(hash * 0.17 + i * 1.34));
      const heightPercent = Math.min(
        100,
        Math.max(18, Math.round(posRatio * 60 + pseudoRand * 40))
      );
      bars.push(heightPercent);
    }
    return bars;
  }, [recording.id, recording.title, recording.transcription]);

  // Audio element event bindings if real audioBlobUrl exists
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
      haptics.light();
    };

    const handlePause = () => {
      setIsPlaying(false);
    };

    const handlePlay = () => {
      setIsPlaying(true);
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('play', handlePlay);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('play', handlePlay);
    };
  }, [recording.audioBlobUrl]);

  // Simulated audio playback ticker if no real audio element or audio fails
  useEffect(() => {
    if (!isPlaying) {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      return;
    }

    // If real audio element exists with a valid source, let it drive currentTime
    if (recording.audioBlobUrl && audioRef.current) {
      audioRef.current.playbackRate = playbackRate;
      return;
    }

    // Fallback: smooth simulated playback ticker
    const intervalMs = 100;
    timerRef.current = window.setInterval(() => {
      setCurrentTime((prev) => {
        const next = prev + (intervalMs / 1000) * playbackRate;
        if (next >= totalDuration) {
          setIsPlaying(false);
          haptics.light();
          return 0;
        }
        return next;
      });
    }, intervalMs);

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [isPlaying, playbackRate, totalDuration, recording.audioBlobUrl]);

  // Stop playback when collapsed
  useEffect(() => {
    if (!isExpanded && isPlaying) {
      handlePause();
    }
  }, [isExpanded]);

  const handlePlay = () => {
    haptics.medium();
    setIsPlaying(true);
    if (audioRef.current && recording.audioBlobUrl) {
      audioRef.current.playbackRate = playbackRate;
      audioRef.current.play().catch(() => {
        // Fallback to simulated playback if browser blocks autoplay or blob expired
      });
    }
  };

  const handlePause = () => {
    haptics.selection();
    setIsPlaying(false);
    if (audioRef.current && recording.audioBlobUrl) {
      audioRef.current.pause();
    }
  };

  const handleTogglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isPlaying) {
      handlePause();
    } else {
      handlePlay();
    }
  };

  const handleRestart = (e: React.MouseEvent) => {
    e.stopPropagation();
    haptics.light();
    setCurrentTime(0);
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
    }
  };

  const handleCycleSpeed = (e: React.MouseEvent) => {
    e.stopPropagation();
    haptics.selection();
    const speeds = [1.0, 1.25, 1.5, 2.0];
    const nextIdx = (speeds.indexOf(playbackRate) + 1) % speeds.length;
    const nextSpeed = speeds[nextIdx];
    setPlaybackRate(nextSpeed);
    if (audioRef.current) {
      audioRef.current.playbackRate = nextSpeed;
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (!waveformRef.current) return;
    const rect = waveformRef.current.getBoundingClientRect();
    const clickX = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const ratio = clickX / rect.width;
    const seekTime = ratio * totalDuration;

    haptics.selection();
    setCurrentTime(seekTime);
    if (audioRef.current && recording.audioBlobUrl) {
      audioRef.current.currentTime = seekTime;
    }
  };

  const handleCopyTranscription = (e: React.MouseEvent) => {
    e.stopPropagation();
    haptics.success();
    if (recording.transcription) {
      navigator.clipboard.writeText(recording.transcription);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const toggleExpand = () => {
    haptics.selection();
    setIsExpanded((prev) => !prev);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercent = Math.min(100, (currentTime / totalDuration) * 100);

  return (
    <div
      id={`voice-note-${recording.id}`}
      className={`rounded-2xl border transition-all duration-200 overflow-hidden ${tokens.surfaceElevated} ${tokens.border} ${
        isExpanded ? 'shadow-md ring-1 ring-amber-500/25' : 'hover:border-amber-500/30'
      } ${className}`}
    >
      {/* Hidden HTML5 Audio Element for Real Audio Payback */}
      {recording.audioBlobUrl && (
        <audio
          ref={audioRef}
          src={recording.audioBlobUrl}
          preload="metadata"
          className="hidden"
        />
      )}

      {/* Main Header / Clickable Card Surface */}
      <div
        onClick={toggleExpand}
        role="button"
        tabIndex={0}
        aria-expanded={isExpanded}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            toggleExpand();
          }
        }}
        className="p-4 cursor-pointer select-none transition-colors hover:bg-stone-500/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            {/* Mic Badge */}
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border transition-transform ${
                isExpanded ? 'scale-105' : ''
              } ${
                isPlaying
                  ? 'bg-amber-500/20 text-amber-500 border-amber-500/50 shadow-sm shadow-amber-500/20'
                  : 'bg-purple-500/15 text-purple-600 dark:text-purple-400 border-purple-500/30'
              }`}
            >
              {isPlaying ? (
                <Volume2 className="w-5 h-5 animate-pulse" />
              ) : (
                <Mic className="w-5 h-5" />
              )}
            </div>

            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h4 className="font-semibold text-sm leading-snug truncate">
                  {recording.title}
                </h4>

                {/* Duration Badge */}
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-semibold bg-stone-500/15 text-stone-400 dark:text-stone-300 flex items-center gap-1">
                  <Clock className="w-2.5 h-2.5" />
                  {formatTime(totalDuration)}
                </span>

                {/* Live Status Pill */}
                {isPlaying && (
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full font-bold bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/40 flex items-center gap-1 animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                    Playing
                  </span>
                )}
              </div>

              {/* Metadata Subline */}
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-mono text-stone-400 mt-1">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-stone-500" />
                  {new Date(recording.createdAt).toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  })}
                </span>
                {clientName && (
                  <span className="truncate max-w-[140px] text-stone-600 dark:text-stone-300">
                    • Client: {clientName}
                  </span>
                )}
                {projectName && (
                  <span className="truncate max-w-[140px] text-stone-600 dark:text-stone-300">
                    • Project: {projectName}
                  </span>
                )}
              </div>

              {/* Collapsed Snippet Teaser */}
              {!isExpanded && recording.transcription && (
                <p className="text-xs text-stone-500 dark:text-stone-400 mt-2 line-clamp-1 italic font-serif">
                  "{recording.transcription}"
                </p>
              )}
            </div>
          </div>

          {/* Right Action: Expand/Collapse Chevron Button */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                toggleExpand();
              }}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 border transition-all cursor-pointer ${
                isExpanded
                  ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30'
                  : 'bg-stone-500/10 hover:bg-stone-500/20 text-stone-400 dark:text-stone-300 border-stone-500/20'
              }`}
              title={isExpanded ? 'Collapse note' : 'Expand note'}
            >
              <span className="hidden sm:inline text-[11px]">
                {isExpanded ? 'Collapse' : 'Expand Note'}
              </span>
              {isExpanded ? (
                <ChevronUp className="w-3.5 h-3.5" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Expandable Body: Transcript / Notes & Waveform Visualizer */}
      <AnimatePresence initial={false}>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="border-t border-inherit"
          >
            <div className="p-4 sm:p-5 space-y-4 bg-stone-500/5 dark:bg-stone-900/40">
              {/* 1. PLAY / PAUSE WAVEFORM VISUALIZATION BAR */}
              <div className="p-3.5 sm:p-4 rounded-xl border border-stone-200/80 dark:border-stone-800 bg-white/70 dark:bg-stone-950/70 backdrop-blur-sm shadow-xs space-y-3">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    {/* Play/Pause Button */}
                    <button
                      type="button"
                      onClick={handleTogglePlay}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center font-semibold transition-all cursor-pointer shadow-xs ${
                        isPlaying
                          ? 'bg-amber-500 text-stone-950 hover:bg-amber-400'
                          : 'bg-amber-500/20 text-amber-700 dark:text-amber-400 border border-amber-500/40 hover:bg-amber-500/30'
                      }`}
                      title={isPlaying ? 'Pause Audio' : 'Play Audio Memo'}
                    >
                      {isPlaying ? (
                        <Pause className="w-4 h-4 fill-current" />
                      ) : (
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      )}
                    </button>

                    {/* Reset Button */}
                    <button
                      type="button"
                      onClick={handleRestart}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-stone-400 hover:text-stone-200 hover:bg-stone-500/15 transition-colors cursor-pointer"
                      title="Restart from beginning"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>

                    {/* Speed Selector */}
                    <button
                      type="button"
                      onClick={handleCycleSpeed}
                      className="px-2 py-1 rounded-lg text-[11px] font-mono font-bold text-stone-400 hover:text-stone-200 hover:bg-stone-500/15 border border-stone-500/20 transition-colors cursor-pointer"
                      title="Toggle playback speed (1x, 1.25x, 1.5x, 2x)"
                    >
                      {playbackRate}x
                    </button>
                  </div>

                  {/* Timer Display */}
                  <div className="font-mono text-xs font-semibold text-stone-600 dark:text-stone-300 flex items-center gap-1.5">
                    <span className="text-amber-600 dark:text-amber-400">
                      {formatTime(currentTime)}
                    </span>
                    <span className="text-stone-400">/</span>
                    <span className="text-stone-500">{formatTime(totalDuration)}</span>
                  </div>
                </div>

                {/* Waveform Visualization Canvas / Track */}
                <div
                  ref={waveformRef}
                  onClick={handleSeek}
                  className="relative h-12 flex items-center gap-1 px-1 cursor-pointer select-none group"
                  title="Click anywhere to scrub playback position"
                >
                  {waveformBars.map((barHeight, idx) => {
                    const barRatio = idx / waveformBars.length;
                    const currentRatio = currentTime / totalDuration;
                    const isPlayed = barRatio <= currentRatio;
                    const isCurrent =
                      Math.abs(barRatio - currentRatio) < 1 / waveformBars.length;

                    return (
                      <div
                        key={idx}
                        className="flex-1 h-full flex items-center justify-center"
                      >
                        <div
                          style={{
                            height: `${barHeight}%`,
                          }}
                          className={`w-full max-w-[5px] rounded-full transition-all duration-100 ${
                            isPlayed
                              ? isPlaying && isCurrent
                                ? 'bg-amber-400 shadow-sm shadow-amber-400/50 scale-y-110'
                                : 'bg-amber-500/90 dark:bg-amber-400'
                              : 'bg-stone-300 dark:bg-stone-700/80 group-hover:bg-stone-400 dark:group-hover:bg-stone-600'
                          }`}
                        />
                      </div>
                    );
                  })}

                  {/* Progress Line Indicator */}
                  <div
                    style={{ left: `${progressPercent}%` }}
                    className="absolute top-0 bottom-0 w-0.5 bg-amber-500 shadow-sm shadow-amber-500/50 pointer-events-none transition-all duration-75"
                  />
                </div>

                <div className="flex items-center justify-between text-[10px] font-mono text-stone-400 px-1">
                  <span>Interactive Audio Waveform</span>
                  <span className="italic">Tap bars to jump/scrub</span>
                </div>
              </div>

              {/* 2. AUTO-GENERATED TRANSCRIPTION SECTION */}
              <div className="p-4 rounded-xl border border-stone-200/80 dark:border-stone-800/80 bg-white/60 dark:bg-stone-900/60 backdrop-blur-xs space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded-md bg-amber-500/20 text-amber-500">
                      <Sparkles className="w-3.5 h-3.5" />
                    </span>
                    <span className="text-xs font-bold uppercase tracking-wider font-mono text-stone-700 dark:text-stone-200">
                      Transcript / Notes
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-medium">
                      Manual Transcript
                    </span>
                  </div>

                  {/* Copy Button */}
                  <button
                    type="button"
                    onClick={handleCopyTranscription}
                    className="px-2 py-1 rounded-lg text-xs font-mono text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-stone-200 hover:bg-stone-500/10 flex items-center gap-1 transition-colors cursor-pointer"
                    title="Copy full transcription to clipboard"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-500" />
                        <span className="text-emerald-500 font-semibold">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Transcription Text Block */}
                <div className="p-3 rounded-lg bg-stone-100/70 dark:bg-stone-950/70 border border-stone-200/60 dark:border-stone-800/60 text-xs text-stone-800 dark:text-stone-200 leading-relaxed font-serif">
                  {recording.transcription ? (
                    <p className="whitespace-pre-line">{recording.transcription}</p>
                  ) : (
                    <p className="text-stone-400 italic">
                      Audio processing complete. No transcription text available for this memo.
                    </p>
                  )}
                </div>

                {/* Summary (if available) */}
                {recording.summary && (
                  <div className="text-xs text-stone-600 dark:text-stone-300 font-sans pt-1">
                    <span className="font-semibold text-stone-700 dark:text-stone-200 font-mono text-[11px] uppercase tracking-wider block mb-0.5">
                      Executive Summary:
                    </span>
                    <p className="leading-relaxed">{recording.summary}</p>
                  </div>
                )}
              </div>

              {/* 3. EXTRACTED ACTION ITEMS (if available) */}
              {recording.actionItems && recording.actionItems.length > 0 && (
                <div className="p-3.5 rounded-xl border border-stone-200/80 dark:border-stone-800/80 bg-white/40 dark:bg-stone-900/40 space-y-2">
                  <div className="flex items-center gap-1.5 text-[11px] font-mono font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400">
                    <ListTodo className="w-3.5 h-3.5 text-amber-500" />
                    <span>Identified Action Items ({recording.actionItems.length})</span>
                  </div>
                  <ul className="space-y-1.5 text-xs text-stone-700 dark:text-stone-200">
                    {recording.actionItems.map((action, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 text-amber-500 shrink-0" />
                        <span className="leading-snug">{action}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
