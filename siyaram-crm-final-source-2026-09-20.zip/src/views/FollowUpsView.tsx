import React, { useState, useMemo } from 'react';
import { Clock, CalendarClock, CheckCircle2, Plus, Phone, Mail, Users, Briefcase, AlertCircle, Mic, Trash2, X, Filter, ArrowUpDown, Smartphone, Download, Flame, Calendar, Layers, MessageSquare, ExternalLink, ChevronDown, Check, Sparkles, MapPin, Bell } from 'lucide-react';
import { EmptyStatePlaceholder } from '../components/EmptyStatePlaceholder';
import { getLastConversationSummary, getLinkedProjectTitle } from '../utils/notificationEngine';


import { FollowUp, FollowUpType, FollowUpPriority } from '../types';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';
import { useData } from '../context/DataContext';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { DownloadApkModal } from '../components/DownloadApkModal';

interface FollowUpsViewProps {
  onSelectClient: (clientId: string) => void;
  onSelectProject: (projectId: string) => void;
  onOpenVoiceRecorder: (clientId?: string, projectId?: string, followUpId?: string) => void;
  searchQuery: string;
}

type TimelineGroup = 'overdue' | 'today' | 'this_week' | 'later' | 'completed';
type SortOption = 'dueDate_asc' | 'dueDate_desc' | 'priority_high' | 'client_name';

export const FollowUpsView: React.FC<FollowUpsViewProps> = ({
  onSelectClient,
  onSelectProject,
  onOpenVoiceRecorder,
  searchQuery,
}) => {
  const { theme, tokens, accent } = useTheme();
  const {
    followUps,
    clients,
    projects,
    commLogs,
    addFollowUp,
    toggleFollowUpStatus,
    deleteFollowUp,
  } = useData();

  // Active filter tab: 'all' | 'overdue' | 'today' | 'this_week' | 'later' | 'completed'
  const [activeTab, setActiveTab] = useState<'all' | 'overdue' | 'today' | 'this_week' | 'later' | 'completed'>('all');
  const [followUpToDelete, setFollowUpToDelete] = useState<string | null>(null);
  
  // Grouping layout: 'grouped' (separate sections) or 'flat' (continuous list)
  const [isGroupedView, setIsGroupedView] = useState<boolean>(true);
  
  // Client-side Sort
  const [sortBy, setSortBy] = useState<SortOption>('dueDate_asc');

  // Channel Filter: 'all' | 'call' | 'whatsapp' | 'meeting' | 'email' | 'sms'
  const [channelFilter, setChannelFilter] = useState<string>('all');
  
  // Quick toggle: Only show Phone Calls (ideal for call scheduling)
  const [onlyCalls, setOnlyCalls] = useState<boolean>(false);

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  // New Follow-up form state
  const [newTitle, setNewTitle] = useState('');
  const [newClientId, setNewClientId] = useState('');
  const [newProjectId, setNewProjectId] = useState('prj-1'); // Default to Siyaram Estates
  const [newType, setNewType] = useState<FollowUpType>('call');
  const [newPriority, setNewPriority] = useState<FollowUpPriority>('high');
  const [newDueDate, setNewDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [newScheduledTime, setNewScheduledTime] = useState('14:30');
  const [newNotes, setNewNotes] = useState('');
  const [newCustomNumber, setNewCustomNumber] = useState('');

  // Date calculation boundaries
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  
  // End of "This Week": 7 days from today
  const endOfWeek = new Date(now);
  endOfWeek.setDate(now.getDate() + 7);
  const endOfWeekStr = endOfWeek.toISOString().split('T')[0];

  // Helper to categorize a follow-up into 'overdue' | 'today' | 'this_week' | 'later' | 'completed'
  const getTimelineBucket = (f: FollowUp): TimelineGroup => {
    if (f.status === 'completed') return 'completed';
    if (f.dueDate < todayStr) return 'overdue';
    if (f.dueDate === todayStr) return 'today';
    if (f.dueDate > todayStr && f.dueDate <= endOfWeekStr) return 'this_week';
    return 'later';
  };

  // Pre-calculate counts for quick stats badges
  const groupCounts = useMemo(() => {
    let overdue = 0;
    let today = 0;
    let thisWeek = 0;
    let later = 0;
    let completed = 0;
    let callsCount = 0;

    followUps.forEach((f) => {
      if (f.type === 'call') callsCount++;
      const bucket = getTimelineBucket(f);
      if (bucket === 'overdue') overdue++;
      else if (bucket === 'today') today++;
      else if (bucket === 'this_week') thisWeek++;
      else if (bucket === 'later') later++;
      else if (bucket === 'completed') completed++;
    });

    return { overdue, today, thisWeek, later, completed, callsCount, total: followUps.length };
  }, [followUps, todayStr, endOfWeekStr]);

  // Filter follow-ups
  const filteredFollowUps = useMemo(() => {
    return followUps.filter((f) => {
      const bucket = getTimelineBucket(f);

      // Tab filter
      if (activeTab === 'overdue' && bucket !== 'overdue') return false;
      if (activeTab === 'today' && bucket !== 'today') return false;
      if (activeTab === 'this_week' && bucket !== 'this_week') return false;
      if (activeTab === 'later' && bucket !== 'later') return false;
      if (activeTab === 'completed' && bucket !== 'completed') return false;

      // Only Phone Calls quick filter
      if (onlyCalls && f.type !== 'call') return false;

      // Channel filter
      if (channelFilter !== 'all' && f.type !== channelFilter) return false;

      // Search query filter
      const q = searchQuery.toLowerCase().trim();
      if (!q) return true;

      const client = clients.find((c) => c.id === f.clientId);
      const project = projects.find((p) => p.id === f.projectId);
      return (
        f.title.toLowerCase().includes(q) ||
        f.notes.toLowerCase().includes(q) ||
        (f.customNumber && f.customNumber.includes(q)) ||
        (client && (
          client.name.toLowerCase().includes(q) ||
          client.phone.includes(q) ||
          (client.location && client.location.toLowerCase().includes(q))
        )) ||
        (project && project.title.toLowerCase().includes(q))
      );
    });
  }, [followUps, activeTab, onlyCalls, channelFilter, searchQuery, clients, projects, todayStr, endOfWeekStr]);

  // Client-side Sorting
  const sortedFollowUps = useMemo(() => {
    const list = [...filteredFollowUps];
    const priorityWeights: Record<FollowUpPriority, number> = {
      high: 3,
      medium: 2,
      low: 1,
    };

    list.sort((a, b) => {
      if (sortBy === 'dueDate_asc') {
        // Earliest due date first (Overdue first, then today, then future)
        const dateDiff = a.dueDate.localeCompare(b.dueDate);
        if (dateDiff !== 0) return dateDiff;
        return (a.scheduledTime || '00:00').localeCompare(b.scheduledTime || '00:00');
      }

      if (sortBy === 'dueDate_desc') {
        const dateDiff = b.dueDate.localeCompare(a.dueDate);
        if (dateDiff !== 0) return dateDiff;
        return (b.scheduledTime || '00:00').localeCompare(a.scheduledTime || '00:00');
      }

      if (sortBy === 'priority_high') {
        const pDiff = priorityWeights[b.priority] - priorityWeights[a.priority];
        if (pDiff !== 0) return pDiff;
        return a.dueDate.localeCompare(b.dueDate);
      }

      if (sortBy === 'client_name') {
        const clientA = clients.find((c) => c.id === a.clientId)?.name || a.title;
        const clientB = clients.find((c) => c.id === b.clientId)?.name || b.title;
        return clientA.localeCompare(clientB);
      }

      return 0;
    });

    return list;
  }, [filteredFollowUps, sortBy, clients]);

  // Grouped buckets when `isGroupedView` is ON
  const groupedBuckets = useMemo(() => {
    const buckets: Record<TimelineGroup, FollowUp[]> = {
      overdue: [],
      today: [],
      this_week: [],
      later: [],
      completed: [],
    };

    sortedFollowUps.forEach((item) => {
      const bucket = getTimelineBucket(item);
      buckets[bucket].push(item);
    });

    return buckets;
  }, [sortedFollowUps, todayStr, endOfWeekStr]);

  // New Follow-up submit
  const handleCreateFollowUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    addFollowUp({
      title: newTitle.trim(),
      clientId: newClientId || undefined,
      projectId: newProjectId || undefined,
      type: newType,
      priority: newPriority,
      dueDate: newDueDate,
      scheduledTime: newScheduledTime,
      notes: newNotes.trim() || 'Follow up scheduled in Siyaram CRM.',
      customNumber: newCustomNumber.trim() || undefined,
    });

    setNewTitle('');
    setNewNotes('');
    setNewCustomNumber('');
    setIsCreateModalOpen(false);
  };

  // WhatsApp open helper
  const handleOpenWhatsApp = (number?: string, name?: string) => {
    if (!number) return;
    const clean = number.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(
      `Namaste ${name || ''}, greeting from Siyaram Estates. I am following up with you as scheduled.`
    );
    window.open(`https://wa.me/${clean}?text=${text}`, '_blank');
  };

  const getTypeIcon = (type: FollowUpType) => {
    switch (type) {
      case 'call':
        return <Phone className="w-3.5 h-3.5 text-blue-500" />;
      case 'whatsapp':
        return <MessageSquare className="w-3.5 h-3.5 text-emerald-500" />;
      case 'email':
        return <Mail className="w-3.5 h-3.5 text-purple-500" />;
      case 'meeting':
        return <Users className="w-3.5 h-3.5 text-amber-500" />;
      case 'sms':
        return <MessageSquare className="w-3.5 h-3.5 text-slate-500" />;
      default:
        return <CalendarClock className="w-3.5 h-3.5 text-stone-400" />;
    }
  };

  // Human readable date badge
  const getDueBadge = (dueDate: string, scheduledTime?: string) => {
    if (dueDate < todayStr) {
      // Calculate days overdue
      const diffMs = new Date(todayStr).getTime() - new Date(dueDate).getTime();
      const diffDays = Math.max(1, Math.round(diffMs / (1000 * 60 * 60 * 24)));
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-rose-600 dark:text-rose-400 bg-rose-500/15 px-2 py-0.5 rounded-lg border border-rose-500/25">
          <AlertCircle className="w-3 h-3" />
          {diffDays} {diffDays === 1 ? 'day' : 'days'} overdue ({dueDate})
        </span>
      );
    }
    if (dueDate === todayStr) {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-amber-700 dark:text-amber-400 bg-amber-500/15 px-2 py-0.5 rounded-lg border border-amber-500/30">
          <Clock className="w-3 h-3 text-amber-500 animate-pulse" />
          Today {scheduledTime ? `at ${scheduledTime}` : ''}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-mono text-slate-600 dark:text-stone-400 bg-slate-100 dark:bg-white/5 px-2 py-0.5 rounded-lg border border-slate-200/80 dark:border-white/10">
        <Calendar className="w-3 h-3" />
        {dueDate} {scheduledTime ? `at ${scheduledTime}` : ''}
      </span>
    );
  };

  const card3D = `${tokens.surface} ${tokens.border} ${tokens.surfaceHover}`;

  // Render an individual follow-up item card
  const renderFollowUpCard = (item: FollowUp) => {
    const client = clients.find((c) => c.id === item.clientId);
    const project = projects.find((p) => p.id === item.projectId);
    const isCompleted = item.status === 'completed';
    const isOverdue = !isCompleted && item.dueDate < todayStr;
    const isToday = !isCompleted && item.dueDate === todayStr;
    const phoneNumber = item.customNumber || client?.phone;
    const whatsappNumber = client?.whatsappNumber || item.customNumber || client?.phone;

    return (
      <div
        key={item.id}
        id={`followup-card-${item.id}`}
        className={`p-4 sm:p-5 rounded-[22px] border transition-all duration-200 hover:translate-y-[-2px] ${
          isCompleted
            ? 'opacity-60 bg-slate-50/50 dark:bg-white/5 border-slate-200/60 dark:border-white/5'
            : isOverdue
            ? 'border-rose-500/40 bg-rose-500/5 shadow-sm'
            : isToday
            ? 'border-amber-500/40 bg-amber-500/5 shadow-sm'
            : card3D
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
          <div className="flex items-start gap-3.5 min-w-0 flex-1">
            {/* Mark complete toggle */}
            <button
              type="button"
              onClick={() => { haptics.success(); toggleFollowUpStatus(item.id); }}
              className={`mt-1 w-5 h-5 rounded-full border flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                isCompleted
                  ? 'bg-emerald-500 border-emerald-500 text-white shadow-xs'
                  : isOverdue
                  ? 'border-rose-400 hover:border-rose-600 bg-rose-500/10 text-rose-500'
                  : 'border-slate-400 dark:border-stone-500 hover:border-amber-500'
              }`}
              title={isCompleted ? 'Mark as Pending' : 'Mark as Completed'}
            >
              {isCompleted && <Check className="w-3.5 h-3.5 stroke-[3]" />}
            </button>

            <div className="min-w-0 flex-1">
              {/* Type, Priority, and Due badges */}
              <div className="flex flex-wrap items-center gap-2 mb-1.5">
                <span
                  className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-md font-semibold flex items-center gap-1 ${
                    item.type === 'call'
                      ? 'bg-blue-500/15 text-blue-600 dark:text-blue-400 border border-blue-500/20'
                      : item.type === 'whatsapp'
                      ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                      : item.type === 'meeting'
                      ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/20'
                      : 'bg-purple-500/15 text-purple-600 dark:text-purple-400 border border-purple-500/20'
                  }`}
                >
                  {getTypeIcon(item.type)}
                  <span>{item.type}</span>
                </span>

                <span
                  className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-md font-semibold ${
                    item.priority === 'high'
                      ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/25'
                      : item.priority === 'medium'
                      ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/25'
                      : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25'
                  }`}
                >
                  {item.priority}
                </span>

                {getDueBadge(item.dueDate, item.scheduledTime)}
              </div>

              {/* Title */}
              <h4
                className={`font-display text-base sm:text-lg tracking-tight font-bold ${
                  isCompleted
                    ? 'line-through text-slate-400 dark:text-stone-500'
                    : 'text-slate-900 dark:text-stone-100'
                }`}
              >
                {item.title}
              </h4>

              {/* Notes */}
              {item.notes && (
                <p className="text-xs mt-1 text-slate-600 dark:text-stone-300 leading-relaxed line-clamp-2">
                  {item.notes}
                </p>
              )}

              {/* Pichli Baat-Cheet (Last Conversation Summary) */}
              {(() => {
                const lastSummary = getLastConversationSummary(client, commLogs);
                return (
                  <div className="mt-2 text-[11px] p-2.5 rounded-xl bg-amber-500/5 dark:bg-amber-500/10 border border-amber-500/20 text-slate-700 dark:text-stone-300">
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-bold text-amber-700 dark:text-amber-400">
                        Pichli Baat-Cheet Summary:
                      </span>
                      {isToday && (
                        <span className="text-[10px] font-mono font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                          <Bell className="w-2.5 h-2.5" />
                          <span>2-Min Alert Active</span>
                        </span>
                      )}
                    </div>
                    <p className="italic leading-relaxed">"{lastSummary}"</p>
                  </div>
                );
              })()}

              {/* Linked Client & Project badges */}
              <div className="flex flex-wrap items-center gap-3 mt-2.5 text-xs text-slate-500 dark:text-stone-400">
                {client && (
                  <span
                    onClick={() => onSelectClient(client.id)}
                    className="flex items-center gap-1.5 hover:underline cursor-pointer font-medium text-slate-800 dark:text-stone-200"
                  >
                    <img
                      src={client.avatar}
                      alt={client.name}
                      className="w-4 h-4 rounded-full object-cover border border-white/40"
                    />
                    <span>{client.name}</span>
                    {client.location && (
                      <span className="text-[11px] text-slate-400 dark:text-stone-400 flex items-center gap-0.5 font-normal">
                        <MapPin className="w-2.5 h-2.5 text-rose-500" />
                        {client.location}
                      </span>
                    )}
                  </span>
                )}

                {phoneNumber && (
                  <span className="font-mono text-[11px] text-slate-600 dark:text-stone-300 flex items-center gap-1">
                    <Phone className="w-3 h-3 text-slate-400" />
                    <span>{phoneNumber}</span>
                  </span>
                )}

                {project && (
                  <span
                    onClick={() => onSelectProject(project.id)}
                    className="flex items-center gap-1 hover:underline cursor-pointer text-amber-600 dark:text-amber-400 font-mono text-[11px]"
                  >
                    <Briefcase className="w-3 h-3" />
                    <span>{project.code}: {project.title}</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Quick Actions (Call, WhatsApp, Record Memo, Delete) */}
          <div className="flex items-center gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200/80 dark:border-white/10 shrink-0">
            {/* Direct Phone Dial */}
            {phoneNumber && (
              <a
                href={`tel:${phoneNumber}`}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 bg-blue-500/15 text-blue-600 dark:text-blue-400 hover:bg-blue-500/25 transition-all cursor-pointer"
                title={`Call ${phoneNumber}`}
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call</span>
              </a>
            )}

            {/* Direct WhatsApp */}
            {whatsappNumber && (
              <button
                type="button"
                onClick={() => handleOpenWhatsApp(whatsappNumber, client?.name)}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/25 transition-all cursor-pointer"
                title="Send WhatsApp Message"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">WhatsApp</span>
              </button>
            )}

            {/* Voice Memo CTA */}
            <button
              type="button"
              onClick={() => onOpenVoiceRecorder(item.clientId, item.projectId, item.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                theme === 'dark'
                  ? 'bg-amber-500/20 text-amber-400 hover:bg-amber-500/30'
                  : 'bg-slate-900 text-white hover:bg-black'
              }`}
              title="Record Audio Memo during or after call"
            >
              <Mic className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Record</span>
            </button>

            {/* Delete button */}
            <button
              type="button"
              onClick={() => setFollowUpToDelete(item.id)}
              className="p-1.5 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
              title="Delete Task"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-5 ">
      {/* Top Banner: APK Download Highlight & Quick Link */}
      <div
        id="apk-download-hero-banner"
        className={`p-3.5 sm:p-4 rounded-3xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
          theme === 'dark'
            ? 'bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border-amber-500/25'
            : 'bg-gradient-to-r from-amber-50 via-white to-slate-50 border-amber-200'
        }`}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0 shadow-sm">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-sm tracking-tight text-slate-900 dark:text-stone-100">
                Direct Android APK Download
              </span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30">
                Siyaram-CRM-v1.4.2.apk
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-stone-400">
              Install native Android app package directly with offline sync, call logs, and WhatsApp integration.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Direct Download Button */}
          <a
            href="/downloads/Siyaram-CRM-v1.4.2.apk"
            download="Siyaram-CRM-v1.4.2.apk"
            className={`px-4 py-2 rounded-2xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer shadow-md ${
              theme === 'dark'
                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20'
                : 'bg-slate-900 hover:bg-black text-white shadow-slate-900/20'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download APK</span>
          </a>

          {/* Open APK Modal with info & direct URL */}
          <button
            type="button"
            onClick={() => setIsApkModalOpen(true)}
            className="px-3 py-2 rounded-2xl text-xs font-semibold border border-slate-300 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors cursor-pointer"
            title="View APK details and copy link"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-2 border-b border-inherit">
        <div>
          <span className={`text-[11px] font-mono tracking-widest uppercase ${tokens.textMuted}`}>
            Operations & Call Scheduling · Siyaram Estates
          </span>
          <h2 className="font-display text-2xl sm:text-2xl tracking-tight mt-0.5">
            Pending Follow-ups & Call Tracker
          </h2>
          <p className={`text-xs ${tokens.textSecondary}`}>
            Organizing upcoming touchpoints grouped by <strong>Today</strong>, <strong>This Week</strong>, and <strong>Overdue</strong>
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            id="btn-test-2min-alert-followup"
            type="button"
            onClick={() => {
              haptics.medium();
              if ((window as any).__triggerTest2MinAlert) {
                (window as any).__triggerTest2MinAlert();
              }
            }}
            className="px-3.5 py-2.5 rounded-2xl font-bold text-xs flex items-center gap-1.5 border border-amber-500/40 text-amber-600 dark:text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 transition-all cursor-pointer shadow-xs"
            title="Test 2-Minute Call Alert Notification & Sound"
          >
            <Bell className="w-4 h-4 text-amber-500" />
            <span>Test 2-Min Alert</span>
          </button>

          <button
            id="btn-schedule-new-followup"
            type="button"
            onClick={() => setIsCreateModalOpen(true)}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs tracking-wider uppercase flex items-center gap-2 transition-all cursor-pointer shadow-md ${
              theme === 'dark'
                ? 'bg-white/15 hover:bg-white/20 text-white border border-white/20'
                : 'bg-white hover:bg-slate-50 text-slate-900 border border-slate-200'
            }`}
          >
            <Plus className="w-4 h-4 text-amber-500" />
            <span>New Follow-up</span>
          </button>
        </div>
      </div>

      {/* PRIMARY CONTROLS: Group Filter Pills + Timeline View Toggle + Client-side Sorting */}
      <div className="space-y-3">
        {/* Horizontal Scrollable Timeline Tabs with Live Counts */}
        <div className="p-1 rounded-2xl bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 flex flex-wrap items-center gap-1">
          {[
            { id: 'all', label: 'All Tasks', count: groupCounts.total },
            { id: 'overdue', label: '🚨 Overdue', count: groupCounts.overdue, highlight: groupCounts.overdue > 0 ? 'text-rose-500' : '' },
            { id: 'today', label: '🌅 Today', count: groupCounts.today, highlight: groupCounts.today > 0 ? 'text-amber-500 font-bold' : '' },
            { id: 'this_week', label: '🗓️ This Week', count: groupCounts.thisWeek, highlight: groupCounts.thisWeek > 0 ? 'text-blue-500' : '' },
            { id: 'later', label: '📆 Later', count: groupCounts.later },
            { id: 'completed', label: '✅ Completed', count: groupCounts.completed },
          ].map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-followup-${tab.id}`}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 min-w-[95px] sm:min-w-[110px] py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  active
                    ? theme === 'dark'
                      ? 'tactile-pill-active-dark scale-[1.01] shadow-sm'
                      : 'tactile-pill-active-dawn scale-[1.01] shadow-sm'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary} hover:bg-white/5`
                }`}
              >
                <span className={tab.highlight}>{tab.label}</span>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                    active
                      ? theme === 'dark' ? 'bg-white/20 text-white' : 'bg-black/10 text-slate-900'
                      : 'bg-black/5 dark:bg-white/10 text-slate-500 dark:text-stone-400'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* SECONDARY ROW: View Switcher, Call Filter & Client-side Sort */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-2">
            {/* Calls Only Toggle */}
            <button
              id="filter-only-calls-toggle"
              type="button"
              onClick={() => setOnlyCalls(!onlyCalls)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border ${
                onlyCalls
                  ? 'bg-blue-500 text-white border-blue-600 shadow-sm'
                  : `${card3D} text-slate-600 dark:text-stone-300 border-slate-200 dark:border-white/10`
              }`}
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Calls Only ({groupCounts.callsCount})</span>
            </button>

            {/* Channels Filter Dropdown / Pills */}
            <div className="flex items-center gap-1">
              {[
                { id: 'all', label: 'All Channels' },
                { id: 'call', label: 'Phone' },
                { id: 'whatsapp', label: 'WhatsApp' },
                { id: 'meeting', label: 'Meeting' },
              ].map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setChannelFilter(c.id)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-medium transition-all cursor-pointer ${
                    channelFilter === c.id
                      ? theme === 'dark'
                        ? 'bg-white/20 text-white font-bold'
                        : 'bg-slate-900 text-white font-bold'
                      : 'text-slate-500 hover:text-slate-900 dark:text-stone-400'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* View Mode Toggle: Grouped Timeline vs Continuous List */}
            <button
              id="toggle-grouped-view"
              type="button"
              onClick={() => setIsGroupedView(!isGroupedView)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border ${
                isGroupedView
                  ? 'bg-amber-500/20 text-amber-700 dark:text-amber-400 border-amber-500/30'
                  : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-stone-400 border-slate-200 dark:border-white/10'
              }`}
              title="Toggle Grouped Timeline Sections"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{isGroupedView ? 'Grouped View' : 'Flat List'}</span>
            </button>

            {/* Client-Side Sort Dropdown */}
            <div className="flex items-center gap-1.5 text-xs font-mono">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
              <select
                id="select-sort-followups"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className={`px-2.5 py-1.5 rounded-xl text-xs font-sans border focus:outline-none cursor-pointer ${
                  theme === 'dark'
                    ? 'bg-[#15181e] text-stone-200 border-white/10'
                    : 'bg-white text-slate-800 border-slate-200'
                }`}
              >
                <option value="dueDate_asc">Sort: Due Date (Earliest First)</option>
                <option value="dueDate_desc">Sort: Due Date (Latest First)</option>
                <option value="priority_high">Sort: Priority (High to Low)</option>
                <option value="client_name">Sort: Client Name (A - Z)</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* CONTENT LIST */}
      {isGroupedView && activeTab === 'all' ? (
        /* GROUPED VIEW: Automatically segments calls into Today, This Week, Overdue, and Later */
        <div className="space-y-4">
          {/* 1. OVERDUE CALLS */}
          {groupedBuckets.overdue.length > 0 && (
            <div className="space-y-3" id="group-section-overdue">
              <div className="flex items-center justify-between pb-1 border-b border-rose-500/20">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                  <h3 className="font-display text-lg font-bold tracking-tight text-rose-600 dark:text-rose-400 flex items-center gap-2">
                    <span>🚨 Overdue Calls & Touchpoints</span>
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/30">
                    {groupedBuckets.overdue.length} Action Needed
                  </span>
                </div>
                <span className="text-[11px] text-rose-500/80 font-mono">Past scheduled due dates</span>
              </div>

              <div className="space-y-3">
                {groupedBuckets.overdue.map((item) => renderFollowUpCard(item))}
              </div>
            </div>
          )}

          {/* 2. TODAY'S UPCOMING CALLS */}
          {groupedBuckets.today.length > 0 && (
            <div className="space-y-3" id="group-section-today">
              <div className="flex items-center justify-between pb-1 border-b border-amber-500/30">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping" />
                  <h3 className="font-display text-lg font-bold tracking-tight text-amber-600 dark:text-amber-400 flex items-center gap-2">
                    <span>🌅 Today's Scheduled Calls</span>
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-700 dark:text-amber-400 border border-amber-500/30">
                    {groupedBuckets.today.length} Due Today
                  </span>
                </div>
                <span className="text-[11px] text-amber-600/80 dark:text-amber-400 font-mono">{todayStr}</span>
              </div>

              <div className="space-y-3">
                {groupedBuckets.today.map((item) => renderFollowUpCard(item))}
              </div>
            </div>
          )}

          {/* 3. THIS WEEK'S UPCOMING CALLS */}
          {groupedBuckets.this_week.length > 0 && (
            <div className="space-y-3" id="group-section-this-week">
              <div className="flex items-center justify-between pb-1 border-b border-blue-500/20">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  <h3 className="font-display text-lg font-bold tracking-tight text-blue-600 dark:text-blue-400 flex items-center gap-2">
                    <span>🗓️ This Week's Calls (Next 7 Days)</span>
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-blue-500/20 text-blue-600 dark:text-blue-400 border border-blue-500/30">
                    {groupedBuckets.this_week.length} Upcoming
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 dark:text-stone-400 font-mono">Until {endOfWeekStr}</span>
              </div>

              <div className="space-y-3">
                {groupedBuckets.this_week.map((item) => renderFollowUpCard(item))}
              </div>
            </div>
          )}

          {/* 4. LATER / BEYOND THIS WEEK */}
          {groupedBuckets.later.length > 0 && (
            <div className="space-y-3" id="group-section-later">
              <div className="flex items-center justify-between pb-1 border-b border-slate-200 dark:border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-400" />
                  <h3 className="font-display text-lg font-bold tracking-tight text-slate-700 dark:text-stone-300 flex items-center gap-2">
                    <span>📆 Later & Future Schedules</span>
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-200 dark:bg-white/10 text-slate-700 dark:text-stone-300">
                    {groupedBuckets.later.length}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 font-mono">Future pipeline</span>
              </div>

              <div className="space-y-3">
                {groupedBuckets.later.map((item) => renderFollowUpCard(item))}
              </div>
            </div>
          )}

          {/* 5. COMPLETED TASKS */}
          {groupedBuckets.completed.length > 0 && (
            <div className="space-y-3 pt-4 opacity-75" id="group-section-completed">
              <div className="flex items-center justify-between pb-1 border-b border-emerald-500/20">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <h3 className="font-display text-base font-bold tracking-tight text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
                    <span>✅ Completed Follow-ups</span>
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                    {groupedBuckets.completed.length}
                  </span>
                </div>
              </div>

              <div className="space-y-3">
                {groupedBuckets.completed.map((item) => renderFollowUpCard(item))}
              </div>
            </div>
          )}

          {sortedFollowUps.length === 0 && (
            <EmptyStatePlaceholder
              icon={CalendarClock}
              title="Queue is Clear"
              description="No follow-ups match your current filter criteria."
              actionLabel="Add Follow-up"
              ActionIcon={Plus}
              onAction={() => setIsCreateModalOpen(true)}
            />
          )}
        </div>
      ) : (
        /* FLAT VIEW: Standard sorted list for specific tab (e.g. Overdue, Today, or This Week) */
        <div className="space-y-3">
          {sortedFollowUps.map((item) => renderFollowUpCard(item))}

          {sortedFollowUps.length === 0 && (
            <div className={`p-12 text-center rounded-3xl border border-dashed ${tokens.border}`}>
              <CalendarClock className="w-12 h-12 mx-auto text-slate-400 mb-3 opacity-50" />
              <h4 className="font-display text-xl font-bold tracking-tight">
                No items in this group
              </h4>
              <p className="text-xs text-slate-500 dark:text-stone-400 mt-1">
                {activeTab === 'overdue' && 'Hooray! There are no overdue calls in your queue.'}
                {activeTab === 'today' && 'No more calls scheduled for today.'}
                {activeTab === 'this_week' && 'No calls due this week.'}
                {activeTab === 'completed' && 'No completed tasks yet.'}
                {activeTab === 'all' && 'No follow-up matches your search or filter.'}
              </p>
            </div>
          )}
        </div>
      )}

      {/* CREATE NEW FOLLOW-UP MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm ">
          <div
            className={`relative w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] ${
              theme === 'dark'
                ? 'bg-[#0f1115]/95 border-white/10 text-stone-100'
                : 'bg-white/95 border-slate-200 text-slate-900'
            }`}
          >
            <div className="px-6 py-4 border-b border-inherit flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CalendarClock className="w-5 h-5 text-amber-500" />
                <h3 className="font-display text-xl font-bold tracking-tight">
                  Schedule Follow-up / Call
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 text-slate-400 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateFollowUp} className="p-6 space-y-4 overflow-y-auto text-xs">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-stone-300">
                  Call / Task Title *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Call Vikram Singhania regarding Siyaram 250 sq.yd Plot token"
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none ${
                    theme === 'dark'
                      ? 'bg-white/5 border-white/10 text-stone-100'
                      : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-stone-300">
                    Channel / Type
                  </label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none cursor-pointer ${
                      theme === 'dark'
                        ? 'bg-[#15181e] border-white/10 text-stone-100'
                        : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  >
                    <option value="call">Phone Call (कॉल)</option>
                    <option value="whatsapp">WhatsApp Message</option>
                    <option value="meeting">Site Visit / Meeting</option>
                    <option value="sms">SMS Text</option>
                    <option value="email">Email</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-stone-300">
                    Priority
                  </label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as any)}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none cursor-pointer ${
                      theme === 'dark'
                        ? 'bg-[#15181e] border-white/10 text-stone-100'
                        : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  >
                    <option value="high">High (Urgent Attention)</option>
                    <option value="medium">Medium (Standard)</option>
                    <option value="low">Low (Routine)</option>
                  </select>
                </div>
              </div>

              {/* Date & Time with Quick Presets */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-stone-300">
                    Due Date
                  </label>
                  <input
                    type="date"
                    value={newDueDate}
                    onChange={(e) => setNewDueDate(e.target.value)}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none font-mono ${
                      theme === 'dark'
                        ? 'bg-white/5 border-white/10 text-stone-100'
                        : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-stone-300">
                    Scheduled Time
                  </label>
                  <input
                    type="time"
                    value={newScheduledTime}
                    onChange={(e) => setNewScheduledTime(e.target.value)}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none font-mono ${
                      theme === 'dark'
                        ? 'bg-white/5 border-white/10 text-stone-100'
                        : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  />
                </div>
              </div>

              {/* Quick Presets for Date */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[10px] uppercase font-mono text-slate-400">Presets:</span>
                {[
                  { label: 'Today', days: 0 },
                  { label: 'Tomorrow', days: 1 },
                  { label: 'In 3 Days', days: 3 },
                  { label: 'Next Week (7d)', days: 7 },
                  { label: 'In 10 Days', days: 10 },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      const d = new Date();
                      d.setDate(d.getDate() + preset.days);
                      setNewDueDate(d.toISOString().split('T')[0]);
                    }}
                    className="px-2.5 py-1 rounded-lg text-[11px] font-mono bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 hover:bg-amber-500/20 hover:text-amber-600 cursor-pointer transition-colors"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-stone-300">
                    Client Association
                  </label>
                  <select
                    value={newClientId}
                    onChange={(e) => {
                      setNewClientId(e.target.value);
                      const c = clients.find((x) => x.id === e.target.value);
                      if (c && !newCustomNumber) {
                        setNewCustomNumber(c.phone);
                      }
                    }}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none cursor-pointer ${
                      theme === 'dark'
                        ? 'bg-[#15181e] border-white/10 text-stone-100'
                        : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  >
                    <option value="">No Client (Ad-hoc Task)</option>
                    {clients.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.location ? `(${c.location})` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-stone-300">
                    Phone / Mobile Number
                  </label>
                  <input
                    type="text"
                    value={newCustomNumber}
                    onChange={(e) => setNewCustomNumber(e.target.value)}
                    placeholder="+91 98112 55443"
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none font-mono ${
                      theme === 'dark'
                        ? 'bg-white/5 border-white/10 text-stone-100'
                        : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-stone-300">
                  Project Association
                </label>
                <select
                  value={newProjectId}
                  onChange={(e) => setNewProjectId(e.target.value)}
                  className={`w-full px-3 py-2.5 rounded-xl text-xs border focus:outline-none cursor-pointer ${
                    theme === 'dark'
                      ? 'bg-[#15181e] border-white/10 text-stone-100'
                      : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                >
                  <option value="">No Specific Project</option>
                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.code} — {p.title}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1 text-slate-600 dark:text-stone-300">
                  Call Agenda / Notes
                </label>
                <textarea
                  rows={2}
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="Key discussion points, pricing quotation, plot dimensions..."
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs border focus:outline-none ${
                    theme === 'dark'
                      ? 'bg-white/5 border-white/10 text-stone-100'
                      : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                />
              </div>

              <div className="pt-3 border-t border-inherit flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-500 hover:text-slate-900 dark:text-stone-400 dark:hover:text-stone-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2.5 rounded-2xl text-xs font-bold tracking-wider uppercase cursor-pointer shadow-md ${
                    theme === 'dark'
                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20'
                      : 'bg-slate-900 hover:bg-black text-white shadow-slate-900/20'
                  }`}
                >
                  Schedule Follow-up
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* APK DOWNLOAD MODAL */}
      <DownloadApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </div>
  );
};
