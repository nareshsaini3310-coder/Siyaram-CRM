import { motion } from 'motion/react';
import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Briefcase,
  Users,
  Calendar,
  DollarSign,
  CheckCircle2,
  Circle,
  Plus,
  Trash2,
  Edit,
  Mic,
  Play,
  Pause,
  ExternalLink,
  Phone,
  Mail,
  UserPlus,
  FileText,
  X,
  MapPin,
  Building,
  Layers,
  MessageSquare,
  Map,
  Image,
  Maximize2
} from 'lucide-react';
import { Project, Client, Milestone, VoiceRecording, FloorMap, ProjectContact } from '../types';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { EditProjectModal } from '../components/EditProjectModal';
import { ManageFloorMapModal } from '../components/ManageFloorMapModal';
import { QuickCommModal } from '../components/QuickCommModal';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { ExpandableVoiceRecordingItem } from '../components/ExpandableVoiceRecordingItem';

interface ProjectDetailViewProps {
  projectId: string;
  onBack: () => void;
  onSelectClient: (clientId: string) => void;
  onOpenVoiceRecorder: (clientId?: string, projectId?: string) => void;
}

export const ProjectDetailView: React.FC<ProjectDetailViewProps> = ({
  projectId,
  onBack,
  onSelectClient,
  onOpenVoiceRecorder,
}) => {
  const { theme, tokens, accent } = useTheme();
  const {
    getProjectById,
    updateProject,
    deleteProject,
    clients,
    tags,
    recordings,
  } = useData();

  
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    setIsLoading(true);
    const t = setTimeout(() => setIsLoading(false), 500);
    return () => clearTimeout(t);
  }, [projectId]);

  const project = getProjectById(projectId);

  const [isLinkingClient, setIsLinkingClient] = useState(false);
  const [selectedClientToLink, setSelectedClientToLink] = useState('');
  const [newMilestoneTitle, setNewMilestoneTitle] = useState('');
  const [newMilestoneDate, setNewMilestoneDate] = useState('2026-10-31');
  const [isAddingMilestone, setIsAddingMilestone] = useState(false);
  const [activeDetailTab, setActiveDetailTab] = useState<'specs' | 'clients' | 'milestones' | 'audio' | 'deliverables' | 'documents'>('specs');
  const [docFilter, setDocFilter] = useState<'all' | 'floor_map' | 'agreement' | 'brochure' | 'video' | 'other'>('all');
  const [isManageFloorMapOpen, setIsManageFloorMapOpen] = useState(false);
  const [editingFloorMap, setEditingFloorMap] = useState<FloorMap | undefined>(undefined);
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isCommModalOpen, setIsCommModalOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [newContactName, setNewContactName] = useState('');
  const [newContactRole, setNewContactRole] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [newContactWhatsApp, setNewContactWhatsApp] = useState('');
  const [newFeature, setNewFeature] = useState('');



  if (isLoading) {
    return (
      <div className="space-y-8 ">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-stone-500/10">
          <div className="w-32 h-6 bg-stone-500/10 rounded animate-pulse" />
          <div className="flex gap-2">
            <div className="w-32 h-9 bg-stone-500/10 rounded-xl animate-pulse" />
            <div className="w-32 h-9 bg-stone-500/10 rounded-xl animate-pulse" />
            <div className="w-10 h-9 bg-stone-500/10 rounded-xl animate-pulse" />
          </div>
        </div>
        <div className="space-y-4">
          <div className="flex gap-2">
            <div className="w-16 h-6 bg-stone-500/10 rounded-full animate-pulse" />
            <div className="w-24 h-6 bg-stone-500/10 rounded-full animate-pulse" />
          </div>
          <div className="w-64 h-10 bg-stone-500/10 rounded-lg animate-pulse" />
          <div className="w-full max-w-2xl h-16 bg-stone-500/10 rounded-lg animate-pulse" />
        </div>
        <div className="p-1 rounded-2xl bg-stone-500/5 flex gap-1 overflow-hidden">
          {[1,2,3,4,5,6].map(i => <div key={i} className="flex-1 h-10 bg-stone-500/10 rounded-xl animate-pulse" />)}
        </div>
        <div className={`p-6 rounded-2xl border space-y-5 ${tokens.surface} ${tokens.border}`}>
           <div className="flex justify-between items-center">
              <div className="space-y-2">
                <div className="w-48 h-8 bg-stone-500/10 rounded-lg animate-pulse" />
                <div className="w-64 h-4 bg-stone-500/10 rounded animate-pulse" />
              </div>
              <div className="w-32 h-9 bg-stone-500/10 rounded-xl animate-pulse" />
           </div>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
             {[1,2,3].map(i => <div key={i} className="h-40 bg-stone-500/10 rounded-xl animate-pulse" />)}
           </div>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="p-8 text-center space-y-4">
        <p className="text-stone-400">Project record not found.</p>
        <button
          onClick={onBack}
          className={`px-4 py-2 rounded-xl text-xs font-semibold ${tokens.accentBtn}`}
        >
          Return to Projects
        </button>
      </div>
    );
  }

  // Linked clients list
  const linkedClients = project.clientIds
    .map((cId) => clients.find((c) => c.id === cId))
    .filter(Boolean) as Client[];

  // Available clients that are not yet linked
  const unlinkedClients = clients.filter((c) => !project.clientIds.includes(c.id));

  // Attached recordings
  const attachedRecordings = recordings.filter(
    (r) => r.projectId === project.id || project.voiceRecordingIds.includes(r.id)
  );

  // Project tags
  const projectTags = project.tagIds
    .map((tId) => tags.find((t) => t.id === tId))
    .filter(Boolean);

  // Milestone toggling
  const handleToggleMilestone = (mId: string) => {
    const updatedMilestones = project.milestones.map((m) =>
      m.id === mId ? { ...m, completed: !m.completed } : m
    );
    updateProject(project.id, { milestones: updatedMilestones });
  };

  const handleAddMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMilestoneTitle.trim()) return;

    const newMilestone: Milestone = {
      id: `m-${Date.now()}`,
      title: newMilestoneTitle.trim(),
      completed: false,
      dueDate: newMilestoneDate,
    };

    updateProject(project.id, {
      milestones: [...project.milestones, newMilestone],
    });
    setNewMilestoneTitle('');
    setIsAddingMilestone(false);
  };

  // Link / Unlink client
  const handleLinkClient = () => {
    if (!selectedClientToLink) return;
    if (!project.clientIds.includes(selectedClientToLink)) {
      updateProject(project.id, {
        clientIds: [...project.clientIds, selectedClientToLink],
      });
    }
    setSelectedClientToLink('');
    setIsLinkingClient(false);
  };

  const handleUnlinkClient = (clientId: string) => {
    updateProject(project.id, {
      clientIds: project.clientIds.filter((id) => id !== clientId),
    });
  };

  const addProjectContact = () => {
    if (!newContactName.trim() || !newContactPhone.trim()) return;
    const contact: ProjectContact = { id: `pc-${Date.now()}`, name: newContactName.trim(), role: newContactRole.trim() || undefined, phone: newContactPhone.trim(), whatsapp: newContactWhatsApp.trim() || undefined };
    updateProject(project.id, { contacts: [...(project.contacts || []), contact] });
    setNewContactName(''); setNewContactRole(''); setNewContactPhone(''); setNewContactWhatsApp('');
  };

  const removeProjectContact = (id: string) => updateProject(project.id, { contacts: (project.contacts || []).filter(c => c.id !== id) });

  const addProjectFeature = () => {
    if (!newFeature.trim()) return;
    updateProject(project.id, { keyFeatures: [...(project.keyFeatures || []), newFeature.trim()] });
    setNewFeature('');
  };

  const removeProjectFeature = (feature: string) => updateProject(project.id, { keyFeatures: (project.keyFeatures || []).filter(f => f !== feature) });

  
  const completedMilestones = project.milestones.filter((m) => m.completed).length;
  const progressPct =
    project.milestones.length > 0
      ? Math.round((completedMilestones / project.milestones.length) * 100)
      : 0;

  return (
    <div className="space-y-8 ">
      {/* Top Bar with Back and Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-inherit">
        <button
          type="button"
          onClick={onBack}
          className={`flex items-center gap-2 text-xs font-mono transition-colors ${tokens.textSecondary} hover:${tokens.textPrimary}`}
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Projects</span>
        </button>

        <div className="flex flex-wrap items-center gap-2">
          
          {/* Upload Document Button */}
          <button
            type="button"
            onClick={() => {
              setEditingFloorMap(undefined);
              setIsManageFloorMapOpen(true);
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${tokens.surfaceElevated} ${tokens.border} hover:${tokens.textPrimary} border`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Upload Document</span>
          </button>

          {/* Edit Project Button */}
          <button
            type="button"
            onClick={() => setIsEditModalOpen(true)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition-all ${tokens.surfaceElevated} ${tokens.border} hover:${tokens.textPrimary}`}
          >
            <Edit className="w-3.5 h-3.5 text-amber-400" />
            <span>Edit Project & Specs</span>
          </button>

          {/* Quick Outreach Button */}
          <button
            type="button"
            onClick={() => setIsCommModalOpen(true)}
            className="px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs transition-all cursor-pointer"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Send WhatsApp / Call</span>
          </button>

          {/* Voice Memo Button */}
          <button
            type="button"
            onClick={() => onOpenVoiceRecorder(project.clientIds[0], project.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${tokens.accentBtn}`}
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Record Voice Note</span>
          </button>

          <button
            type="button"
            onClick={() => setIsDeleteConfirmOpen(true)}
            className="p-2 rounded-xl border border-stone-500/20 text-stone-400 hover:text-[#c85642] hover:border-[#c85642]/40 transition-colors"
            title="Delete Project"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Project Banner & Specs */}
      <motion.div
        layoutId={`project-card-${project.id}`}
        transition={{
          type: 'spring',
          stiffness: 550,
          damping: 38,
          mass: 0.35,
        }}
        className="space-y-4"
      >
        <div className="flex flex-wrap items-center gap-2.5">
          <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-amber-500/20 text-amber-300">
            {project.code}
          </span>
          <select
            value={project.status}
            onChange={(e) => updateProject(project.id, { status: e.target.value as any })}
            className={`text-xs font-mono uppercase px-3 py-1 rounded-full font-semibold border cursor-pointer ${
              project.status === 'active'
                ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                : project.status === 'in_review'
                ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30'
                : project.status === 'planning'
                ? 'bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30'
                : 'bg-stone-500/15 text-stone-400 border-stone-500/30'
            }`}
          >
            <option value="active">Active Execution</option>
            <option value="in_review">In Review</option>
            <option value="planning">Schematic Planning</option>
            <option value="completed">Completed Commission</option>
          </select>

          {project.location && (
            <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-stone-500/15 text-stone-300 flex items-center gap-1 border border-stone-500/20">
              <MapPin className="w-3 h-3 text-amber-400" />
              <span>{project.location}</span>
            </span>
          )}

          {projectTags.map((tag) => (
            <span
              key={tag!.id}
              className="text-[11px] font-mono px-2.5 py-0.5 rounded-md border"
              style={{
                borderColor: `${tag!.color}40`,
                backgroundColor: `${tag!.color}15`,
                color: tag!.color,
              }}
            >
              #{tag!.name}
            </span>
          ))}
        </div>

        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <h1 className="font-display text-4xl sm:text-5xl tracking-tight leading-none">
            {project.title}
          </h1>
          <button
            type="button"
            onClick={() => setIsEditModalOpen(true)}
            className="text-xs font-mono text-amber-400 hover:underline flex items-center gap-1"
          >
            <Edit className="w-3 h-3" /> Edit Project Details
          </button>
        </div>

        <p className={`text-sm sm:text-base leading-relaxed max-w-4xl ${tokens.textSecondary}`}>
          {project.description}
        </p>
      </motion.div>

      {/* Project contacts & sales points */}
      <div className={`grid grid-cols-1 lg:grid-cols-2 gap-4`}>
        <div className={`p-5 rounded-2xl border ${tokens.surface} ${tokens.border}`}>
          <div className="flex items-center justify-between mb-4">
            <div><h3 className="font-display text-xl">Project Contacts</h3><p className={`text-[11px] ${tokens.textSecondary}`}>Developer, sales and site contacts for one-tap outreach.</p></div>
          </div>
          <div className="space-y-2">
            {(project.contacts || []).map(c => (
              <div key={c.id} className={`flex items-center justify-between gap-3 p-3 rounded-xl border ${tokens.border} ${tokens.bgSubtle}`}>
                <div><p className="font-semibold text-sm">{c.name}</p><p className={`text-[10px] ${tokens.textMuted}`}>{c.role || 'Project Contact'} · {c.phone}</p></div>
                <div className="flex items-center gap-1">
                  <a href={`tel:${c.phone}`} className="p-2 rounded-lg bg-blue-500/15 text-blue-400"><Phone className="w-3.5 h-3.5" /></a>
                  <a href={`https://wa.me/${(c.whatsapp || c.phone).replace(/\D/g,'')}`} target="_blank" rel="noreferrer" className="p-2 rounded-lg bg-emerald-500/15 text-emerald-400"><MessageSquare className="w-3.5 h-3.5" /></a>
                  <button onClick={() => removeProjectContact(c.id)} className="p-2 rounded-lg text-red-400/70"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            ))}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <input value={newContactName} onChange={e=>setNewContactName(e.target.value)} placeholder="Name" className={`px-3 py-2 rounded-lg border bg-transparent text-xs ${tokens.border}`} />
              <input value={newContactRole} onChange={e=>setNewContactRole(e.target.value)} placeholder="Role (Sales)" className={`px-3 py-2 rounded-lg border bg-transparent text-xs ${tokens.border}`} />
              <input value={newContactPhone} onChange={e=>setNewContactPhone(e.target.value)} placeholder="Phone" className={`px-3 py-2 rounded-lg border bg-transparent text-xs ${tokens.border}`} />
              <input value={newContactWhatsApp} onChange={e=>setNewContactWhatsApp(e.target.value)} placeholder="WhatsApp (optional)" className={`px-3 py-2 rounded-lg border bg-transparent text-xs ${tokens.border}`} />
            </div>
            <button onClick={addProjectContact} className={`w-full mt-2 px-3 py-2 rounded-lg text-xs font-semibold ${tokens.accentBtn}`}><Plus className="w-3.5 h-3.5 inline mr-1"/>Add Contact</button>
          </div>
        </div>
        <div className={`p-5 rounded-2xl border ${tokens.surface} ${tokens.border}`}>
          <h3 className="font-display text-xl">Key Sales Points</h3><p className={`text-[11px] mt-1 ${tokens.textSecondary}`}>Keep the project's talking points ready for client conversations.</p>
          <div className="flex flex-wrap gap-2 mt-4">
            {(project.keyFeatures || []).map(f => <span key={f} className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-[11px] border ${tokens.border} ${tokens.bgSubtle}`}>{f}<button onClick={()=>removeProjectFeature(f)} className="text-red-400"><X className="w-3 h-3"/></button></span>)}
          </div>
          <div className="flex gap-2 mt-4"><input value={newFeature} onChange={e=>setNewFeature(e.target.value)} onKeyDown={e=>{if(e.key==='Enter') addProjectFeature()}} placeholder="e.g. Gated Community" className={`flex-1 px-3 py-2 rounded-lg border bg-transparent text-xs ${tokens.border}`} /><button onClick={addProjectFeature} className={`px-3 py-2 rounded-lg text-xs font-semibold ${tokens.accentBtn}`}><Plus className="w-3.5 h-3.5"/></button></div>
        </div>
      </div>

      {/* REAL ESTATE PROPERTY HIGHLIGHTS: Plot, High-Rise & Land */}
      <div className={`p-6 rounded-2xl border ${tokens.surface} ${tokens.border}`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-amber-500 flex items-center gap-1.5">
            <Layers className="w-4 h-4" />
            <span>Property Specifications: Plots, High Rises & Land Portfolio</span>
          </h3>
          <button
            type="button"
            onClick={() => setIsEditModalOpen(true)}
            className="text-xs font-mono text-stone-400 hover:text-white underline cursor-pointer"
          >
            Quick Edit Specs
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-4 border-b border-inherit">
          <div className="p-3.5 rounded-xl bg-stone-500/10 border border-inherit">
            <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block mb-1">
              🏡 Plot Inventory
            </span>
            <span className="text-sm font-semibold font-mono text-stone-100">
              {project.plotDetails || '150, 250, 500 Sq. Yd.'}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-stone-500/10 border border-inherit">
            <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block mb-1">
              🏢 High Rises
            </span>
            <span className="text-sm font-semibold font-mono text-stone-100">
              {project.highRiseDetails || 'G+32 Luxury Towers'}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-stone-500/10 border border-inherit">
            <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block mb-1">
              🌾 Total Land Area
            </span>
            <span className="text-sm font-semibold font-mono text-stone-100">
              {project.landArea || '38.5 Acres Township'}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-stone-500/10 border border-inherit">
            <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block mb-1">
              🔢 Total Units
            </span>
            <span className="text-sm font-semibold font-mono text-stone-100">
              {project.unitCount ? `${project.unitCount} Units` : '480 Units'}
            </span>
          </div>
        </div>

        {/* Financials & Timeline Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-b border-inherit">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block">
              Contract Budget
            </span>
            <span className="text-xl font-mono font-bold">€{project.budget.toLocaleString()}</span>
          </div>
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block">
              Incurred To Date
            </span>
            <span className="text-xl font-mono font-bold text-amber-500">
              €{project.spent.toLocaleString()}
            </span>
          </div>
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block">
              Commission Start
            </span>
            <span className="text-sm font-mono mt-1 block">{project.startDate}</span>
          </div>
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block">
              Target Handover
            </span>
            <span className="text-sm font-mono mt-1 block">{project.targetDate}</span>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between gap-4">
          <div className="text-xs font-mono text-stone-400">
            Milestone Progress: <span className="font-bold text-white">{progressPct}% Complete</span>
          </div>
          <div className="flex-1 max-w-xs bg-stone-500/20 h-2 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                accent === 'sage' ? 'bg-[#6c9377]' : 'bg-[#5a8196]'
              }`}
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
      </div>

      {/* NESTED SUB-TABS (Tab ke andar Tab) */}
      <div className="space-y-4 pt-2">
        <div className="p-1 rounded-2xl bg-stone-500/10 border border-inherit flex flex-wrap items-center gap-1">
          {[
            { id: 'specs', label: 'Property & Plot Details', icon: Layers },
            { id: 'clients', label: `Clients (${linkedClients.length})`, icon: Users },
            { id: 'milestones', label: `Milestones (${completedMilestones}/${project.milestones.length})`, icon: CheckCircle2 },
            { id: 'audio', label: `Audio Logs (${attachedRecordings.length})`, icon: Mic },
            { id: 'deliverables', label: `Deliverables (${project.deliverables.length})`, icon: FileText },
            { id: 'documents', label: `Documents (${project.floorMaps?.length || 0})`, icon: Image },
          ].map((tab) => {
            const active = activeDetailTab === tab.id;
            const TabIcon = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveDetailTab(tab.id as any)}
                className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  active
                    ? theme === 'dark'
                      ? 'tactile-pill-active-dark scale-[1.01]'
                      : 'tactile-pill-active-dawn scale-[1.01]'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary} hover:bg-stone-500/10`
                }`}
              >
                <TabIcon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* SUB-TAB 0: Detailed Property Specs & Inventory */}
      {activeDetailTab === 'specs' && (
        <div className="space-y-4 ">
          <div className={`p-6 rounded-2xl border space-y-5 ${tokens.surface} ${tokens.border}`}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-2xl tracking-tight">
                  {project.title} — Real Estate Dimensions & Layout
                </h3>
                <p className={`text-xs ${tokens.textSecondary}`}>
                  Complete details of plots, high-rise luxury towers, land area, and location specifications
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsEditModalOpen(true)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 ${tokens.accentBtn}`}
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Edit All Property Specs</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Plot Details Box */}
              <div className={`p-5 rounded-xl border space-y-2 ${tokens.surfaceElevated} ${tokens.border}`}>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold uppercase text-emerald-400 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5" />
                    <span>Plotted Sectors</span>
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                    Gated Plots
                  </span>
                </div>
                <h4 className="font-display text-lg tracking-tight font-semibold">
                  {project.plotDetails || '150, 250, 500 Sq. Yd.'}
                </h4>
                <p className={`text-xs ${tokens.textSecondary} leading-relaxed`}>
                  Demarcated residential villa plots with wide avenue access, 24/7 private gated security, underground electricity, and private clubhouse privileges.
                </p>
              </div>

              {/* High-Rises Details Box */}
              <div className={`p-5 rounded-xl border space-y-2 ${tokens.surfaceElevated} ${tokens.border}`}>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold uppercase text-blue-400 flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5" />
                    <span>High Rises Towers</span>
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/20 text-blue-300">
                    Sky Mansions
                  </span>
                </div>
                <h4 className="font-display text-lg tracking-tight font-semibold">
                  {project.highRiseDetails || 'G+32 Iconic Luxury Towers'}
                </h4>
                <p className={`text-xs ${tokens.textSecondary} leading-relaxed`}>
                  Premium 3 & 4 BHK sky residences with floor-to-ceiling glass facades, double-height cantilevered balconies, and infinity rooftop decks.
                </p>
              </div>

              {/* Land Details Box */}
              <div className={`p-5 rounded-xl border space-y-2 ${tokens.surfaceElevated} ${tokens.border}`}>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold uppercase text-amber-400 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>Land & Location</span>
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                    Expressway
                  </span>
                </div>
                <h4 className="font-display text-lg tracking-tight font-semibold">
                  {project.landArea || '38.5 Acres Township'}
                </h4>
                <p className={`text-xs ${tokens.textSecondary} leading-relaxed`}>
                  Located at {project.location || 'Sector 84, Express Highway'}. Master-planned mixed development with 70% open green landscaped courtyards.
                </p>
              </div>
            </div>

            
            {/* Developer Site Notes */}
            {project.notes && (
              <div className="p-4 rounded-xl border border-stone-500/20 bg-stone-500/5">
                <span className="text-[11px] font-mono uppercase font-bold text-stone-400 block mb-1">
                  Confidential Site & Regulatory Notes
                </span>
                <p className={`text-xs font-mono leading-relaxed ${tokens.textSecondary}`}>
                  {project.notes}
                </p>
              </div>
            )}

            
            {/* Quick Preview Floor Maps Gallery */}
            <div className="pt-4 mt-4 border-t border-stone-500/20">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold text-sm flex items-center gap-1.5">
                  <Image className="w-4 h-4" />
                  <span>Document Previews</span>
                </h4>
                <button 
                  onClick={() => setActiveDetailTab('documents')}
                  className={`text-[10px] uppercase font-bold tracking-wider hover:underline ${tokens.accentText}`}
                >
                  View All {project.floorMaps?.length || 0} Documents
                </button>
              </div>
              
              {(!project.floorMaps || project.floorMaps.length === 0) ? (
                <div className={`p-6 rounded-xl border border-dashed flex flex-col items-center justify-center text-center space-y-2 ${tokens.border} ${tokens.bgSubtle}`}>
                  <Image className={`w-6 h-6 ${tokens.textMuted}`} />
                  <div>
                    <p className="font-semibold text-xs">No documents uploaded</p>
                    <p className={`text-[10px] mt-0.5 ${tokens.textMuted}`}>Upload floor maps, agreements, brochures, and videos.</p>
                  </div>
                  <button
                    onClick={() => {
                      setEditingFloorMap(undefined);
                      setIsManageFloorMapOpen(true);
                    }}
                    className={`mt-2 px-3 py-1.5 rounded-lg text-xs font-semibold ${tokens.accentBtn}`}
                  >
                    Upload Document
                  </button>
                </div>
              ) : (
                <div className="flex overflow-x-auto gap-4 pb-2 snap-x scrollbar-hide">
                  {project.floorMaps.slice(0, 4).map((map) => (
                    <div 
                      key={map.id} 
                      onClick={() => setFullScreenImage(map.fileUrl)}
                      className={`relative min-w-[160px] w-40 h-28 rounded-xl border overflow-hidden cursor-pointer group snap-start shrink-0 ${tokens.border}`}
                    >
                      <img 
                        src={map.fileUrl} 
                        alt={map.title} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Maximize2 className="w-5 h-5 text-white" />
                      </div>
                      <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 to-transparent p-2 pt-8">
                         <div className="flex flex-col gap-0.5">
                           <span className="text-[8px] uppercase font-bold tracking-wider text-white/70">
                             {(map.category || 'floor_map').replace('_', ' ')}
                           </span>
                           <p className="text-white text-[10px] font-bold line-clamp-1">{map.title}</p>
                         </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
{/* SUB-TAB 1: Clients */}
      {activeDetailTab === 'clients' && (
        <div className="space-y-4 ">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display text-2xl tracking-tight">
                Associated Clients ({linkedClients.length})
              </h3>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Buyers, investors, and stakeholders interested in {project.title}
              </p>
            </div>

            {!isLinkingClient && unlinkedClients.length > 0 && (
              <button
                type="button"
                onClick={() => setIsLinkingClient(true)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium border flex items-center gap-1.5 transition-colors ${tokens.border} ${tokens.surfaceHover}`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Link Another Client</span>
              </button>
            )}
          </div>

          {/* Link Client Popover/Form */}
          {isLinkingClient && (
            <div className={`p-4 rounded-xl border flex flex-wrap items-center gap-3 ${tokens.surfaceElevated} ${tokens.border}`}>
              <span className="text-xs font-medium">Select client to link:</span>
              <select
                value={selectedClientToLink}
                onChange={(e) => setSelectedClientToLink(e.target.value)}
                className={`px-3 py-1.5 rounded-lg text-xs border focus:outline-none ${tokens.surface} ${tokens.border}`}
              >
                <option value="">Choose a client...</option>
                {unlinkedClients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} — {c.company} ({c.role})
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={handleLinkClient}
                disabled={!selectedClientToLink}
                className={`px-4 py-1.5 rounded-lg text-xs font-semibold disabled:opacity-40 ${tokens.accentBtn}`}
              >
                Confirm Association
              </button>
              <button
                type="button"
                onClick={() => setIsLinkingClient(false)}
                className="text-xs text-stone-400 hover:text-stone-200"
              >
                Cancel
              </button>
            </div>
          )}

          {/* Clients Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {linkedClients.map((client) => (
              <div
                key={client.id}
                className={`p-5 rounded-2xl border transition-all ${tokens.surface} ${tokens.border}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3.5">
                    <img
                      src={client.avatar}
                      alt={client.name}
                      onClick={() => onSelectClient(client.id)}
                      className="w-12 h-12 rounded-full object-cover border-2 border-stone-500/20 cursor-pointer hover:scale-105 transition-transform"
                    />
                    <div>
                      <h4
                        onClick={() => onSelectClient(client.id)}
                        className="font-display text-lg tracking-tight hover:underline cursor-pointer"
                      >
                        {client.name}
                      </h4>
                      <p className={`text-xs ${tokens.textSecondary}`}>{client.role}</p>
                      <p className="text-[11px] font-mono text-stone-400">{client.company}</p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleUnlinkClient(client.id)}
                    className="text-[11px] text-stone-500 hover:text-red-400 font-mono transition-colors"
                    title="Remove association with this project"
                  >
                    Unlink
                  </button>
                </div>

                {/* Contact info & quick actions */}
                <div className="mt-4 pt-3 border-t border-inherit flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-3 text-stone-400 text-[11px] font-mono">
                    <span className="flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      {client.phone}
                    </span>
                    {client.whatsappNumber && (
                      <span className="flex items-center gap-1 text-emerald-400">
                        <MessageSquare className="w-3 h-3" />
                        WA
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenVoiceRecorder(client.id, project.id)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-medium flex items-center gap-1 ${tokens.accentBgTint} ${tokens.accentText}`}
                    >
                      <Mic className="w-3 h-3" />
                      <span>Voice Memo</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onSelectClient(client.id)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] border ${tokens.border} hover:${tokens.surfaceHover}`}
                    >
                      View Dossier
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {linkedClients.length === 0 && (
              <div className={`col-span-2 p-8 rounded-2xl border text-center border-dashed ${tokens.border}`}>
                <Users className="w-8 h-8 mx-auto text-stone-500 mb-2 opacity-50" />
                <p className="text-xs text-stone-400">
                  No clients currently assigned to this project.
                </p>
                <button
                  type="button"
                  onClick={() => setIsLinkingClient(true)}
                  className={`mt-3 px-4 py-1.5 rounded-xl text-xs font-semibold ${tokens.accentBtn}`}
                >
                  Link a Client
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: Milestones & Phasing */}
      {activeDetailTab === 'milestones' && (
        <div className="space-y-4 ">
          <div className={`p-6 rounded-2xl border space-y-4 ${tokens.surface} ${tokens.border}`}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-xl tracking-tight">Milestones & Construction Phasing</h3>
                <p className={`text-xs ${tokens.textSecondary}`}>
                  Track and sign-off structural and development stages for {project.title}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsAddingMilestone(!isAddingMilestone)}
                className={`text-xs font-mono flex items-center gap-1 hover:underline ${tokens.accentText}`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Phase</span>
              </button>
            </div>

            {isAddingMilestone && (
              <form onSubmit={handleAddMilestone} className="space-y-2 p-3 rounded-xl bg-stone-500/10">
                <input
                  type="text"
                  required
                  value={newMilestoneTitle}
                  onChange={(e) => setNewMilestoneTitle(e.target.value)}
                  placeholder="e.g. Demarcation stone pillar installation & RERA inspection"
                  className={`w-full px-3 py-1.5 text-xs rounded-lg border focus:outline-none ${tokens.surface} ${tokens.border}`}
                />
                <div className="flex items-center justify-between gap-2">
                  <input
                    type="date"
                    value={newMilestoneDate}
                    onChange={(e) => setNewMilestoneDate(e.target.value)}
                    className={`px-2 py-1 text-xs rounded-lg border ${tokens.surface} ${tokens.border}`}
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setIsAddingMilestone(false)}
                      className="text-xs text-stone-400"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className={`px-3 py-1 text-xs rounded-lg font-semibold ${tokens.accentBtn}`}
                    >
                      Save
                    </button>
                  </div>
                </div>
              </form>
            )}

            <div className="space-y-2.5">
              {project.milestones.map((milestone) => (
                <div
                  key={milestone.id}
                  onClick={() => handleToggleMilestone(milestone.id)}
                  className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 cursor-pointer transition-colors ${tokens.surfaceElevated} ${tokens.border} hover:${tokens.surfaceHover}`}
                >
                  <div className="flex items-center gap-3">
                    {milestone.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                    ) : (
                      <Circle className="w-4 h-4 text-stone-500 shrink-0" />
                    )}
                    <span
                      className={`text-xs font-medium ${
                        milestone.completed ? 'line-through text-stone-500' : tokens.textPrimary
                      }`}
                    >
                      {milestone.title}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-stone-400 shrink-0">
                    {milestone.dueDate}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: Audio Intelligence & Voice Notes */}
      {activeDetailTab === 'audio' && (
        <div className="space-y-4 ">
          <div className={`p-6 rounded-2xl border space-y-4 ${tokens.surface} ${tokens.border}`}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-xl tracking-tight">Audio Notes & Call Recordings</h3>
                <p className={`text-xs ${tokens.textSecondary}`}>
                  Site voice memos, client call recordings, and speech transcripts for {project.title}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onOpenVoiceRecorder(project.clientIds[0], project.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 ${tokens.accentBtn}`}
                title="Record new call"
              >
                <Mic className="w-3.5 h-3.5" />
                <span>Record Voice Note</span>
              </button>
            </div>

            <div className="space-y-3">
              {attachedRecordings.map((rec) => {
                const linkedClient = clients.find((c) => c.id === rec.clientId);
                return (
                  <ExpandableVoiceRecordingItem
                    key={rec.id}
                    recording={rec}
                    clientName={linkedClient?.name}
                    projectName={project.title}
                    onOpenVoiceRecorder={onOpenVoiceRecorder}
                  />
                );
              })}

              {attachedRecordings.length === 0 && (
                <div className="p-8 rounded-2xl border border-dashed border-stone-500/20 text-center text-xs text-stone-400">
                  <Mic className="w-6 h-6 mx-auto mb-2 opacity-40 text-stone-400" />
                  No audio logs saved for {project.title} yet. Use the Voice Recorder to archive site notes and client calls.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: Contract Deliverables */}
      {activeDetailTab === 'deliverables' && (
        <div className="space-y-4 ">
          <div className={`p-6 rounded-2xl border space-y-4 ${tokens.surface} ${tokens.border}`}>
            <div>
              <h3 className="font-display text-xl tracking-tight">Contract Deliverables & SOW</h3>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Architectural layout maps, plot demarcation registries, and submittals
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {project.deliverables.map((item, i) => (
                <div
                  key={i}
                  className={`p-4 rounded-2xl border flex items-start gap-3 ${tokens.surfaceElevated} ${tokens.border}`}
                >
                  <div className={`p-2 rounded-xl text-stone-300 ${tokens.bgSubtle}`}>
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-semibold">{item}</h5>
                    <span className="text-[10px] font-mono text-stone-400">
                      Deliverable #{i + 1}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      
      {/* SUB-TAB: Floor Maps & Documents */}
      {activeDetailTab === 'documents' && (
        <div className="space-y-4 ">
          <div className={`p-6 rounded-[28px] border space-y-6 ${tokens.surface} ${tokens.border}`}>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="font-display text-2xl tracking-tight">Floor Maps & Documents</h3>
                <p className={`text-xs mt-1 ${tokens.textSecondary}`}>
                  Manage site layouts, floor plans, and important project documents.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setEditingFloorMap(undefined);
                  setIsManageFloorMapOpen(true);
                }}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${tokens.accentBtn}`}
              >
                <Plus className="w-4 h-4" />
                <span>Upload Document</span>
              </button>
            </div>

            {(!project.floorMaps || project.floorMaps.length === 0) ? (
              <div className={`p-8 rounded-2xl border border-dashed flex flex-col items-center justify-center text-center space-y-3 ${tokens.border} ${tokens.bgSubtle}`}>
                <Map className={`w-8 h-8 ${tokens.textMuted}`} />
                <div>
                  <p className="font-semibold text-sm">No documents uploaded</p>
                  <p className={`text-xs mt-0.5 ${tokens.textMuted}`}>Upload floor maps, agreements, brochures, videos, and master layouts.</p>
                </div>
              </div>
            ) : (
              <>
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className={`flex gap-2 p-1 border rounded-xl ${tokens.bgSubtle} ${tokens.border}`}>
                    {['all', 'floor_map', 'agreement', 'brochure', 'video', 'other'].map((f) => (
                      <button
                        key={f}
                        onClick={() => setDocFilter(f as any)}
                        className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold capitalize transition-all ${
                          docFilter === f
                            ? `${tokens.accentBgTint} ${tokens.accentText} shadow-sm`
                            : `${tokens.textSecondary} hover:${tokens.textPrimary}`
                        }`}
                      >
                        {f === 'all' ? 'All' : f.replace('_', ' ')}
                      </button>
                    ))}
                  </div>
                </div>


              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {(docFilter === 'all' ? project.floorMaps : project.floorMaps.filter(m => (m.category || 'floor_map') === docFilter)).map((map) => {
                  const isVideo = map.category === 'video' || (map.fileUrl && (map.fileUrl.startsWith('data:video/') || map.fileUrl.match(/\.(mp4|webm|ogg|mov)$/i)));
                  return (
                  <div key={map.id} className={`group relative rounded-2xl border overflow-hidden flex flex-col ${tokens.border} ${tokens.surfaceHover}`}>
                    <div 
                      className="relative w-full h-40 bg-stone-500/10 cursor-pointer overflow-hidden"
                      onClick={() => setFullScreenImage(map.fileUrl)}
                    >
                      {isVideo ? (
                        <video 
                          src={map.fileUrl} 
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 pointer-events-none" 
                          muted 
                          playsInline 
                        />
                      ) : (
                        <img src={map.fileUrl} alt={map.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                      )}
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        {isVideo ? <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-md"><div className="w-0 h-0 border-t-4 border-t-transparent border-l-6 border-l-white border-b-4 border-b-transparent ml-1"></div></div> : <Maximize2 className="w-6 h-6 text-white" />}
                      </div>
                      
                    </div>
                    <div className="p-4 flex flex-col gap-2 flex-1">
                      <div className="flex justify-between items-start gap-2">
                        
                        <div className="flex flex-col gap-1">
                          <h4 className="font-semibold text-sm line-clamp-1">{map.title}</h4>
                          <span className={`text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md w-fit ${tokens.accentBgTint} ${tokens.accentText}`}>
                            {(map.category || 'floor_map').replace('_', ' ')}
                          </span>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingFloorMap(map);
                              setIsManageFloorMapOpen(true);
                            }}
                            className={`p-1.5 rounded-lg ${tokens.textSecondary} hover:${tokens.textPrimary} hover:bg-stone-500/20 transition-colors`}
                            title="Edit"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm('Are you sure you want to delete this document?')) {
                                const newMaps = project.floorMaps!.filter(m => m.id !== map.id);
                                updateProject(project.id, { floorMaps: newMaps });
                              }
                            }}
                            className="p-1.5 rounded-lg text-red-500/70 hover:text-red-500 hover:bg-red-500/10 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      {map.notes && <p className={`text-xs line-clamp-2 ${tokens.textMuted}`}>{map.notes}</p>}
                      <p className={`text-[10px] font-mono mt-auto pt-2 border-t ${tokens.border} ${tokens.textMuted}`}>
                        Uploaded: {new Date(map.uploadedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                )})}
              </div>
              </>
            )}
          </div>
        </div>
      )}

      
      {/* Floor Map Manager */}
      <ManageFloorMapModal
        isOpen={isManageFloorMapOpen}
        onClose={() => setIsManageFloorMapOpen(false)}
        existingMap={editingFloorMap}
        onSave={(floorMapData) => {
          if (editingFloorMap) {
            const newMaps = project.floorMaps!.map(m => m.id === editingFloorMap.id ? { ...m, ...floorMapData } : m);
            updateProject(project.id, { floorMaps: newMaps });
          } else {
            const newMap: FloorMap = {
              ...floorMapData,
              id: 'map-' + Date.now().toString(),
              uploadedAt: new Date().toISOString()
            };
            const currentMaps = project.floorMaps || [];
            updateProject(project.id, { floorMaps: [...currentMaps, newMap] });
          }
        }}
        onDelete={() => {
          if (editingFloorMap) {
            const newMaps = project.floorMaps!.filter(m => m.id !== editingFloorMap.id);
            updateProject(project.id, { floorMaps: newMaps });
          }
        }}
      />

      {/* Full Screen Image Viewer */}
      {fullScreenImage && (
        <div 
          className="fixed inset-0 z-[60] bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in zoom-in-95 duration-200 cursor-pointer"
          onClick={() => setFullScreenImage(null)}
        >
          <button 
            className={`absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors`}
            onClick={(e) => { e.stopPropagation(); setFullScreenImage(null); }}
          >
            <X className="w-6 h-6" />
          </button>
          {(fullScreenImage.startsWith('data:video/') || fullScreenImage.match(/\.(mp4|webm|ogg|mov)$/i)) ? (
             <video 
               src={fullScreenImage} 
               controls 
               autoPlay 
               className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
               onClick={(e) => e.stopPropagation()} 
             />
          ) : (
             <img 
               src={fullScreenImage} 
               alt="Full Screen Preview" 
               className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
               onClick={(e) => e.stopPropagation()}
             />
          )}
        </div>
      )}

      {/* Edit Project Modal */}
      <EditProjectModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        project={project}
      />

      {/* Quick Comm Modal */}
      <QuickCommModal
        isOpen={isCommModalOpen}
        onClose={() => setIsCommModalOpen(false)}
        initialProjectId={project.id}
        initialClientId={project.clientIds[0]}
        onOpenVoiceRecorder={onOpenVoiceRecorder}
      />
    </div>
  );
};
