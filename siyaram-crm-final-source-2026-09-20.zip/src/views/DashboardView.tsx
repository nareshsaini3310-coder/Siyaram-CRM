import { motion, AnimatePresence } from 'motion/react';
import React, { useState } from 'react';
import { Settings,
  Plus,
  Phone,
  MessageSquare,
  FileText,
  Calendar,
  CheckCircle2,
  Clock,
  Briefcase,
  Users,
  Mic,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Volume2,
  Send,
  Edit,
  MapPin,
  Layers,
  Building, Building2, Map, User } from 'lucide-react';
import { ViewType, Client, Project, FollowUp, CommChannel, CommLog } from '../types';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { QuickCommModal } from '../components/QuickCommModal';
import { EditProjectModal } from '../components/EditProjectModal';
import { EditFollowUpModal } from '../components/EditFollowUpModal';
import { AddClientModal } from '../components/AddClientModal';
import { ExpandableVoiceRecordingItem } from '../components/ExpandableVoiceRecordingItem';
import { MorningAgendaCard } from '../components/MorningAgendaCard';
import { isOverdueFollowUp, getLeadTemperature } from '../utils/leadRules';
import { startCellularCall } from '../utils/nativeBridge';

interface DashboardViewProps {
  onNavigate: (view: ViewType) => void;
  onSelectProject: (projectId: string) => void;
  onSelectClient: (clientId: string) => void;
  onOpenVoiceRecorder: (clientId?: string, projectId?: string, followUpId?: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onSelectProject,
  onSelectClient,
  onOpenVoiceRecorder,
}) => {
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return 'Good Morning';
    if (hour >= 12 && hour < 17) return 'Good Afternoon';
    if (hour >= 17 && hour < 22) return 'Good Evening';
    return 'Good Night';
  };
  const greeting = getGreeting();

  const { theme, tokens, accent } = useTheme();
  const { user } = useAuth();
  const {
    projects,
    clients,
    followUps,
    recordings,
    commLogs,
    stats,
    toggleFollowUpStatus,
    addFollowUp,
  } = useData();

  // Primary Tab within Dashboard: Today's Board | Live Sites | Voice & Comm Logs
  const [activeBoardTab, setActiveBoardTab] = useState<'today' | 'comm' | 'sites' | 'audio'>('today');

  // Secondary Sub-tab (tab ke andar tab!)
  const [subTabUpcoming, setSubTabUpcoming] = useState<'all' | 'calls' | 'whatsapp' | 'reviews'>('all');
  const [subTabSites, setSubTabSites] = useState<'all' | 'active' | 'review'>('all');
  const [subTabAudio, setSubTabAudio] = useState<'all' | 'recent' | 'actions'>('all');
  const [subTabComm, setSubTabComm] = useState<'all' | 'whatsapp' | 'call' | 'sms'>('all');

  // Quick Action Modal & Communication Modal
  const [isQuickActionOpen, setIsQuickActionOpen] = useState(false);
  const [isCommModalOpen, setIsCommModalOpen] = useState(false);
  const [commClientId, setCommClientId] = useState<string | undefined>(undefined);
  const [commChannel, setCommChannel] = useState<CommChannel>('whatsapp');

  // Modals for editing Siyaram project or follow-ups
  const [isEditProjectOpen, setIsEditProjectOpen] = useState(false);
  const [isEditFollowUpOpen, setIsEditFollowUpOpen] = useState(false);
  const [isAddClientOpen, setIsAddClientOpen] = useState(false);
  const [isFabMenuOpen, setIsFabMenuOpen] = useState(false);
  const [selectedFollowUpToEdit, setSelectedFollowUpToEdit] = useState<FollowUp | undefined>(undefined);

  // Featured Project: Siyaram
  const siyaramProject = projects.find((p) => p.title.toLowerCase().includes('siyaram')) || projects[0];

  // Recent client (like "Ananya" or first client)
  const recentClient = clients.find((c) => c.id === 'cli-ananya') || clients[0];

  // Live sites count
  const liveSitesCount = projects.filter((p) => p.status === 'active').length;

  // Calls due today only; never use a hard-coded fallback.
  const localDateKey = (date = new Date()) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  };
  const todayKey = localDateKey();
  const callsTodayCount = followUps.filter(
    (f) => f.type === 'call' && f.status === 'pending' && f.dueDate === todayKey
  ).length;

  // Overdue count
  const overdueCount = followUps.filter((f) => isOverdueFollowUp(f)).length;

  const attentionClients = clients
    .map((client) => ({ client, temperature: getLeadTemperature(client, followUps) }))
    .filter(({ client }) => {
      const hasPending = followUps.some((f) => f.clientId === client.id && f.status === 'pending');
      const hasOverdue = followUps.some((f) => f.clientId === client.id && isOverdueFollowUp(f));
      return hasOverdue || !hasPending;
    })
    .sort((a, b) => (a.temperature === 'hot' ? -1 : a.temperature === 'warm' ? 0 : 1) - (b.temperature === 'hot' ? -1 : b.temperature === 'warm' ? 0 : 1))
    .slice(0, 5);

  // Filtered upcoming items based on sub-tab
  const filteredUpcoming = followUps.filter((f) => {
    if (f.status === 'completed') return false;
    if (f.dueDate !== todayKey) return false;
    if (subTabUpcoming === 'calls') return f.type === 'call';
    if (subTabUpcoming === 'whatsapp') return f.type === 'whatsapp';
    if (subTabUpcoming === 'reviews') return f.type === 'review' || f.type === 'meeting';
    return true;
  });

  // Filtered live sites based on sub-tab
  const filteredSites = projects.filter((p) => {
    if (subTabSites === 'active') return p.status === 'active';
    if (subTabSites === 'review') return p.status === 'in_review';
    return true;
  });

  // Filtered comm logs
  const filteredCommLogs = commLogs.filter((log) => {
    if (subTabComm === 'all') return true;
    return log.channel === subTabComm;
  });

  const cardStyle = `${tokens.surface} ${tokens.border} ${tokens.surfaceHover}`;
  const btn3DStyle = theme === 'dark' ? 'tactile-btn-3d-dark' : 'tactile-btn-3d-dawn';

  const handleOpenWhatsAppDirect = (client?: Client) => {
    if (!client) {
      setIsCommModalOpen(true);
      setCommChannel('whatsapp');
      return;
    }
    const targetNumber = (client.whatsappNumber || client.phone || '').replace(/[^0-9]/g, '');
    if (!targetNumber) {
      setCommClientId(client.id);
      setCommChannel('whatsapp');
      setIsCommModalOpen(true);
      return;
    }
    const defaultMsg = encodeURIComponent(
      `Namaste ${client.name.split(' ')[0]}, this is Siyaram regarding our real estate project updates.`
    );
    window.open(`https://wa.me/${targetNumber}?text=${defaultMsg}`, '_blank', 'noopener,noreferrer');
  };

  const handleCallDirect = (client?: Client) => {
    if (!client) {
      setIsCommModalOpen(true);
      setCommChannel('call');
      return;
    }
    const targetNumber = (client.phone || client.whatsappNumber || '').replace(/[^0-9]/g, '');
    if (targetNumber) {
      startCellularCall(targetNumber);
    } else {
      setCommClientId(client.id);
      setCommChannel('call');
      setIsCommModalOpen(true);
    }
  };

  return (
    <div className="space-y-4 pb-20 max-w-3xl mx-auto">
      <div className="space-y-4 pt-1">
        <div className="flex items-center justify-between gap-4 pt-1">
          <div>
            <div className="flex items-center gap-2">
              <span className={`text-[10px] sm:text-[11px] font-mono tracking-widest uppercase font-semibold ${tokens.textMuted}`}>
                AAJ
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
            </div>
            <div className="flex flex-wrap items-end gap-3 mt-0.5">
              <h2 className="font-display text-xl sm:text-2xl tracking-tight leading-tight">
                {greeting}, {user?.name?.split(' ')[0] || 'Siyaram Ji'}
              </h2>
              <span className="font-display text-3xl sm:text-4xl font-black leading-none text-blue-400">
                {callsTodayCount}
              </span>
              <span className={`text-[10px] font-mono uppercase tracking-wider ${tokens.textMuted}`}>
                kaam aaj
              </span>
            </div>
            <p className={`text-xs sm:text-sm mt-0.5 max-w-md ${tokens.textSecondary}`}>
              Today's follow-up calls, urgent client dispatches, and active site inventory.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setActiveBoardTab('today')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 ${tokens.accentBtn}`}
            >
              <ArrowRight className="w-3.5 h-3.5" />
              <span>Shuru karo</span>
            </button>
            <button
              type="button"
              onClick={() => setIsQuickActionOpen(true)}
              className={`w-10 h-10 rounded-full flex items-center justify-center cursor-pointer transition-transform duration-150 active:scale-95 ${btn3DStyle}`}
              aria-label="Quick Action"
              title="Create New Call, Task, or Project"
            >
              <Plus className="w-5 h-5 text-blue-400" />
            </button>
          </div>
        </div>
      </div>


      {/* Project Statistics Widget */}
      <div className={`p-4 sm:p-5 rounded-[24px] flex flex-col sm:flex-row items-center justify-between gap-4 border ${cardStyle}`}>
        <div className="flex items-center gap-4 w-full">
          <div className="flex items-center gap-3 flex-1">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${tokens.accentBgTint} border ${tokens.accentBorder}`}>
              <Map className={`w-5 h-5 ${tokens.accentText}`} />
            </div>
            <div>
              <span className={`text-[10px] sm:text-xs font-mono uppercase tracking-wider block mb-0.5 ${tokens.textSecondary}`}>
                Total Plots
              </span>
              <div className="font-display text-lg sm:text-xl tracking-tight font-semibold">
                {projects.filter(p => p.projectType === 'plot').reduce((acc, p) => acc + (p.unitCount || 0), 0) || 220}
                <span className={`text-xs font-normal ml-1 ${tokens.textMuted}`}>units</span>
              </div>
            </div>
          </div>
          
          <div className={`w-px h-10 hidden sm:block ${tokens.border}`}></div>
          
          <div className="flex items-center gap-3 flex-1">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${tokens.accentBgTint} border ${tokens.accentBorder}`}>
              <Building2 className={`w-5 h-5 ${tokens.accentText}`} />
            </div>
            <div>
              <span className={`text-[10px] sm:text-xs font-mono uppercase tracking-wider block mb-0.5 ${tokens.textSecondary}`}>
                Active High-Rises
              </span>
              <div className="font-display text-lg sm:text-xl tracking-tight font-semibold">
                {projects.filter(p => p.projectType === 'high_rises' && p.status === 'active').reduce((acc, p) => acc + (p.unitCount || 0), 0) || 480}
                <span className={`text-xs font-normal ml-1 ${tokens.textMuted}`}>units</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Subah Ka Follow-up Agenda (Daily Morning Schedule & 2-Min Alert Center) */}
      <MorningAgendaCard
        onSelectClient={onSelectClient}
        onSelectProject={onSelectProject}
        onTest2MinAlert={() => {
          if ((window as any).__triggerTest2MinAlert) {
            (window as any).__triggerTest2MinAlert();
          }
        }}
      />

      {/* 
        FOUR 3D HERO METRIC CARDS (2x2 Grid)
        1. Calls & Follow-ups today: 3
        2. Last client contact: Ananya (Connected)
        3. Overdue follow-ups
        4. Siyaram Project Specs (Plots, High Rises, Land)
      */}
      <div className="grid grid-cols-2 gap-3.5 sm:gap-4">
        {/* Tile 1: Calls Today */}
        <div
          onClick={() => {
            setActiveBoardTab('today');
            setSubTabUpcoming('calls');
          }}
          className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 ease-out hover:scale-[1.03] hover:-translate-y-1 hover:brightness-[1.15] ${cardStyle}`}
        >
          <span className={`text-xs sm:text-[13px] font-medium block ${tokens.textSecondary}`}>
            Upcoming calls
          </span>
          <div className="font-display text-xl sm:text-2xl tracking-tight mt-2 font-semibold text-blue-400">
            {callsTodayCount}
          </div>
          <span className="text-[10px] font-mono text-stone-400 block mt-2">
            scheduled touchpoints
          </span>
        </div>

        {/* Tile 2: Last Call / Contact */}
        <div
          onClick={() => recentClient && onSelectClient(recentClient.id)}
          className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 ease-out hover:scale-[1.03] hover:-translate-y-1 hover:brightness-[1.15] ${cardStyle}`}
        >
          <span className={`text-xs sm:text-[13px] font-medium block ${tokens.textSecondary}`}>
            Last contact
          </span>
          <div className="font-display text-xl sm:text-2xl tracking-tight mt-2 font-semibold truncate hover:underline">
            {recentClient?.name.split(' ')[0] || 'Ananya'}
          </div>
          <span className="text-[10px] font-mono text-emerald-400 block mt-2 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
            WhatsApp & Call active
          </span>
        </div>

        {/* Tile 3: Overdue */}
        <div
          onClick={() => {
            setActiveBoardTab('today');
            setSubTabUpcoming('all');
          }}
          className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 ease-out hover:scale-[1.03] hover:-translate-y-1 hover:brightness-[1.15] ${cardStyle}`}
        >
          <span className={`text-xs sm:text-[13px] font-medium block ${tokens.textSecondary}`}>
            Follow-ups
          </span>
          <div className="font-display text-xl sm:text-2xl tracking-tight mt-2 font-semibold">
            {followUps.filter((f) => f.status === 'pending').length}
          </div>
          <span className="text-[10px] font-mono text-stone-400 block mt-2">
            pending agenda items
          </span>
        </div>

        {/* Tile 4: Project Siyaram Specs */}
        <div
          onClick={() => siyaramProject && onSelectProject(siyaramProject.id)}
          className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 ease-out hover:scale-[1.03] hover:-translate-y-1 hover:brightness-[1.15] ${cardStyle}`}
        >
          <span className={`text-xs sm:text-[13px] font-medium block text-blue-400`}>
            Project Siyaram
          </span>
          <div className="font-display text-lg sm:text-xl tracking-tight mt-1 font-semibold truncate">
            {siyaramProject?.propertyType || 'Plots & High Rises'}
          </div>
          <span className="text-[10px] font-mono text-stone-400 block mt-1 truncate">
            {siyaramProject?.location || 'Sector 84 Expressway'}
          </span>
        </div>
      </div>

      {/* 
        FEATURED SIYARAM PROJECT SHOWCASE CARD
        Gives user instant access to edit plot, high-rises, land, location anytime!
      */}
      {siyaramProject && (
        <div className={`p-5 rounded-[24px] border ${cardStyle}`}>
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-inherit">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300">
                Flagship Project
              </span>
              <h2 className="font-display text-xl sm:text-2xl font-bold tracking-tight">
                {siyaramProject.title}
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsEditProjectOpen(true)}
                className="px-3 py-1 rounded-xl text-xs font-semibold border flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
                title="Edit Siyaram project details, plot sizes, location, and high-rises"
              >
                <Edit className="w-3.5 h-3.5 text-blue-400" />
                <span>Edit Specs</span>
              </button>
              <button
                type="button"
                onClick={() => onSelectProject(siyaramProject.id)}
                className={`px-3 py-1 rounded-xl text-xs font-semibold ${tokens.accentBtn}`}
              >
                View Project
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3.5">
            <div className="p-2.5 rounded-xl bg-stone-500/10">
              <span className="text-[10px] font-mono uppercase text-stone-400 block">Location</span>
              <span className="text-xs font-mono font-semibold truncate block mt-0.5 text-stone-200">
                {siyaramProject.location || 'Sector 84, Hub'}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-stone-500/10">
              <span className="text-[10px] font-mono uppercase text-stone-400 block">Plots</span>
              <span className="text-xs font-mono font-semibold truncate block mt-0.5 text-stone-200">
                {siyaramProject.plotDetails || '150, 250, 500 Yd'}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-stone-500/10">
              <span className="text-[10px] font-mono uppercase text-stone-400 block">High Rises</span>
              <span className="text-xs font-mono font-semibold truncate block mt-0.5 text-stone-200">
                {siyaramProject.highRiseDetails || 'G+32 Towers'}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-stone-500/10">
              <span className="text-[10px] font-mono uppercase text-stone-400 block">Land Area</span>
              <span className="text-xs font-mono font-semibold truncate block mt-0.5 text-stone-200">
                {siyaramProject.landArea || '38.5 Acres'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 
        INTERACTIVE QUICK OUTREACH CARD (Matches screenshot design)
        Left circular phone button, middle client info, 3 right tactile buttons
      */}
      {recentClient && (
        <div className={`p-4 sm:p-5 rounded-[24px] flex items-center justify-between gap-3 ${cardStyle}`}>
          <div className="flex items-center gap-3.5 min-w-0">
            {/* Left circular phone button */}
            <button
              type="button"
              onClick={() => handleCallDirect(recentClient)}
              className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 cursor-pointer ${btn3DStyle}`}
              title={`Call ${recentClient.name}`}
            >
              <Phone className="w-4 h-4 text-emerald-400" />
            </button>

            {/* Middle text details */}
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-[11px] font-mono text-stone-400">
                <span>Recent Client</span>
                <span>·</span>
                <span className="text-emerald-400 font-medium">Ready for Outreach</span>
              </div>
              <h3
                onClick={() => onSelectClient(recentClient.id)}
                className="font-display text-base sm:text-lg tracking-tight font-semibold truncate cursor-pointer hover:underline"
              >
                {recentClient.name}
              </h3>
              <p className="text-[11px] font-mono text-stone-400 truncate">
                {recentClient.whatsappNumber || recentClient.phone}
              </p>
            </div>
          </div>

          {/* Right 3 circular tactile buttons: WhatsApp, Voice Memo, Dossier */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => handleOpenWhatsAppDirect(recentClient)}
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center cursor-pointer ${btn3DStyle}`}
              title="Open WhatsApp Chat"
            >
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
            </button>

            <button
              type="button"
              onClick={() => onOpenVoiceRecorder(recentClient.id)}
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center cursor-pointer ${btn3DStyle}`}
              title="Record Voice Note / Call Memo"
            >
              <Mic className="w-3.5 h-3.5 text-blue-400" />
            </button>

            <button
              type="button"
              onClick={() => onSelectClient(recentClient.id)}
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center cursor-pointer ${btn3DStyle}`}
              title="View Full Client Dossier"
            >
              <FileText className="w-3.5 h-3.5 text-stone-300" />
            </button>
          </div>
        </div>
      )}

      {/* 
        CRITICAL USER MANDATE: "tab ke andar tab hona chahie pure ek dusre se acchi tarike se indicated hona chahie"
        PRIMARY TABS + NESTED SECONDARY TABS
      */}
      <div className="space-y-4 pt-2">
        {/* RULE-BASED ATTENTION RADAR */}
        {attentionClients.length > 0 && (
          <section className={`p-4 rounded-[24px] border ${theme === 'dark' ? 'bg-white/[0.045] border-white/10' : 'bg-white/75 border-slate-200'} backdrop-blur-xl shadow-sm`}>
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-[10px] uppercase tracking-[0.18em] font-bold text-blue-500">Needs Your Attention</p>
                <h3 className="text-base font-semibold mt-0.5">Lead Radar</h3>
              </div>
              <span className="text-[10px] font-medium text-stone-400">Rule-based</span>
            </div>
            <div className="space-y-2">
              {attentionClients.map(({ client, temperature }) => {
                const tone = temperature === 'hot' ? 'text-rose-400 bg-rose-500/10 border-rose-500/20' : temperature === 'warm' ? 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20' : 'text-slate-400 bg-slate-500/10 border-slate-500/20';
                return (
                  <div key={client.id} className={`flex items-center gap-3 p-3 rounded-2xl border ${theme === 'dark' ? 'bg-black/10 border-white/5' : 'bg-white/60 border-slate-100'}`}>
                    <button type="button" onClick={() => onSelectClient(client.id)} className="flex-1 min-w-0 text-left">
                      <div className="font-semibold text-xs truncate">{client.name}</div>
                      <div className="text-[10px] text-stone-400 truncate">{client.nextFollowUpDate ? `Next: ${client.nextFollowUpDate}` : 'No next action set'}</div>
                    </button>
                    <span className={`px-2 py-1 rounded-full border text-[9px] uppercase font-bold ${tone}`}>{temperature}</span>
                    <button type="button" onClick={() => handleCallDirect(client)} className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-sm" aria-label={`Call ${client.name}`}>
                      <Phone className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* PRIMARY TAB LEVEL: Today's Board | Unified Comm Logs | Live Sites | Voice Briefs */}
        <div className="p-1 rounded-2xl bg-stone-500/10 border border-inherit flex flex-wrap items-center gap-1">
          {[
            { id: 'today', label: "Upcoming Calls", icon: Calendar },
            { id: 'comm', label: 'Comm Logs (All)', icon: MessageSquare },
            { id: 'sites', label: 'Live Sites', icon: Briefcase },
            { id: 'audio', label: 'Voice Notes', icon: Mic },
          ].map((tab) => {
            const active = activeBoardTab === tab.id;
            const TabIcon = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveBoardTab(tab.id as any)}
                className={`flex-1 min-w-[120px] py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  active
                    ? theme === 'dark'
                      ? 'tactile-pill-active-dark scale-[1.01]'
                      : 'tactile-pill-active-dawn scale-[1.01]'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary} hover:bg-stone-500/10`
                }`}
              >
                <TabIcon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* 
          TAB 1 CONTENT: UPCOMING CALLS & SCHEDULED FOLLOW-UPS
          With NESTED SUB-TABS (All, Phone Calls, WhatsApp, Design Reviews)
        */}
        {activeBoardTab === 'today' && (
          <div className="space-y-4 ">
            {/* Header with 'Upcoming Calls' and '+ Schedule Call' */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-display text-xl sm:text-2xl tracking-tight font-medium">
                  Upcoming Calls & Follow-ups
                </h2>
                <p className={`text-xs ${tokens.textSecondary}`}>
                  Schedule of upcoming telephone calls and WhatsApp follow-ups
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedFollowUpToEdit(undefined);
                  setIsEditFollowUpOpen(true);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 ${tokens.accentBtn}`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Schedule Call</span>
              </button>
            </div>

            {/* NESTED SUB-TAB BAR (Tab ke andar Tab) */}
            <div className="flex flex-wrap items-center gap-2">
              {[
                { id: 'all', label: `All Upcoming (${filteredUpcoming.length})` },
                { id: 'calls', label: `Phone Calls (${callsTodayCount})` },
                { id: 'whatsapp', label: 'WhatsApp Follow-ups' },
                { id: 'reviews', label: 'Site Reviews' },
              ].map((sub) => (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => setSubTabUpcoming(sub.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                    subTabUpcoming === sub.id
                      ? theme === 'dark'
                        ? 'bg-[#f4f1ea] text-[#0b0c0e] font-semibold shadow-sm'
                        : 'bg-[#1b1a17] text-[#ece7de] font-semibold shadow-sm'
                      : `${tokens.surfaceElevated} ${tokens.textSecondary} border ${tokens.border} hover:${tokens.textPrimary}`
                  }`}
                >
                  {sub.label}
                </button>
              ))}
            </div>

            {/* Upcoming List Cards */}
            <div className="space-y-3">
              {filteredUpcoming.map((item) => {
                const client = clients.find((c) => c.id === item.clientId);
                const project = projects.find((p) => p.id === item.projectId);

                return (
                  <div
                    key={item.id}
                    className={`p-4 rounded-[20px] flex items-center justify-between gap-3.5 transition-all ${cardStyle}`}
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <button
                        type="button"
                        onClick={() => toggleFollowUpStatus(item.id)}
                        className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center transition-colors shrink-0 ${
                          item.status === 'completed'
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'border-stone-500 hover:border-stone-300'
                        }`}
                        title="Mark Completed"
                      >
                        {item.status === 'completed' && <CheckCircle2 className="w-3 h-3" />}
                      </button>

                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span
                            className={`text-[9px] uppercase font-mono px-1.5 py-0.5 rounded font-semibold ${
                              item.type === 'whatsapp'
                                ? 'bg-emerald-500/20 text-emerald-400'
                                : item.priority === 'high'
                                ? 'bg-[#c85642]/20 text-[#c85642]'
                                : 'bg-cyan-500/20 text-cyan-300'
                            }`}
                          >
                            {item.type === 'whatsapp' ? 'WhatsApp' : item.type}
                          </span>
                          <span className="text-[10px] font-mono text-stone-400">
                            Due: {item.dueDate} {item.scheduledTime ? `· ${item.scheduledTime}` : ''}
                          </span>
                        </div>

                        <h4 className="font-medium text-xs sm:text-sm mt-0.5 truncate">
                          {item.title}
                        </h4>

                        {client && (
                          <div className="flex items-center gap-2 text-[11px] text-stone-400 mt-0.5">
                            <span
                              onClick={() => onSelectClient(client.id)}
                              className="hover:underline cursor-pointer font-semibold text-stone-300"
                            >
                              {client.name}
                            </span>
                            <span>·</span>
                            <span className="font-mono">{client.whatsappNumber || client.phone}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action buttons: Dial / WhatsApp / Edit */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* WhatsApp shortcut */}
                      <button
                        type="button"
                        onClick={() => handleOpenWhatsAppDirect(client)}
                        className="w-8 h-8 rounded-full bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 flex items-center justify-center cursor-pointer transition-colors"
                        title="Open WhatsApp"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                      </button>

                      {/* Phone call shortcut */}
                      <button
                        type="button"
                        onClick={() => handleCallDirect(client)}
                        className={`w-8 h-8 rounded-full flex items-center justify-center cursor-pointer ${btn3DStyle}`}
                        title="Dial phone"
                      >
                        <Phone className="w-3.5 h-3.5 text-stone-300" />
                      </button>

                      {/* Voice memo recorder */}
                      <button
                        type="button"
                        onClick={() => onOpenVoiceRecorder(item.clientId, item.projectId, item.id)}
                        className={`w-8 h-8 rounded-full flex items-center justify-center cursor-pointer ${btn3DStyle}`}
                        title="Record call audio / voice memo"
                      >
                        <Mic className="w-3.5 h-3.5 text-blue-400" />
                      </button>

                      {/* Edit follow-up */}
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedFollowUpToEdit(item);
                          setIsEditFollowUpOpen(true);
                        }}
                        className={`w-8 h-8 rounded-full flex items-center justify-center cursor-pointer ${btn3DStyle}`}
                        title="Edit scheduled follow-up"
                      >
                        <Edit className="w-3 h-3 text-stone-400" />
                      </button>
                    </div>
                  </div>
                );
              })}

              {filteredUpcoming.length === 0 && (
                <div className={`p-8 rounded-2xl text-center text-xs text-stone-400 ${cardStyle}`}>
                  No tasks or calls scheduled under this filter. Click "+ Schedule Call" to add one.
                </div>
              )}
            </div>
          </div>
        )}

        {/* 
          TAB 2 CONTENT: UNIFIED COMM LOGS (Calls, WhatsApp, SMS)
          Matches user request: "Jo call logs hota hai usmein hi call WhatsApp aur message teenon ka aana chahie"
        */}
        {activeBoardTab === 'comm' && (
          <div className="space-y-4 ">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-display text-xl sm:text-2xl tracking-tight font-medium">
                  Unified Call & Message Logs
                </h2>
                <p className={`text-xs ${tokens.textSecondary}`}>
                  Unified timeline of telephone calls, WhatsApp chats, and SMS dispatches
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setCommChannel('whatsapp');
                  setIsCommModalOpen(true);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 ${tokens.accentBtn}`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Send / Log</span>
              </button>
            </div>

            {/* NESTED SUB-TAB BAR for Communication */}
            <div className="flex flex-wrap items-center gap-2">
              {[
                { id: 'all', label: `All Logs (${commLogs.length})` },
                { id: 'whatsapp', label: 'WhatsApp' },
                { id: 'call', label: 'Calls' },
                { id: 'sms', label: 'SMS' },
              ].map((sub) => (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => setSubTabComm(sub.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                    subTabComm === sub.id
                      ? theme === 'dark'
                        ? 'bg-[#f4f1ea] text-[#0b0c0e] font-semibold shadow-sm'
                        : 'bg-[#1b1a17] text-[#ece7de] font-semibold shadow-sm'
                      : `${tokens.surfaceElevated} ${tokens.textSecondary} border ${tokens.border} hover:${tokens.textPrimary}`
                  }`}
                >
                  {sub.label}
                </button>
              ))}
            </div>

            {/* Comm Log Timeline */}
            <div className="space-y-3">
              {filteredCommLogs.slice(0, 10).map((log) => {
                const client = clients.find((c) => c.id === log.clientId);
                const isWhatsApp = log.channel === 'whatsapp';
                const isSMS = log.channel === 'sms';
                const isCall = log.channel === 'call';

                return (
                  <div key={log.id} className={`p-4 rounded-[20px] space-y-2 ${cardStyle}`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                            isWhatsApp
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : isSMS
                              ? 'bg-blue-500/20 text-blue-400'
                              : 'bg-cyan-500/20 text-cyan-300'
                          }`}
                        >
                          {isWhatsApp && <MessageSquare className="w-3.5 h-3.5" />}
                          {isSMS && <Send className="w-3.5 h-3.5" />}
                          {isCall && <Phone className="w-3.5 h-3.5" />}
                        </div>

                        <div>
                          <span className="text-xs font-semibold font-mono">
                            {log.channel.toUpperCase()} · {log.direction}
                          </span>
                          <span className="text-[10px] font-mono text-stone-400 block">
                            {new Date(log.timestamp).toLocaleString()}
                          </span>
                        </div>
                      </div>

                      {client && (
                        <button
                          type="button"
                          onClick={() => onSelectClient(client.id)}
                          className="text-xs font-semibold hover:underline text-stone-300"
                        >
                          {client.name}
                        </button>
                      )}
                    </div>

                    <p className={`text-xs ${tokens.textPrimary} pl-9 leading-relaxed`}>
                      {log.messageBody || log.notes}
                    </p>

                    {log.durationSeconds && (
                      <div className="pl-9 text-[10px] font-mono text-blue-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>Call Duration: {Math.floor(log.durationSeconds / 60)}m {log.durationSeconds % 60}s</span>
                      </div>
                    )}
                  </div>
                );
              })}

              {filteredCommLogs.length === 0 && (
                <div className={`p-8 rounded-2xl text-center text-xs text-stone-400 ${cardStyle}`}>
                  No communication logs under this channel.
                </div>
              )}
            </div>
          </div>
        )}

        {/* 
          TAB 3 CONTENT: LIVE SITES & COMMISSIONS
          With NESTED SUB-TABS (All, Active Construction, In Review)
        */}
        {activeBoardTab === 'sites' && (
          <div className="space-y-4 ">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl sm:text-2xl tracking-tight font-medium">
                Live Sites & Portfolios
              </h2>
              <button
                type="button"
                onClick={() => onNavigate('projects')}
                className="text-xs font-mono text-stone-400 hover:text-stone-200 transition-colors"
              >
                All Projects ({projects.length})
              </button>
            </div>

            {/* NESTED SUB-TAB BAR */}
            <div className="flex flex-wrap items-center gap-2">
              {[
                { id: 'all', label: 'All Portfolios' },
                { id: 'active', label: `Active Sites (${liveSitesCount})` },
                { id: 'review', label: 'In Review' },
              ].map((sub) => (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => setSubTabSites(sub.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                    subTabSites === sub.id
                      ? theme === 'dark'
                        ? 'bg-[#f4f1ea] text-[#0b0c0e] font-semibold shadow-sm'
                        : 'bg-[#1b1a17] text-[#ece7de] font-semibold shadow-sm'
                      : `${tokens.surfaceElevated} ${tokens.textSecondary} border ${tokens.border} hover:${tokens.textPrimary}`
                  }`}
                >
                  {sub.label}
                </button>
              ))}
            </div>

            {/* Projects list */}
            <div className="space-y-3.5">
              {filteredSites.map((project) => {
                const linkedClients = project.clientIds
                  .map((id) => clients.find((c) => c.id === id))
                  .filter(Boolean) as Client[];

                return (
                  <div
                    key={project.id}
                    onClick={() => onSelectProject(project.id)}
                    className={`p-5 rounded-[22px] cursor-pointer transition-all hover:scale-[1.005] ${cardStyle}`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-semibold">
                        {project.code}
                      </span>
                      <span className="text-xs font-mono font-bold">
                        €{project.budget.toLocaleString()}
                      </span>
                    </div>

                    <h3 className="font-display text-lg tracking-tight font-semibold hover:underline">
                      {project.title}
                    </h3>
                    <p className={`text-xs mt-1 line-clamp-2 ${tokens.textSecondary}`}>
                      {project.description}
                    </p>

                    {/* Associated Clients */}
                    <div className="mt-4 pt-3 border-t border-inherit flex items-center justify-between">
                      <div className="flex items-center -space-x-2">
                        {linkedClients.map((client) => (
                          <img
                            key={client.id}
                            src={client.avatar}
                            alt={client.name}
                            className="w-6 h-6 rounded-full object-cover border-2 border-stone-800"
                            title={client.name}
                          />
                        ))}
                        <span className="text-[11px] font-mono text-stone-400 pl-3">
                          {linkedClients.map((c) => c.name.split(' ')[0]).join(', ')}
                        </span>
                      </div>

                      <span className="text-xs font-mono text-stone-400 flex items-center gap-1">
                        <span>Details</span>
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 
          TAB 4 CONTENT: VOICE NOTES & BRIEFINGS
          With NESTED SUB-TABS
        */}
        {activeBoardTab === 'audio' && (
          <div className="space-y-4 ">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-display text-xl sm:text-2xl tracking-tight font-medium">
                  Voice Notes & Recordings
                </h2>
                <p className={`text-xs ${tokens.textSecondary}`}>
                  Voice memos and call recordings with your notes, transcripts and action items
                </p>
              </div>
              <button
                type="button"
                onClick={() => onOpenVoiceRecorder()}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 ${tokens.accentBtn}`}
              >
                <Mic className="w-3.5 h-3.5" />
                <span>Record Voice Note</span>
              </button>
            </div>

            {/* Recordings List */}
            <div className="space-y-3">
              {recordings.map((rec) => {
                const client = clients.find((c) => c.id === rec.clientId);
                const project = projects.find((p) => p.id === rec.projectId);

                return (
                  <ExpandableVoiceRecordingItem
                    key={rec.id}
                    recording={rec}
                    clientName={client?.name}
                    projectName={project?.title}
                    onOpenVoiceRecorder={onOpenVoiceRecorder}
                  />
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* 
        QUICK ACTION MODAL (Opened via '+' button)
      */}
      {isQuickActionOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs ">
          <div className={`w-full max-w-sm p-6 rounded-[28px] space-y-4 border ${cardStyle}`}>
            <div className="flex items-center justify-between pb-2 border-b border-inherit">
              <h3 className="font-display text-xl tracking-tight">Quick Action</h3>
              <button
                type="button"
                onClick={() => setIsQuickActionOpen(false)}
                className="text-xs text-stone-400 hover:text-stone-200"
              >
                Close
              </button>
            </div>

            <div className="space-y-2.5">
              {/* Manchaha WhatsApp */}
              <button
                type="button"
                onClick={() => {
                  setIsQuickActionOpen(false);
                  setCommChannel('whatsapp');
                  setIsCommModalOpen(true);
                }}
                className={`w-full p-3.5 rounded-2xl flex items-center gap-3 text-xs font-semibold cursor-pointer ${btn3DStyle}`}
              >
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp with any number</span>
              </button>

              {/* Add New Client */}
              <button
                type="button"
                onClick={() => {
                  setIsQuickActionOpen(false);
                  setIsAddClientOpen(true);
                }}
                className={`w-full p-3.5 rounded-2xl flex items-center gap-3 text-xs font-semibold cursor-pointer ${btn3DStyle}`}
              >
                <Users className="w-4 h-4 text-blue-400" />
                <span>Add New Client (Location, Mobile & Follow-up)</span>
              </button>

              {/* Voice Note / Recording */}
              <button
                type="button"
                onClick={() => {
                  setIsQuickActionOpen(false);
                  onOpenVoiceRecorder();
                }}
                className={`w-full p-3.5 rounded-2xl flex items-center gap-3 text-xs font-semibold cursor-pointer ${btn3DStyle}`}
              >
                <Mic className="w-4 h-4 text-[#6c9377]" />
                <span>Record Voice Note / Call Memo</span>
              </button>

              {/* Schedule Follow-up Call */}
              <button
                type="button"
                onClick={() => {
                  setIsQuickActionOpen(false);
                  setSelectedFollowUpToEdit(undefined);
                  setIsEditFollowUpOpen(true);
                }}
                className={`w-full p-3.5 rounded-2xl flex items-center gap-3 text-xs font-semibold cursor-pointer ${btn3DStyle}`}
              >
                <Calendar className="w-4 h-4 text-cyan-400" />
                <span>Schedule Upcoming Call / Follow-up</span>
              </button>

              {/* Edit Siyaram Project */}
              <button
                type="button"
                onClick={() => {
                  setIsQuickActionOpen(false);
                  setIsEditProjectOpen(true);
                }}
                className={`w-full p-3.5 rounded-2xl flex items-center gap-3 text-xs font-semibold cursor-pointer ${btn3DStyle}`}
              >
                <Edit className="w-4 h-4 text-blue-400" />
                <span>Edit Project Siyaram & Specs</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Communication Modal */}
      <QuickCommModal
        isOpen={isCommModalOpen}
        onClose={() => setIsCommModalOpen(false)}
        initialClientId={commClientId}
        initialChannel={commChannel}
        onOpenVoiceRecorder={onOpenVoiceRecorder}
      />

      {/* Edit Siyaram Project Modal */}
      {siyaramProject && (
        <EditProjectModal
          isOpen={isEditProjectOpen}
          onClose={() => setIsEditProjectOpen(false)}
          project={siyaramProject}
        />
      )}

      {/* Edit / Schedule Follow-up Modal */}
      <EditFollowUpModal
        isOpen={isEditFollowUpOpen}
        onClose={() => {
          setIsEditFollowUpOpen(false);
          setSelectedFollowUpToEdit(undefined);
        }}
        followUp={selectedFollowUpToEdit}
      />

      {/* Add Client Modal with Location & Follow-up presets */}
      {/* Floating Action Button (FAB) */}
      <div className="fixed bottom-[calc(var(--siyaram-dock-space)+0.75rem)] right-4 sm:right-10 z-40 flex flex-col items-end gap-3">
        <AnimatePresence>
          {isFabMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.9 }}
              transition={{ duration: 0.15 }}
              className="flex flex-col gap-3 mb-2 items-end"
            >
              <button
                onClick={() => {
                  setIsFabMenuOpen(false);
                  setIsAddClientOpen(true);
                }}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl shadow-xl border backdrop-blur-xl transition-transform hover:scale-105 active:scale-95 ${theme === 'dark' ? 'bg-blue-500/10 border-blue-400/20' : 'bg-white/80 border-blue-300'} ${tokens.surfaceElevated}`}
              >
                <span className={`text-xs font-semibold ${tokens.textPrimary}`}>New Lead</span>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tokens.accentBgTint} border ${tokens.accentBorder}`}>
                  <User className={`w-4 h-4 ${tokens.accentText}`} />
                </div>
              </button>
              
              <button
                onClick={() => {
                  setIsFabMenuOpen(false);
                  setIsEditProjectOpen(true);
                }}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl shadow-xl border backdrop-blur-xl transition-transform hover:scale-105 active:scale-95 ${theme === 'dark' ? 'bg-blue-500/10 border-blue-400/20' : 'bg-white/80 border-blue-300'} ${tokens.surfaceElevated}`}
              >
                <span className={`text-xs font-semibold ${tokens.textPrimary}`}>New Project</span>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tokens.accentBgTint} border ${tokens.accentBorder}`}>
                  <Map className={`w-4 h-4 ${tokens.accentText}`} />
                </div>
              </button>
              
              <button
                onClick={() => {
                  setIsFabMenuOpen(false);
                  setIsCommModalOpen(true);
                }}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl shadow-xl border backdrop-blur-xl transition-transform hover:scale-105 active:scale-95 ${theme === 'dark' ? 'bg-blue-500/10 border-blue-400/20' : 'bg-white/80 border-blue-300'} ${tokens.surfaceElevated}`}
              >
                <span className={`text-xs font-semibold ${tokens.textPrimary}`}>Quick Dispatch</span>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tokens.accentBgTint} border ${tokens.accentBorder}`}>
                  <MessageSquare className={`w-4 h-4 ${tokens.accentText}`} />
                </div>
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <button
          onClick={() => setIsFabMenuOpen(!isFabMenuOpen)}
            className={`w-14 h-14 rounded-full shadow-[0_8px_30px_rgba(37,99,235,0.28)] flex items-center justify-center backdrop-blur-xl border transition-all duration-300 hover:scale-105 active:scale-95 ${theme === 'dark' ? 'bg-blue-500/20 border-blue-400/40' : 'bg-blue-100 border-blue-400'} z-50`}
        >
          <motion.div animate={{ rotate: isFabMenuOpen ? 45 : 0 }} transition={{ duration: 0.2 }}>
            <Plus className="w-6 h-6 text-blue-500" />
          </motion.div>
        </button>
      </div>

      <AddClientModal
        isOpen={isAddClientOpen}
        onClose={() => setIsAddClientOpen(false)}
        onClientCreated={(newClientId) => onSelectClient(newClientId)}
      />
    </div>
  );
};
