import React, { useState, useRef } from 'react';
import { Settings,
  Sun,
  Moon,
  Check,
  Palette,
  Mic,
  ShieldCheck,
  User,
  Type,
  Volume2,
  RefreshCw,
  LogOut,
  Sparkles, Wifi, WifiOff,
  Monitor,
  CheckCircle2,
  Lock,
  Database,
  Download,
  Upload,
  RotateCcw,
  FileCheck,
  AlertTriangle } from 'lucide-react';
import { ThemeMode, AccentColor, ThemePreference } from '../types';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { clientStatusConfig, projectStatusConfig } from '../utils/status';
import { haptics } from '../utils/haptics';

export const SettingsView: React.FC = () => {
  const {
    theme,
    preference,
    isAutoTheme,
    systemTheme,
    setTheme,
    setPreference,
    setAutoTheme,
    accent,
    setAccent,
    tokens,
  } = useTheme();
  const { user, logout, openAuthModal } = useAuth();
  const {
    simulateSyncConflict,
    isOfflineMode,
    toggleOfflineMode,
    exportDataBackup,
    importDataBackup,
    resetToMasterData,
  } = useData();

  const [testMicState, setTestMicState] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [micFeedback, setMicFeedback] = useState<string | null>(null);
  const [activeSettingsTab, setActiveSettingsTab] = useState<'appearance' | 'voice' | 'account' | 'lock'>('appearance');
  const [backupMessage, setBackupMessage] = useState<string | null>(null);
  const [resetModalOpen, setResetModalOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const testMicrophone = async () => {
    setTestMicState('testing');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setTestMicState('success');
      setMicFeedback('Microphone hardware calibrated and ready for call capture.');
      setTimeout(() => {
        stream.getTracks().forEach((t) => t.stop());
      }, 1500);
    } catch (e: any) {
      setTestMicState('error');
      setMicFeedback('Microphone permission is required for Voice Notes.');
    }
  };

  return (
    <div className="space-y-8  max-w-4xl">
      {/* Header */}
      <div className="pb-2 border-b border-inherit">
        <span className={`text-[11px] font-mono tracking-widest uppercase ${tokens.textMuted}`}>
          Studio Environment & Preferences
        </span>
        <h2 className="font-display text-3xl tracking-tight mt-0.5">
          Appearance, Typography & System Configuration
        </h2>
        <p className={`text-xs ${tokens.textSecondary}`}>
          Configure the visual system, palette modes, and voice recording integrations
        </p>
      </div>

      {/* NESTED SUB-TABS (Tab ke andar Tab) */}
      <div className="space-y-4">
        <div className="p-1 rounded-2xl bg-stone-500/10 border border-inherit flex flex-wrap items-center gap-1">
          {[
            { id: 'appearance', label: 'Palette & Typography', icon: Palette },
            { id: 'lock', label: 'Lock & Portability', icon: Lock },
            { id: 'voice', label: 'Audio & Mic Hardware', icon: Mic },
            { id: 'account', label: 'Better-Auth Security', icon: ShieldCheck },
          ].map((tab) => {
            const active = activeSettingsTab === tab.id;
            const TabIcon = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveSettingsTab(tab.id as any)}
                className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  active
                    ? theme === 'dark'
                      ? 'tactile-pill-active-dark scale-[1.01]'
                      : 'tactile-pill-active-dawn scale-[1.01]'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary} hover:bg-stone-500/10`
                }`}
              >
                <TabIcon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* SUB-TAB 1: Appearance & Typography */}
      {activeSettingsTab === 'appearance' && (
      <div className="space-y-6 ">
        {/* Theme Modes & Auto-Switch Selector */}
        <div className={`p-6 sm:p-8 rounded-[24px] space-y-6 ${tokens.surface} ${tokens.border}`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Palette className={`w-4 h-4 ${tokens.accentText}`} />
                <h3 className="font-display text-xl tracking-tight">Theme Mode & System Auto-Switch</h3>
              </div>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Select between the architectural Dark ambiance, editorial Dawn cream canvas, or enable automatic system synchronization.
              </p>
            </div>

            {/* Live Auto-Switch Pill */}
            <div className="flex items-center gap-2 shrink-0">
              <span
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-mono border transition-all ${
                  isAutoTheme
                    ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30 shadow-xs'
                    : 'bg-stone-500/15 text-stone-400 border-stone-500/30'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${isAutoTheme ? 'bg-emerald-400 animate-pulse' : 'bg-stone-400'}`} />
                {isAutoTheme ? (
                  <span>Auto-Sync: {systemTheme === 'dark' ? 'Dark' : 'Dawn'}</span>
                ) : (
                  <span>Manual: {theme === 'dark' ? 'Dark' : 'Dawn'}</span>
                )}
              </span>
            </div>
          </div>

          {/* Dedicated matchMedia Auto-Switch Toggle Card */}
          <div
            className={`p-4 sm:p-5 rounded-2xl border transition-all ${tokens.surfaceElevated} ${
              isAutoTheme
                ? theme === 'dark'
                  ? 'border-emerald-500/40 bg-emerald-950/15 ring-1 ring-emerald-500/20'
                  : 'border-emerald-600/40 bg-emerald-50/50 ring-1 ring-emerald-600/20'
                : tokens.border
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start sm:items-center gap-3.5">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                    isAutoTheme
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : `${tokens.accentBgTint} ${tokens.accentText}`
                  }`}
                >
                  <Monitor className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold text-sm">Auto-Switch with System Preferences</h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-stone-500/10 text-stone-400 border border-stone-500/20">
                      matchMedia
                    </span>
                  </div>
                  <p className={`text-xs mt-0.5 ${tokens.textSecondary} leading-relaxed`}>
                    Listens to browser <code className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-stone-500/15 text-stone-300">matchMedia('(prefers-color-scheme: dark)')</code> to automatically switch between Dark and Dawn modes in real time when your OS appearance changes.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 self-end sm:self-center shrink-0">
                <button
                  type="button"
                  id="btn-toggle-auto-theme"
                  onClick={() => {
                    haptics.selection();
                    setAutoTheme(!isAutoTheme);
                  }}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    isAutoTheme ? 'bg-emerald-500' : 'bg-stone-600/50'
                  }`}
                  role="switch"
                  aria-checked={isAutoTheme}
                  title={isAutoTheme ? 'Click to disable auto-switch' : 'Click to enable auto-switch'}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                      isAutoTheme ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Live Media Query Diagnostic Bar */}
            <div className="mt-3.5 pt-3 border-t border-inherit flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono">
              <div className="flex items-center gap-2 text-stone-400">
                <span className="text-stone-500">Browser matchMedia:</span>
                <span className="flex items-center gap-1.5 font-semibold text-stone-300">
                  {systemTheme === 'dark' ? (
                    <>
                      <Moon className="w-3.5 h-3.5 text-amber-300" />
                      <span>(prefers-color-scheme: dark) matches: true</span>
                    </>
                  ) : (
                    <>
                      <Sun className="w-3.5 h-3.5 text-amber-500" />
                      <span>(prefers-color-scheme: dark) matches: false</span>
                    </>
                  )}
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <span
                  className={`px-2 py-0.5 rounded-md border text-[10px] ${
                    isAutoTheme
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                      : 'bg-stone-500/10 border-stone-500/20 text-stone-400'
                  }`}
                >
                  {isAutoTheme
                    ? `Synced to OS (${systemTheme === 'dark' ? 'Dark' : 'Dawn'})`
                    : `Manual Override (${theme === 'dark' ? 'Dark' : 'Dawn'})`}
                </span>
              </div>
            </div>
          </div>

          {/* Three Selection Cards: Auto (System), Dark Mode, Dawn Mode */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Auto (System Sync) Card */}
            <div
              id="theme-card-auto-system"
              onClick={() => {
                haptics.selection();
                setPreference('system');
              }}
              className={`p-5 rounded-2xl border-2 cursor-pointer transition-all ${
                isAutoTheme
                  ? theme === 'dark'
                    ? 'border-emerald-500/80 ring-2 ring-emerald-500/20 bg-emerald-950/20'
                    : 'border-emerald-600/80 ring-2 ring-emerald-600/20 bg-emerald-50/70'
                  : `border-transparent ${tokens.surfaceElevated} hover:border-stone-500/30`
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 font-medium text-sm">
                  <Monitor className="w-4 h-4 text-emerald-400" />
                  <span className={tokens.textPrimary}>Auto (System)</span>
                </div>
                {isAutoTheme && (
                  <span className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </span>
                )}
              </div>

              {/* Dual-Split Preview Swatch */}
              <div className="p-3.5 rounded-xl bg-stone-500/10 border border-stone-500/20 space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono text-stone-400">
                  <span>OS Match</span>
                  <span className="font-semibold text-emerald-400">
                    {systemTheme === 'dark' ? '→ Dark' : '→ Dawn'}
                  </span>
                </div>
                <div className="flex h-2 rounded-full overflow-hidden border border-stone-500/20">
                  <div className="w-1/2 bg-[#0b0c0e]" title="Dark Mode" />
                  <div className="w-1/2 bg-[#ece7de]" title="Dawn Mode" />
                </div>
                <div className="flex items-center justify-between text-[10px] font-mono text-stone-400">
                  <span>#0b0c0e</span>
                  <span>#ece7de</span>
                </div>
              </div>

              <p className={`text-[11px] mt-3 ${tokens.textSecondary} leading-relaxed`}>
                Automatically follows your device OS settings. Currently detected: <strong className="text-stone-300">{systemTheme === 'dark' ? 'Dark' : 'Dawn'}</strong>.
              </p>
            </div>

            {/* Dark Mode Card */}
            <div
              id="theme-card-dark"
              onClick={() => {
                haptics.selection();
                setPreference('dark');
              }}
              className={`p-5 rounded-2xl border-2 cursor-pointer transition-all ${
                !isAutoTheme && theme === 'dark'
                  ? 'border-white/80 ring-2 ring-white/20 bg-[#121418]'
                  : 'border-transparent bg-[#121418]/60 hover:bg-[#121418]'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-white font-medium text-sm">
                  <Moon className="w-4 h-4 text-amber-300" />
                  <span>Dark Mode</span>
                </div>
                {!isAutoTheme && theme === 'dark' && (
                  <span className="w-5 h-5 rounded-full bg-white text-black flex items-center justify-center">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </span>
                )}
              </div>

              {/* Visual preview swatch */}
              <div className="p-3.5 rounded-xl bg-[#0b0c0e] border border-[#22252a] space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono text-[#a6a29a]">
                  <span>Canvas: #0b0c0e</span>
                  <span className="text-[#efe8dc]">Accent: #efe8dc</span>
                </div>
                <div className="h-2 rounded-full bg-[#1b1e24] w-3/4" />
                <div className="h-2 rounded-full bg-[#efe8dc]/40 w-1/2" />
              </div>

              <p className="text-[11px] text-[#a6a29a] mt-3 leading-relaxed">
                Almost-black background (#0b0c0e), off-white text (#f4f1ea), and muted warm-beige primary accent.
              </p>
            </div>

            {/* Dawn (Light) Mode Card */}
            <div
              id="theme-card-dawn"
              onClick={() => {
                haptics.selection();
                setPreference('dawn');
              }}
              className={`p-5 rounded-2xl border-2 cursor-pointer transition-all ${
                !isAutoTheme && theme === 'dawn'
                  ? 'border-stone-800 ring-2 ring-stone-800/20 bg-[#f7f4ed]'
                  : 'border-transparent bg-[#f7f4ed]/70 hover:bg-[#f7f4ed]'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-[#1b1a17] font-medium text-sm">
                  <Sun className="w-4 h-4 text-amber-600" />
                  <span>Dawn Mode (Light)</span>
                </div>
                {!isAutoTheme && theme === 'dawn' && (
                  <span className="w-5 h-5 rounded-full bg-[#1b1a17] text-white flex items-center justify-center">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </span>
                )}
              </div>

              {/* Visual preview swatch */}
              <div className="p-3.5 rounded-xl bg-[#ece7de] border border-[#d6cfc0] space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono text-[#5e5a52]">
                  <span>Canvas: #ece7de</span>
                  <span className="text-[#1b1a17]">Text: #1b1a17</span>
                </div>
                <div className="h-2 rounded-full bg-[#ded7cb] w-3/4" />
                <div className="h-2 rounded-full bg-[#1b1a17]/40 w-1/2" />
              </div>

              <p className="text-[11px] text-[#5e5a52] mt-3 leading-relaxed">
                Cream background (#ece7de), dark high-contrast text (#1b1a17), and warm architectural neutrals.
              </p>
            </div>
          </div>
        </div>

        {/* Accent Color Options */}
        <div className={`p-6 sm:p-8 rounded-[24px] space-y-6 ${tokens.surface} ${tokens.border}`}>
          <div>
            <h3 className="font-display text-xl tracking-tight">Accent Palette Option</h3>
            <p className={`text-xs ${tokens.textSecondary}`}>
              Switch between Sage (earthy botanical green) and Ocean (atmospheric coastal blue-grey).
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Sage Accent */}
            <div
              onClick={() => setAccent('sage')}
              className={`p-5 rounded-2xl border-2 cursor-pointer transition-all ${
                accent === 'sage'
                  ? 'border-[#6c9377] bg-[#6c9377]/10'
                  : `border-inherit ${tokens.surfaceHover}`
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-4 h-4 rounded-full bg-[#6c9377] ring-2 ring-white/20 shadow-sm" />
                  <span className="font-semibold text-sm">Sage (Green)</span>
                </div>
                {accent === 'sage' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#6c9377] text-white">
                    Active Accent
                  </span>
                )}
              </div>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Organic botanical green reflecting natural travertine gardens, courtyard foliage, and understated equilibrium.
              </p>
              <div className="mt-4 flex gap-2">
                <span className="px-3 py-1 rounded-lg text-xs font-semibold bg-[#6c9377] text-white">
                  Primary Button
                </span>
                <span className="px-3 py-1 rounded-lg text-xs font-medium bg-[#6c9377]/20 text-[#6c9377] border border-[#6c9377]/30">
                  Pill Badge
                </span>
              </div>
            </div>

            {/* Ocean Accent */}
            <div
              onClick={() => setAccent('ocean')}
              className={`p-5 rounded-2xl border-2 cursor-pointer transition-all ${
                accent === 'ocean'
                  ? 'border-[#5a8196] bg-[#5a8196]/10'
                  : `border-inherit ${tokens.surfaceHover}`
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-4 h-4 rounded-full bg-[#5a8196] ring-2 ring-white/20 shadow-sm" />
                  <span className="font-semibold text-sm">Ocean (Blue-Grey)</span>
                </div>
                {accent === 'ocean' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#5a8196] text-white">
                    Active Accent
                  </span>
                )}
              </div>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Atmospheric alpine mist and Nordic lake blue-grey conveying precision engineering and architectural composure.
              </p>
              <div className="mt-4 flex gap-2">
                <span className="px-3 py-1 rounded-lg text-xs font-semibold bg-[#5a8196] text-white">
                  Primary Button
                </span>
                <span className="px-3 py-1 rounded-lg text-xs font-medium bg-[#5a8196]/20 text-[#5a8196] border border-[#5a8196]/30">
                  Pill Badge
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Semantic Color System Reference */}
        <div className={`p-6 sm:p-8 rounded-[24px] space-y-4 ${tokens.surface} ${tokens.border}`}>
          <div>
            <h3 className="font-display text-xl tracking-tight">Semantic Status Indicators</h3>
            <p className={`text-xs ${tokens.textSecondary}`}>
              Standardized operational cues throughout task tracking, budget warnings, and milestones
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-xl border border-[#588c67]/30 bg-[#588c67]/10 flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-[#588c67]" />
              <div>
                <div className="text-xs font-semibold text-[#588c67]">Success</div>
                <div className="text-[10px] font-mono text-stone-400">Green-ish (#588c67)</div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl border border-[#c59b4e]/30 bg-[#c59b4e]/10 flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-[#c59b4e]" />
              <div>
                <div className="text-xs font-semibold text-[#c59b4e]">Warning</div>
                <div className="text-[10px] font-mono text-stone-400">Tan / Gold (#c59b4e)</div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl border border-[#c85642]/30 bg-[#c85642]/10 flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-[#c85642]" />
              <div>
                <div className="text-xs font-semibold text-[#c85642]">Danger</div>
                <div className="text-[10px] font-mono text-stone-400">Terracotta-Red (#c85642)</div>
              </div>
            </div>
          </div>
        </div>

        {/* Typography Showcase */}
        <div className={`p-6 sm:p-8 rounded-[24px] space-y-4 ${tokens.surface} ${tokens.border}`}>
          <div className="flex items-center gap-2 mb-1">
            <Type className={`w-4 h-4 ${tokens.accentText}`} />
            <h3 className="font-display text-xl tracking-tight">Google Typography Hierarchy</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className={`p-4 rounded-xl border ${tokens.surfaceElevated} ${tokens.border}`}>
              <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block mb-1">
                Display & Headings
              </span>
              <div className="font-display text-2xl tracking-tight">Instrument Serif</div>
              <p className={`text-xs mt-2 italic font-serif ${tokens.textSecondary}`}>
                “Architecture is the learned game, correct and magnificent, of forms assembled in the light.”
              </p>
            </div>

            <div className={`p-4 rounded-xl border ${tokens.surfaceElevated} ${tokens.border}`}>
              <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block mb-1">
                Body & Interface
              </span>
              <div className="font-medium text-base">Plus Jakarta Sans</div>
              <p className={`text-xs mt-2 font-sans ${tokens.textSecondary}`}>
                Engineered for dense UI legibility, precision metrics, and tabular financial summaries.
              </p>
            </div>
          </div>
        </div>

        {/* Status Indicators Legend */}
        <div className={`p-6 sm:p-8 rounded-[24px] space-y-6 ${tokens.surface} ${tokens.border}`}>
          <div>
            <h3 className="font-display text-xl tracking-tight mb-1">Status Color Legend</h3>
            <p className={`text-xs ${tokens.textSecondary}`}>
              Reference for the colored status indicators used across client and project lists.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Client Statuses */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider mb-2 border-b pb-2 border-slate-200 dark:border-white/10">
                Client Statuses
              </h4>
              {clientStatusConfig.map((conf) => (
                <div key={conf.status} className="flex items-start gap-3">
                  <div className={`w-3.5 h-3.5 rounded-full mt-0.5 shrink-0 shadow-sm ${conf.colorClass}`} />
                  <div>
                    <div className="text-sm font-semibold">{conf.label}</div>
                    <div className={`text-[11px] leading-relaxed ${tokens.textSecondary}`}>{conf.description}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Project Statuses */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider mb-2 border-b pb-2 border-slate-200 dark:border-white/10">
                Project Statuses
              </h4>
              {projectStatusConfig.map((conf) => (
                <div key={conf.status} className="flex items-start gap-3">
                  <div className={`w-3.5 h-3.5 rounded-full mt-0.5 shrink-0 shadow-sm ${conf.colorClass}`} />
                  <div>
                    <div className="text-sm font-semibold">{conf.label}</div>
                    <div className={`text-[11px] leading-relaxed ${tokens.textSecondary}`}>{conf.description}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
      )}

      {/* SUB-TAB 2: Voice & Hardware Calibration */}
      {activeSettingsTab === 'voice' && (
      <div className="space-y-6 ">
        <div className={`p-6 sm:p-8 rounded-[24px] space-y-4 ${tokens.surface} ${tokens.border}`}>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Mic className={`w-4 h-4 ${tokens.accentText}`} />
                <h3 className="font-display text-xl tracking-tight">Voice Recorder Hardware Test</h3>
              </div>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Verify browser microphone permissions and audio stream fidelity
              </p>
            </div>

            <button
              type="button"
              onClick={testMicrophone}
              disabled={testMicState === 'testing'}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 ${tokens.accentBtn}`}
            >
              {testMicState === 'testing' ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Checking Mic...</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Test Hardware</span>
                </>
              )}
            </button>
          </div>

          {micFeedback && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                testMicState === 'success'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
              }`}
            >
              <span>{micFeedback}</span>
            </div>
          )}
        </div>
      </div>
      )}

      {/* SUB-TAB 3: Better-Auth Security */}
      {activeSettingsTab === 'account' && (
      <div className="space-y-6 ">
        <div className={`p-6 sm:p-8 rounded-[24px] space-y-4 ${tokens.surface} ${tokens.border}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${tokens.accentBgTint} ${tokens.accentText}`}>
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-[10px] uppercase tracking-wider text-stone-400">
                    better-auth
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                </div>
                <h3 className="font-display text-xl tracking-tight">Active Studio Authentication</h3>
              </div>
            </div>

            <button
              type="button"
              onClick={openAuthModal}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold border ${tokens.border} hover:${tokens.surfaceHover}`}
            >
              Switch Account
            </button>
          </div>

          {user && (
            <div className={`p-4 rounded-xl border flex items-center justify-between gap-4 ${tokens.surfaceElevated} ${tokens.border}`}>
              <div className="flex items-center gap-3">
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-10 h-10 rounded-full object-cover border"
                />
                <div>
                  <div className="font-semibold text-xs">{user.name}</div>
                  <div className={`text-[11px] ${tokens.textSecondary}`}>{user.role} · {user.email}</div>
                </div>
              </div>

              <button
                type="button"
                onClick={logout}
                className="text-xs text-stone-400 hover:text-red-400 font-mono"
              >
                Sign Out
              </button>
            </div>
          )}
        </div>

        <div className="pt-4">
          <span className={`text-xs font-mono uppercase tracking-widest block mb-4 ${tokens.textMuted}`}>
            Data & Network
          </span>
          <div className="space-y-3">
            <button
              onClick={toggleOfflineMode}
              className={`w-full flex items-center justify-between p-4 rounded-[20px] transition-colors border ${isOfflineMode ? 'bg-rose-500/10 border-rose-500/30' : tokens.surfaceElevated + ' ' + tokens.border} hover:${tokens.surfaceHover}`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isOfflineMode ? 'bg-rose-500/20' : theme === 'dark' ? 'bg-emerald-500/10' : 'bg-emerald-100'}`}>
                  {isOfflineMode ? (
                    <WifiOff className="w-4 h-4 text-rose-500" />
                  ) : (
                    <Wifi className={`w-4 h-4 ${theme === 'dark' ? 'text-emerald-500' : 'text-emerald-600'}`} />
                  )}
                </div>
                <div className="text-left">
                  <div className="text-sm font-semibold">{isOfflineMode ? 'Offline Mode Active' : 'Online Mode'}</div>
                  <div className={`text-xs ${isOfflineMode ? 'text-rose-400' : tokens.textSecondary}`}>
                    {isOfflineMode ? 'Viewing cached data. Sync paused.' : 'Connected and syncing in real-time.'}
                  </div>
                </div>
              </div>
              <div className={`w-10 h-6 rounded-full p-1 transition-colors ${isOfflineMode ? 'bg-rose-500' : tokens.surfaceHover}`}>
                <div className={`w-4 h-4 rounded-full bg-white transition-transform ${isOfflineMode ? 'translate-x-4' : 'translate-x-0'}`} />
              </div>
            </button>

            <button
              onClick={simulateSyncConflict}
              className={`w-full flex items-center justify-between p-4 rounded-[20px] transition-colors border ${tokens.surfaceElevated} hover:${tokens.surfaceHover} ${tokens.border}`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${theme === 'dark' ? 'bg-amber-500/10' : 'bg-amber-100'}`}>
                  <RefreshCw className={`w-4 h-4 ${theme === 'dark' ? 'text-amber-500' : 'text-amber-600'}`} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-semibold">Simulate Sync Conflict</div>
                  <div className={`text-xs ${tokens.textSecondary}`}>Test the conflict resolution UI</div>
                </div>
              </div>
            </button>
          </div>
        </div>

      </div>
      )}

      {/* SUB-TAB 4: Lock, Backup & Portability */}
      {activeSettingsTab === 'lock' && (
        <div className="space-y-6">
          {/* Status Banner */}
          <div className={`p-6 rounded-[24px] border ${tokens.surface} ${tokens.border} space-y-4`}>
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                  <Lock className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-display text-xl tracking-tight font-bold">Project Architecture: Locked & Protected</h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      SECURE
                    </span>
                  </div>
                  <p className={`text-xs mt-1 ${tokens.textSecondary}`}>
                    Core branding, executive themes, font stacks, and database schema are locked against arbitrary drift when zipping or importing to other tools.
                  </p>
                </div>
              </div>
            </div>

            {/* Architecture Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2">
              <div className="p-3 rounded-xl bg-black/20 border border-white/5 space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400">Master Brand</span>
                <div className="text-xs font-bold text-amber-400">SIYARAM CRM</div>
                <div className="text-[10px] text-stone-500">Real Estate Executive</div>
              </div>
              <div className="p-3 rounded-xl bg-black/20 border border-white/5 space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400">Ambiance Mode</span>
                <div className="text-xs font-bold text-emerald-400">Architectural Dark</div>
                <div className="text-[10px] text-stone-500">Auto-drift prevented</div>
              </div>
              <div className="p-3 rounded-xl bg-black/20 border border-white/5 space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400">Audio Synth</span>
                <div className="text-xs font-bold text-blue-400">100% Standalone</div>
                <div className="text-[10px] text-stone-500">Web Audio chime fallback</div>
              </div>
              <div className="p-3 rounded-xl bg-black/20 border border-white/5 space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400">Data Schema</span>
                <div className="text-xs font-bold text-purple-400">Self-Hydrating</div>
                <div className="text-[10px] text-stone-500">Local storage validated</div>
              </div>
            </div>
          </div>

          {/* Backup & Portability Actions */}
          <div className={`p-6 rounded-[24px] border ${tokens.surface} ${tokens.border} space-y-5`}>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Database className="w-4 h-4 text-amber-400" />
                <h3 className="font-display text-lg tracking-tight font-bold">Data Portability & Safe Export</h3>
              </div>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Save your client interactions, call records, follow-ups, and project inventory to a portable JSON file or restore from a previous backup.
              </p>
            </div>

            {backupMessage && (
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2 text-xs text-amber-300">
                <FileCheck className="w-4 h-4 shrink-0 text-amber-400" />
                <span>{backupMessage}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* 1. Export JSON */}
              <button
                type="button"
                onClick={() => {
                  haptics.medium();
                  exportDataBackup();
                  setBackupMessage('Full CRM database exported safely to your downloads.');
                  setTimeout(() => setBackupMessage(null), 5000);
                }}
                className={`p-4 rounded-2xl border flex flex-col items-start justify-between gap-3 text-left transition-all cursor-pointer ${tokens.border} ${tokens.surfaceHover}`}
              >
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Download className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold">Export Backup</div>
                  <div className="text-[10px] text-stone-400 mt-0.5">Download full state as JSON</div>
                </div>
              </button>

              {/* 2. Import JSON */}
              <label
                className={`p-4 rounded-2xl border flex flex-col items-start justify-between gap-3 text-left transition-all cursor-pointer ${tokens.border} ${tokens.surfaceHover}`}
              >
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Upload className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold">Restore Backup</div>
                  <div className="text-[10px] text-stone-400 mt-0.5">Select a CRM backup file</div>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".json,application/json"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      const content = event.target?.result as string;
                      if (content) {
                        const success = importDataBackup(content);
                        if (success) {
                          setBackupMessage('Backup successfully restored! Data is updated.');
                        } else {
                          setBackupMessage('Error: Invalid CRM backup file format.');
                        }
                        setTimeout(() => setBackupMessage(null), 5000);
                      }
                    };
                    reader.readAsText(file);
                    e.target.value = '';
                  }}
                />
              </label>

              {/* 3. Reset to Master Siyaram Estate Data */}
              <button
                type="button"
                onClick={() => setResetModalOpen(true)}
                className="p-4 rounded-2xl border border-rose-500/30 bg-rose-500/5 hover:bg-rose-500/10 flex flex-col items-start justify-between gap-3 text-left transition-all cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center">
                  <RotateCcw className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-rose-300">Restore Master Data</div>
                  <div className="text-[10px] text-stone-400 mt-0.5">Repopulate core real estate inventory</div>
                </div>
              </button>
            </div>
          </div>

          {/* Reset Confirmation Modal */}
          {resetModalOpen && (
            <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/40 space-y-3">
              <div className="flex items-center gap-2 text-rose-300 font-bold text-sm">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <span>Confirm Master Data Repopulation</span>
              </div>
              <p className="text-xs text-stone-300">
                This will reset your clients, plots, and follow-ups back to the pristine master Siyaram Real Estate state. Any unsaved custom records will be overwritten.
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    haptics.success();
                    resetToMasterData();
                    setResetModalOpen(false);
                    setBackupMessage('Master Siyaram Real Estate dataset restored!');
                    setTimeout(() => setBackupMessage(null), 5000);
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white transition-all cursor-pointer"
                >
                  Yes, Restore Master State
                </button>
                <button
                  type="button"
                  onClick={() => setResetModalOpen(false)}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-medium text-stone-400 hover:text-stone-200 border border-white/10 transition-all cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
