import { motion } from 'motion/react';
import React, { useState } from 'react';
import { FolderOpen, FolderPlus, Briefcase, Plus, Search, Filter, Users, Calendar, DollarSign, ArrowRight, CheckCircle2, Clock, X, Tag as TagIcon, MoreVertical, Sparkles, Phone, MessageSquare } from 'lucide-react';
import { EmptyStatePlaceholder } from '../components/EmptyStatePlaceholder';

import { Project, ProjectStatus, Client } from '../types';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { EditFollowUpModal } from '../components/EditFollowUpModal';
import { QuickCommModal } from '../components/QuickCommModal';
import { CardContextMenuModal } from '../components/CardContextMenuModal';
import { ProjectHealthCard } from '../components/ProjectHealthCard';
import { useLongPress } from '../utils/useLongPress';
import { getProjectStatusColor } from '../utils/status';
import { haptics } from '../utils/haptics';

interface ProjectsViewProps {
  onSelectProject: (id: string) => void;
  onSelectClient: (id: string) => void;
  onOpenVoiceRecorder?: (clientId?: string, projectId?: string) => void;
  searchQuery: string;
}

interface ProjectCardItemProps {
  project: Project;
  tokens: any;
  onSelectProject: (id: string) => void;
  onSelectClient: (id: string) => void;
  onOpenContextMenu: (project: Project) => void;
}

const ProjectCardItem: React.FC<ProjectCardItemProps> = ({
  project,
  tokens,
  onSelectProject,
  onSelectClient,
  onOpenContextMenu,
}) => {
  const { clients, tags } = useData();
  const [isPressing, setIsPressing] = useState(false);

  const longPressProps = useLongPress(
    () => {
      setIsPressing(false);
      onOpenContextMenu(project);
    },
    () => {
      onSelectProject(project.id);
    },
    {
      threshold: 420,
      onStart: () => setIsPressing(true),
      onCancel: () => setIsPressing(false),
      onFinish: () => setIsPressing(false),
    }
  );

  const linkedClients = project.clientIds
    .map((cId) => clients.find((c) => c.id === cId))
    .filter(Boolean) as Client[];

  const projectTags = project.tagIds
    .map((tId) => tags.find((t) => t.id === tId))
    .filter(Boolean);

  const completedMilestones = project.milestones.filter((m) => m.completed).length;
  const progressPct =
    project.milestones.length > 0
      ? Math.round((completedMilestones / project.milestones.length) * 100)
      : 0;

  const card3D = `${tokens.surface} ${tokens.border} ${tokens.surfaceHover}`;

  return (
    <motion.div
      key={project.id}
      {...longPressProps}
      className={`p-4 sm:p-5 rounded-[20px] flex flex-col justify-between select-none cursor-pointer transition-all duration-150 relative ${
        isPressing
          ? 'scale-[0.98] ring-2 ring-blue-500/60 shadow-inner'
          : 'hover:translate-y-[-2px]'
      } ${card3D}`}
    >
      <div>
        {/* Meta header */}
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded bg-stone-500/15 text-stone-400">
              {project.code}
            </span>
            <span
              className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full font-medium ${
                project.status === 'active'
                  ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  : project.status === 'in_review'
                  ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                  : project.status === 'planning'
                  ? 'bg-blue-500/15 text-blue-600 dark:text-blue-400'
                  : 'bg-stone-500/15 text-stone-400'
              }`}
            >
              {project.status.replace('_', ' ')}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-semibold">
              ₹{project.budget.toLocaleString('en-IN')}
            </span>
            <button
              type="button"
              data-prevent-long-press="true"
              onClick={(e) => {
                e.stopPropagation();
                haptics.selection();
                onOpenContextMenu(project);
              }}
              className="p-1 rounded-lg text-stone-400 hover:text-blue-500 hover:bg-blue-500/10 transition-colors cursor-pointer"
              title="Quick Tasks (Long-press card or click)"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Title */}
        <div className="flex items-center gap-2">
          <h3
            onClick={(e) => {
              e.stopPropagation();
              onSelectProject(project.id);
            }}
            className="font-display text-xl tracking-tight cursor-pointer hover:underline"
          >
            {project.title}
          </h3>
          <span 
            className={`w-3 h-3 rounded-full shrink-0 ${getProjectStatusColor(project.status)}`}
            title={`Status: ${project.status}`}
          />
        </div>
        <p className={`text-xs mt-2 line-clamp-2 leading-relaxed ${tokens.textSecondary}`}>
          {project.description}
        </p>

        {/* Tags */}
        {projectTags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-3">
            {projectTags.map((tag) => (
              <span
                key={tag!.id}
                className="text-[10px] font-mono px-2 py-0.5 rounded-md border"
                style={{
                  borderColor: `${tag!.color}40`,
                  backgroundColor: `${tag!.color}15`,
                  color: tag!.color,
                }}
              >
                {tag!.name}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Linked Clients Box */}
      <div className="mt-6 pt-4 border-t border-inherit">
        <div className="flex items-center justify-between mb-2">
          <span className={`text-[11px] font-mono uppercase tracking-wider ${tokens.textMuted}`}>
            Linked Clients ({linkedClients.length})
          </span>
          <span className="text-[11px] font-mono text-stone-400">
            {completedMilestones}/{project.milestones.length} Milestones
          </span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center -space-x-2">
              {linkedClients.map((client) => (
                <img
                  key={client.id}
                  src={client.avatar}
                  alt={client.name}
                  data-prevent-long-press="true"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectClient(client.id);
                  }}
                  title={`${client.name} — ${client.role} at ${client.company}`}
                  className="w-7 h-7 rounded-full object-cover border-2 border-[#0b0c0e] cursor-pointer hover:scale-110 transition-transform"
                />
              ))}
            </div>
            <div className="text-xs">
              {linkedClients.length > 0 ? (
                <span className="font-medium truncate block max-w-[160px]">
                  {linkedClients[0].name}
                  {linkedClients.length > 1 && ` +${linkedClients.length - 1} more`}
                </span>
              ) : (
                <span className="text-stone-400 italic text-[11px]">No client linked</span>
              )}
            </div>
          </div>

          <button
            type="button"
            data-prevent-long-press="true"
            onClick={(e) => {
              e.stopPropagation();
              onSelectProject(project.id);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors ${tokens.accentBgTint} ${tokens.accentText}`}
          >
            <span>View Dossier</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  onSelectProject,
  onSelectClient,
  onOpenVoiceRecorder,
  searchQuery,
}) => {
  const { theme, tokens, accent } = useTheme();
  const { projects, clients, tags, addProject } = useData();

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [nestedViewTab, setNestedViewTab] = useState<'grid' | 'stakeholders' | 'milestones'>('grid');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Contextual Menu & Quick Task Modals
  const [contextProject, setContextProject] = useState<Project | null>(null);
  const [isFollowUpModalOpen, setIsFollowUpModalOpen] = useState(false);
  const [followUpClientId, setFollowUpClientId] = useState<string | undefined>();
  const [followUpProjectId, setFollowUpProjectId] = useState<string | undefined>();
  const [isQuickCommOpen, setIsQuickCommOpen] = useState(false);
  const [quickCommClientId, setQuickCommClientId] = useState<string | undefined>();
  const [quickCommProjectId, setQuickCommProjectId] = useState<string | undefined>();
  const [quickCommChannel, setQuickCommChannel] = useState<'call' | 'whatsapp'>('call');

  // New Project Form State
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newBudget, setNewBudget] = useState(150000);
  const [newStartDate, setNewStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [newTargetDate, setNewTargetDate] = useState('2026-12-31');
  const [newSelectedClients, setNewSelectedClients] = useState<string[]>([]);
  const [newSelectedTags, setNewSelectedTags] = useState<string[]>([]);
  const [newDeliverableInput, setNewDeliverableInput] = useState('');
  const [newDeliverables, setNewDeliverables] = useState<string[]>([
    'Schematic Design Documentation',
    'Material & Finish Palette Schedules'
  ]);

  // Filter projects
  const filteredProjects = projects.filter((p) => {
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'pending'
        ? p.status === 'planning' || p.status === 'in_review'
        : p.status === statusFilter;
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !query ||
      p.title.toLowerCase().includes(query) ||
      p.code.toLowerCase().includes(query) ||
      p.description.toLowerCase().includes(query) ||
      (p.location || '').toLowerCase().includes(query) ||
      (p.keyFeatures || []).some((feature) => feature.toLowerCase().includes(query)) ||
      (p.contacts || []).some((contact) => `${contact.name} ${contact.role || ''} ${contact.phone}`.toLowerCase().includes(query));
    return matchesStatus && matchesSearch;
  });

  const handleAddDeliverable = () => {
    if (newDeliverableInput.trim()) {
      setNewDeliverables([...newDeliverables, newDeliverableInput.trim()]);
      setNewDeliverableInput('');
    }
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const created = addProject({
      title: newTitle.trim(),
      description: newDescription.trim() || 'Custom architectural and design commission.',
      status: 'active',
      budget: Number(newBudget),
      startDate: newStartDate,
      targetDate: newTargetDate,
      clientIds: newSelectedClients,
      tagIds: newSelectedTags,
      milestones: [
        { id: `m-${Date.now()}-1`, title: 'Conceptual Briefing & Site Survey', completed: true, dueDate: newStartDate },
        { id: `m-${Date.now()}-2`, title: 'Detailed Design Submittal', completed: false, dueDate: newTargetDate }
      ],
      deliverables: newDeliverables,
    });

    setIsCreateModalOpen(false);
    onSelectProject(created.id);
  };

  const toggleClientSelection = (clientId: string) => {
    setNewSelectedClients((prev) =>
      prev.includes(clientId) ? prev.filter((id) => id !== clientId) : [...prev, clientId]
    );
  };

  const toggleTagSelection = (tagId: string) => {
    setNewSelectedTags((prev) =>
      prev.includes(tagId) ? prev.filter((id) => id !== tagId) : [...prev, tagId]
    );
  };

  return (
    <div className="space-y-4 ">
      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-2 border-b border-inherit">
        <div>
          <span className={`text-[11px] font-mono tracking-widest uppercase ${tokens.textMuted}`}>
            Portfolio Management
          </span>
          <h2 className="font-display text-xl tracking-tight mt-0.5">
            Active Projects & Architectural Commissions
          </h2>
          <p className={`text-xs ${tokens.textSecondary}`}>
            Showing {filteredProjects.length} commissions with linked client dossiers
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsCreateModalOpen(true)}
          className={`px-4 py-2.5 rounded-xl font-medium text-xs tracking-wider uppercase flex items-center gap-2 transition-all shrink-0 ${tokens.accentBtn}`}
        >
          <Plus className="w-4 h-4" />
          <span>New Project</span>
        </button>
      </div>

      {/* PROJECT HEALTH SUMMARY CARD (Uses Recharts) */}
      <ProjectHealthCard
        projects={projects}
        activeFilter={statusFilter}
        onFilterChange={setStatusFilter}
      />

      {/* PRIMARY TAB LEVEL: Status Filter */}
      <div className="space-y-3">
        <div className="p-1 rounded-2xl bg-stone-500/10 border border-inherit flex flex-wrap items-center gap-1">
          {[
            { id: 'all', label: 'All Portfolios' },
            { id: 'active', label: 'Live Sites' },
            { id: 'in_review', label: 'In Review' },
            { id: 'planning', label: 'Planning' },
            { id: 'completed', label: 'Completed' },
          ].map((tab) => {
            const active = statusFilter === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setStatusFilter(tab.id)}
                className={`flex-1 min-w-[100px] py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  active
                    ? theme === 'dark'
                      ? 'tactile-pill-active-dark scale-[1.01]'
                      : 'tactile-pill-active-dawn scale-[1.01]'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary} hover:bg-stone-500/10`
                }`}
              >
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* NESTED SECONDARY SUB-TABS: (Tab ke andar Tab!) */}
        <div className="flex items-center justify-between gap-2 pt-1">
          <div className="flex items-center gap-2">
            {[
              { id: 'grid', label: 'Overview Grid' },
              { id: 'stakeholders', label: 'Clients & Stakeholders' },
              { id: 'milestones', label: 'Phasing & Milestones' },
            ].map((sub) => (
              <button
                key={sub.id}
                type="button"
                onClick={() => setNestedViewTab(sub.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                  nestedViewTab === sub.id
                    ? theme === 'dark'
                      ? 'bg-[#f4f1ea] text-[#0b0c0e] font-semibold shadow-sm'
                      : 'bg-[#1b1a17] text-[#ece7de] font-semibold shadow-sm'
                    : `${tokens.surfaceElevated} ${tokens.textSecondary} border ${tokens.border} hover:${tokens.textPrimary}`
                }`}
              >
                {sub.label}
              </button>
            ))}
          </div>

          <span className="text-xs font-mono text-stone-400">
            {filteredProjects.length} projects
          </span>
        </div>
      </div>

      {/* Projects Grid with 3D tactile styling */}
      
      {filteredProjects.length === 0 ? (
        <EmptyStatePlaceholder
          icon={FolderOpen}
          title="No projects found"
          description="You don't have any projects or architectural commissions matching this criteria. Get started by creating a new one."
          actionLabel="Add New Project"
          ActionIcon={FolderPlus}
          onAction={() => setIsCreateModalOpen(true)}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredProjects.map((project) => (
            <ProjectCardItem
              key={project.id}
              project={project}
              tokens={tokens}
              onSelectProject={onSelectProject}
              onSelectClient={onSelectClient}
              onOpenContextMenu={(p) => setContextProject(p)}
            />
          ))}
        </div>
      )}

      {/* New Project Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs ">
          <div
            className={`relative w-full max-w-xl rounded-2xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] ${tokens.surface} ${tokens.border}`}
          >
            <div className={`px-6 py-4 border-b flex items-center justify-between ${tokens.border} ${tokens.bgSubtle}`}>
              <h3 className="font-display text-xl tracking-tight">Initiate New Project Commission</h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className={`p-1.5 rounded-lg ${tokens.textMuted} hover:${tokens.textPrimary}`}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateProject} className="p-6 overflow-y-auto space-y-4">
              <div>
                <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                  Project Title *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Kyoto Minimalist Tea Pavilion"
                  className={`w-full px-3.5 py-2 rounded-xl text-xs border focus:outline-none ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                />
              </div>

              <div>
                <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                  Architectural Brief & Scope
                </label>
                <textarea
                  rows={3}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Describe spatial footprint, materiality, aesthetic targets..."
                  className={`w-full px-3.5 py-2 rounded-xl text-xs border focus:outline-none ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                    Budget (€)
                  </label>
                  <input
                    type="number"
                    value={newBudget}
                    onChange={(e) => setNewBudget(Number(e.target.value))}
                    className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                  />
                </div>

                <div>
                  <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={newStartDate}
                    onChange={(e) => setNewStartDate(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                  />
                </div>

                <div>
                  <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                    Target Handover
                  </label>
                  <input
                    type="date"
                    value={newTargetDate}
                    onChange={(e) => setNewTargetDate(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl text-xs border focus:outline-none ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                  />
                </div>
              </div>

              {/* Select Clients to Link */}
              <div>
                <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 flex items-center justify-between ${tokens.textSecondary}`}>
                  <span>Link Clients to this Project</span>
                  <span className="font-mono text-[10px] text-stone-400">
                    {newSelectedClients.length} Selected
                  </span>
                </label>
                <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto p-1">
                  {clients.map((c) => {
                    const isSelected = newSelectedClients.includes(c.id);
                    return (
                      <div
                        key={c.id}
                        onClick={() => toggleClientSelection(c.id)}
                        className={`p-2 rounded-xl border flex items-center gap-2 cursor-pointer text-xs transition-all ${
                          isSelected
                            ? `${tokens.accentBgTint} ${tokens.accentBorder} font-medium`
                            : `${tokens.surfaceElevated} ${tokens.border} hover:${tokens.surfaceHover}`
                        }`}
                      >
                        <img src={c.avatar} alt={c.name} className="w-6 h-6 rounded-full object-cover" />
                        <div className="truncate text-[11px] leading-tight">
                          <div>{c.name}</div>
                          <div className="text-[10px] text-stone-400 truncate">{c.company}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Select Tags */}
              <div>
                <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                  Assign Tags
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {tags.map((t) => {
                    const isSelected = newSelectedTags.includes(t.id);
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => toggleTagSelection(t.id)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all border ${
                          isSelected
                            ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300 font-bold'
                            : 'border-stone-500/30 text-stone-400 hover:text-stone-200'
                        }`}
                      >
                        #{t.name}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="pt-3 border-t border-inherit flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className={`px-4 py-2 text-xs font-medium ${tokens.textSecondary} hover:${tokens.textPrimary}`}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-xs font-semibold tracking-wider uppercase ${tokens.accentBtn}`}
                >
                  Create Project Commission
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Contextual Long-Press Menu for Rapid Tasks (Call, Message, Add Follow-up) */}
      <CardContextMenuModal
        isOpen={Boolean(contextProject)}
        onClose={() => setContextProject(null)}
        type="project"
        project={contextProject}
        linkedClients={
          contextProject
            ? (contextProject.clientIds
                .map((id) => clients.find((c) => c.id === id))
                .filter(Boolean) as Client[])
            : []
        }
        onSelectProject={onSelectProject}
        onSelectClient={onSelectClient}
        onOpenFollowUp={(clientId, projectId) => {
          setFollowUpClientId(clientId);
          setFollowUpProjectId(projectId || contextProject?.id);
          setIsFollowUpModalOpen(true);
        }}
        onOpenVoiceRecorder={onOpenVoiceRecorder}
        onOpenQuickComm={(clientId, projectId, channel) => {
          setQuickCommClientId(clientId);
          setQuickCommProjectId(projectId || contextProject?.id);
          setQuickCommChannel(channel || 'call');
          setIsQuickCommOpen(true);
        }}
      />

      {/* Rapid Add Follow-Up Modal */}
      <EditFollowUpModal
        isOpen={isFollowUpModalOpen}
        onClose={() => setIsFollowUpModalOpen(false)}
        initialClientId={followUpClientId}
        initialProjectId={followUpProjectId}
      />

      {/* Quick Communication Modal */}
      <QuickCommModal
        isOpen={isQuickCommOpen}
        onClose={() => setIsQuickCommOpen(false)}
        initialClientId={quickCommClientId}
        initialProjectId={quickCommProjectId}
        initialChannel={quickCommChannel}
        onOpenVoiceRecorder={onOpenVoiceRecorder}
      />
    </div>
  );
};
