import { motion, AnimatePresence } from 'motion/react';
import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Phone,
  Mail,
  Briefcase,
  CalendarClock,
  Mic,
  Star,
  Trash2,
  ExternalLink,
  CheckCircle2,
  Clock,
  Building,
  Plus,
  X,
  MessageSquare,
  Send,
  Edit,
  Copy,
  FileText,
  Filter,
  Check,
  MapPin,
  Calendar
} from 'lucide-react';
import { Client, Project, VoiceRecording, CommChannel, CommLog } from '../types';
import { useTheme } from '../context/ThemeContext';
import { haptics } from '../utils/haptics';
import { useData } from '../context/DataContext';
import { QuickCommModal } from '../components/QuickCommModal';
import { EditClientModal } from '../components/EditClientModal';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { ExpandableVoiceRecordingItem } from '../components/ExpandableVoiceRecordingItem';
import { startCellularCall } from '../utils/nativeBridge';

interface ClientDetailViewProps {
  clientId: string;
  onBack: () => void;
  onSelectProject: (projectId: string) => void;
  onOpenVoiceRecorder: (clientId?: string, projectId?: string) => void;
  onSaveAndNextClient: (clientId: string) => void;
}

export const ClientDetailView: React.FC<ClientDetailViewProps> = ({
  clientId,
  onBack,
  onSelectProject,
  onOpenVoiceRecorder,
  onSaveAndNextClient,
}) => {
  const { theme, tokens, accent } = useTheme();
  const {
    getClientById,
    projects,
    followUps,
    recordings,
    tags,
    commLogs,
    addCommLog,
    deleteClient,
    toggleFollowUpStatus,
    clearClientActivityLogs,
    updateClient,
    addFollowUp,
  } = useData();

  const [activityFilter, setActivityFilter] = useState<'all' | 'call' | 'note' | 'recording' | 'whatsapp' | 'sms'>('all');
  const [isCommModalOpen, setIsCommModalOpen] = useState(false);
  const [isDeleteClientConfirmOpen, setIsDeleteClientConfirmOpen] = useState(false);
  const [isClearLogConfirmOpen, setIsClearLogConfirmOpen] = useState(false);
  const [commInitialChannel, setCommInitialChannel] = useState<CommChannel>('whatsapp');
  const [isEditClientModalOpen, setIsEditClientModalOpen] = useState(false);
  
  const [isLoggingCall, setIsLoggingCall] = useState(false);
  const [callNote, setCallNote] = useState('');
  const [quickRemindDays, setQuickRemindDays] = useState<number | null>(null);
  const [customFollowUpDate, setCustomFollowUpDate] = useState('');
  const [callStartedAt, setCallStartedAt] = useState<number | null>(null);
  const [callDurationSeconds, setCallDurationSeconds] = useState(0);
  const [callNextAction, setCallNextAction] = useState<'call' | 'whatsapp' | 'meeting'>('call');

  // Copy to clipboard state & toast feedback
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [toast, setToast] = useState<{ show: boolean; text: string; label?: string } | null>(null);

  const copyToClipboard = async (text: string, label: string = 'Phone Number') => {
    if (!text) return;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
    } catch {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.opacity = '0';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
    }

    haptics.selection();
    setCopiedText(text);
    setToast({ show: true, text, label });

    setTimeout(() => {
      setCopiedText((prev) => (prev === text ? null : prev));
    }, 2000);

    setTimeout(() => {
      setToast((prev) => (prev?.text === text ? null : prev));
    }, 2600);
  };

  
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    setIsLoading(true);
    const t = setTimeout(() => setIsLoading(false), 500);
    return () => clearTimeout(t);
  }, [clientId]);

  const client = getClientById(clientId);


  if (isLoading) {
    return (
      <div className="flex flex-col lg:flex-row gap-6  h-full">
        {/* Sidebar Skeleton */}
        <div className="w-full lg:w-80 shrink-0 space-y-6">
          <div className="w-24 h-6 bg-stone-500/10 rounded animate-pulse" />
          <div className={`flex flex-col items-center text-center p-6 rounded-3xl border ${tokens.border} bg-stone-500/5`}>
            <div className="w-24 h-24 bg-stone-500/10 rounded-full animate-pulse mb-4" />
            <div className="w-40 h-8 bg-stone-500/10 rounded-lg animate-pulse mb-2" />
            <div className="w-24 h-5 bg-stone-500/10 rounded-lg animate-pulse mb-4" />
            <div className="w-full flex gap-2 justify-center">
              <div className="w-10 h-10 bg-stone-500/10 rounded-full animate-pulse" />
              <div className="w-10 h-10 bg-stone-500/10 rounded-full animate-pulse" />
              <div className="w-10 h-10 bg-stone-500/10 rounded-full animate-pulse" />
            </div>
          </div>
          <div className={`p-6 rounded-3xl border ${tokens.border} bg-stone-500/5 space-y-4`}>
            <div className="w-32 h-5 bg-stone-500/10 rounded animate-pulse" />
            <div className="w-full h-10 bg-stone-500/10 rounded-xl animate-pulse" />
            <div className="w-full h-10 bg-stone-500/10 rounded-xl animate-pulse" />
          </div>
        </div>
        
        {/* Main Content Skeleton */}
        <div className="flex-1 space-y-6 min-w-0">
          <div className="p-1 rounded-2xl bg-stone-500/5 flex gap-1 overflow-hidden">
            {[1,2,3,4].map(i => <div key={i} className="flex-1 h-10 bg-stone-500/10 rounded-xl animate-pulse" />)}
          </div>
          <div className={`p-6 rounded-[28px] border space-y-6 ${tokens.surface} ${tokens.border}`}>
             <div className="flex justify-between items-center">
                <div className="space-y-2">
                  <div className="w-48 h-8 bg-stone-500/10 rounded-lg animate-pulse" />
                  <div className="w-64 h-4 bg-stone-500/10 rounded animate-pulse" />
                </div>
                <div className="w-32 h-9 bg-stone-500/10 rounded-xl animate-pulse" />
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               {[1,2,3,4].map(i => <div key={i} className="h-32 bg-stone-500/10 rounded-xl animate-pulse" />)}
             </div>
          </div>
        </div>
      </div>
    );
  }

  if (!client) {
    return (
      <div className="p-8 text-center space-y-4">
        <p className="text-stone-400">Client record not found.</p>
        <button
          onClick={onBack}
          className={`px-4 py-2 rounded-xl text-xs font-semibold ${tokens.accentBtn}`}
        >
          Return to Clients
        </button>
      </div>
    );
  }

  // Linked projects
  const clientProjects = projects.filter((p) => p.clientIds.includes(client.id));

  // Client follow-ups
  const clientFollowUps = followUps.filter((f) => f.clientId === client.id);

  // Client voice recordings
  const clientRecordings = recordings.filter(
    (r) => r.clientId === client.id || client.voiceRecordingIds.includes(r.id)
  );

  // Client communication & activity logs
  const unifiedActivityLogs = [
    ...commLogs
      .filter((log) => log.clientId === client.id)
      .map((log) => ({ type: 'comm', data: log, timestamp: log.timestamp, id: log.id })),
    ...clientRecordings.map((rec) => ({
      type: 'recording',
      data: rec,
      timestamp: rec.createdAt,
      id: rec.id,
    })),
  ]
    .filter((item) => {
      if (activityFilter === 'all') return true;
      if (activityFilter === 'recording') return item.type === 'recording';
      if (item.type === 'comm') return item.data.channel === activityFilter;
      return false;
    })
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  // Client tags
  const clientTags = client.tagIds
    .map((tId) => tags.find((t) => t.id === tId))
    .filter(Boolean);

  const isVIP = client.status === 'vip';

  const handleOpenWhatsAppDirect = () => {
    const num = (client.whatsappNumber || client.phone || '').replace(/[^0-9]/g, '');
    if (!num) {
      setIsCommModalOpen(true);
      setCommInitialChannel('whatsapp');
      return;
    }
    const defaultMsg = encodeURIComponent(
      `Namaste ${client.name.split(' ')[0]}, this is regarding the Siyaram project updates.`
    );
    window.open(`https://wa.me/${num}?text=${defaultMsg}`, '_blank', 'noopener,noreferrer');
  };

  const handleDialDirect = () => {
    const num = client.phone || client.whatsappNumber || '';
    if (num) {
      const result = startCellularCall(num);
      if (result === 'launched') {
        setCallStartedAt(Date.now());
        setIsLoggingCall(true);
      }
    } else {
      setIsCommModalOpen(true);
      setCommInitialChannel('call');
    }
  };

    const handleSaveQuickCallNote = () => {
    if (!callNote.trim()) return;

    addCommLog({
      channel: 'call',
      clientId: client.id,
      phoneNumber: client.phone || client.whatsappNumber || '',
      direction: 'outgoing',
      notes: callNote.trim(),
      status: 'completed',
      durationSeconds: callDurationSeconds,
      timestamp: new Date().toISOString()
    });

    if (quickRemindDays !== null || customFollowUpDate) {
      const followUpDate = new Date();
      if (customFollowUpDate) {
        followUpDate.setTime(new Date(customFollowUpDate + 'T12:00:00').getTime());
      } else {
        followUpDate.setDate(followUpDate.getDate() + (quickRemindDays || 1));
      }
      const followUpDateStr = followUpDate.toISOString().split('T')[0];
      const followUpType = callNextAction === 'whatsapp' ? 'whatsapp' : callNextAction === 'meeting' ? 'meeting' : 'call';

      updateClient(client.id, {
        nextFollowUpDate: followUpDateStr,
        nextFollowUpNote: callNote.trim(),
        nextFollowUpType: followUpType
      });

      addFollowUp({
        title: `Follow up: ${client.name}`,
        clientId: client.id,
        type: followUpType,
        priority: (quickRemindDays === 1 || customFollowUpDate === new Date().toISOString().split('T')[0]) ? 'high' : 'medium',
        dueDate: followUpDateStr,
        notes: callNote.trim()
      });
    }

    setCallNote('');
    setQuickRemindDays(null);
    setCustomFollowUpDate('');
    setCallDurationSeconds(0);
    setCallNextAction('call');
    setIsLoggingCall(false);
    onSaveAndNextClient(client.id);
  };

  useEffect(() => {
    if (!callStartedAt) return;
    const handleReturnFromCall = () => {
      if (document.visibilityState !== 'visible') return;
      const elapsedSeconds = Math.max(1, Math.round((Date.now() - callStartedAt) / 1000));
      setCallDurationSeconds(elapsedSeconds);
      setCallNote((prev) => prev);
      setIsLoggingCall(true);
      setCallStartedAt(null);
    };
    const handleVisibility = () => setTimeout(handleReturnFromCall, 250);
    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('focus', handleReturnFromCall);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('focus', handleReturnFromCall);
    };
  }, [callStartedAt]);

  return (
    <div className="space-y-8 ">
      {/* Top Navigation & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-inherit">
        <button
          type="button"
          onClick={onBack}
          className={`flex items-center gap-2 text-xs font-mono transition-colors ${tokens.textSecondary} hover:${tokens.textPrimary}`}
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Clients</span>
        </button>

        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Communication Trigger */}
          <button
            type="button"
            onClick={() => {
              setCommInitialChannel('whatsapp');
              setIsCommModalOpen(true);
            }}
            className="px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs transition-all cursor-pointer"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>WhatsApp / SMS / Call</span>
          </button>

          {/* Copy Phone to Clipboard */}
          {(client.phone || client.whatsappNumber) && (
            <button
              type="button"
              id="btn-copy-client-phone-header"
              onClick={() => copyToClipboard(client.phone || client.whatsappNumber!, 'Client Phone')}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition-all cursor-pointer ${tokens.surfaceElevated} ${tokens.border} hover:${tokens.textPrimary} hover:border-emerald-500/40`}
              title="Copy phone number to clipboard"
            >
              {copiedText === (client.phone || client.whatsappNumber) ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />
                  <span className="text-emerald-400 font-bold">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-stone-400" />
                  <span>Copy Phone</span>
                </>
              )}
            </button>
          )}

          {/* Edit Client Button */}
          <button
            type="button"
            onClick={() => setIsEditClientModalOpen(true)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition-all ${tokens.surfaceElevated} ${tokens.border} hover:${tokens.textPrimary}`}
          >
            <Edit className="w-3.5 h-3.5 text-stone-400" />
            <span>Edit Profile & Number</span>
          </button>

          {/* Voice Record Memo/Call */}
          <button
            type="button"
            onClick={() => onOpenVoiceRecorder(client.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${tokens.accentBtn}`}
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Record Voice Note</span>
          </button>

          {/* Delete Client */}
          <button
            type="button"
            onClick={() => setIsDeleteClientConfirmOpen(true)}
            className="p-2 rounded-xl border border-stone-500/20 text-stone-400 hover:text-[#c85642] hover:border-[#c85642]/40 transition-colors"
            title="Delete Client"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Client Profile Card */}
      <motion.div
        layoutId={`client-card-${client.id}`}
        transition={{
          type: 'spring',
          stiffness: 550,
          damping: 38,
          mass: 0.35,
        }}
        className={`p-6 sm:p-8 rounded-2xl border ${tokens.surface} ${tokens.border}`}
      >
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
            <div className="relative">
              <img
                src={client.avatar}
                alt={client.name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover border-2 border-stone-500/30"
              />
              {isVIP && (
                <span className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-[#c59b4e] flex items-center justify-center text-white ring-2 ring-[#0b0c0e]">
                  <Star className="w-3.5 h-3.5 fill-current" />
                </span>
              )}
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <span
                  className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full font-medium ${
                    client.status === 'vip'
                      ? 'bg-[#c59b4e]/20 text-[#c59b4e]'
                      : 'bg-emerald-500/15 text-emerald-500'
                  }`}
                >
                  {client.status} Partner
                </span>

                {clientTags.map((tag) => (
                  <span
                    key={tag!.id}
                    className="text-[10px] font-mono px-2 py-0.5 rounded border"
                    style={{
                      borderColor: `${tag!.color}40`,
                      backgroundColor: `${tag!.color}15`,
                      color: tag!.color,
                    }}
                  >
                    #{tag!.name}
                  </span>
                ))}
              </div>

              <h1 className="font-display text-3xl sm:text-4xl tracking-tight leading-none">
                {client.name}
              </h1>
              <p className={`text-sm mt-1 ${tokens.textSecondary}`}>{client.role}</p>

              <div className="flex flex-wrap items-center gap-3 mt-1.5 text-xs font-mono">
                <span className="text-stone-400 flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5" />
                  <span>{client.company}</span>
                </span>

                {client.location && (
                  <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold px-2 py-0.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                    <MapPin className="w-3 h-3 text-rose-500" />
                    <span>{client.location}</span>
                  </span>
                )}

                {client.phone && (
                  <button
                    type="button"
                    onClick={() => copyToClipboard(client.phone, 'Phone')}
                    className="inline-flex items-center gap-1.5 text-slate-600 dark:text-stone-300 hover:text-emerald-600 dark:hover:text-emerald-400 px-2.5 py-1 rounded-lg bg-stone-500/10 hover:bg-emerald-500/10 border border-stone-500/20 hover:border-emerald-500/30 transition-all cursor-pointer group"
                    title="Click to copy phone number to clipboard"
                  >
                    <Phone className="w-3 h-3 text-slate-400 group-hover:text-emerald-500 transition-colors" />
                    <span className="font-mono">{client.phone}</span>
                    {copiedText === client.phone ? (
                      <span className="inline-flex items-center gap-0.5 text-[10px] text-emerald-400 font-bold bg-emerald-500/20 px-1.5 py-0.5 rounded ml-0.5">
                        <Check className="w-2.5 h-2.5 stroke-[3]" />
                        <span>Copied!</span>
                      </span>
                    ) : (
                      <Copy className="w-3 h-3 text-stone-400 opacity-60 group-hover:opacity-100 group-hover:text-emerald-400 transition-opacity ml-0.5" />
                    )}
                  </button>
                )}

                {client.whatsappNumber && client.whatsappNumber !== client.phone && (
                  <button
                    type="button"
                    onClick={() => copyToClipboard(client.whatsappNumber!, 'WhatsApp')}
                    className="inline-flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 px-2.5 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/25 hover:border-emerald-500/40 transition-all cursor-pointer group"
                    title="Click to copy WhatsApp number to clipboard"
                  >
                    <MessageSquare className="w-3 h-3 text-emerald-500" />
                    <span className="font-mono">{client.whatsappNumber}</span>
                    {copiedText === client.whatsappNumber ? (
                      <span className="inline-flex items-center gap-0.5 text-[10px] text-emerald-400 font-bold bg-emerald-500/20 px-1.5 py-0.5 rounded ml-0.5">
                        <Check className="w-2.5 h-2.5 stroke-[3]" />
                        <span>Copied!</span>
                      </span>
                    ) : (
                      <Copy className="w-3 h-3 text-emerald-500/70 group-hover:text-emerald-400 transition-opacity ml-0.5" />
                    )}
                  </button>
                )}
              </div>

              {/* Sales qualification snapshot */}
              {(client.budget || client.requirement || client.leadSource) && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3 max-w-3xl">
                  {client.budget && <div className={`px-3 py-2 rounded-xl border ${tokens.border} ${tokens.surfaceElevated}`}><div className={`text-[9px] uppercase tracking-wider ${tokens.textMuted}`}>Budget</div><div className="text-xs font-semibold mt-0.5">{client.budget}</div></div>}
                  {client.requirement && <div className={`px-3 py-2 rounded-xl border ${tokens.border} ${tokens.surfaceElevated}`}><div className={`text-[9px] uppercase tracking-wider ${tokens.textMuted}`}>Requirement</div><div className="text-xs font-semibold mt-0.5">{client.requirement}</div></div>}
                  {client.leadSource && <div className={`px-3 py-2 rounded-xl border ${tokens.border} ${tokens.surfaceElevated}`}><div className={`text-[9px] uppercase tracking-wider ${tokens.textMuted}`}>Lead Source</div><div className="text-xs font-semibold mt-0.5">{client.leadSource}</div></div>}
                </div>
              )}

              {/* Next Scheduled Follow-Up status pill */}
              {client.nextFollowUpDate && (
                <div className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-xs text-amber-700 dark:text-amber-400 font-mono">
                  <Calendar className="w-3.5 h-3.5 text-amber-500" />
                  <span className="font-bold">Next Follow-Up:</span>
                  <span>{client.nextFollowUpDate}</span>
                  {client.nextFollowUpTime && <span>at {client.nextFollowUpTime}</span>}
                  {client.nextFollowUpNote && (
                    <span className="hidden sm:inline italic text-slate-600 dark:text-stone-300 font-sans truncate max-w-xs">
                      — "{client.nextFollowUpNote}"
                    </span>
                  )}
                </div>
              )}
              {/* Last Interaction Block */}
              {unifiedActivityLogs.length > 0 && (
                <div className="mt-3 inline-flex flex-col sm:flex-row sm:items-center gap-2 p-2.5 rounded-xl bg-stone-500/10 border border-stone-500/20 text-xs text-stone-300">
                  <div className="flex items-center gap-1.5 shrink-0">
                    <div className="w-6 h-6 rounded-full bg-stone-500/20 flex items-center justify-center shrink-0">
                      {unifiedActivityLogs[0].type === 'recording' ? (
                        <Mic className="w-3.5 h-3.5 text-blue-400" />
                      ) : unifiedActivityLogs[0].type === 'comm' && unifiedActivityLogs[0].data.channel === 'whatsapp' ? (
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                      ) : unifiedActivityLogs[0].type === 'comm' && unifiedActivityLogs[0].data.channel === 'call' ? (
                        <Phone className="w-3.5 h-3.5 text-amber-400" />
                      ) : (
                        <FileText className="w-3.5 h-3.5 text-stone-400" />
                      )}
                    </div>
                    <span className="font-bold text-[10px] font-mono uppercase tracking-wider text-stone-400">Last Interaction:</span>
                  </div>
                  <span className="truncate max-w-sm font-sans font-medium">
                    {unifiedActivityLogs[0].type === 'recording' 
                      ? (unifiedActivityLogs[0].data.title || 'Voice Note Recorded')
                      : (unifiedActivityLogs[0].data.notes || `${unifiedActivityLogs[0].data.direction === 'outgoing' ? 'Sent' : 'Received'} ${unifiedActivityLogs[0].data.channel} message`)}
                  </span>
                  <span className="text-[10px] text-stone-500 shrink-0 font-mono ml-auto">
                    {new Date(unifiedActivityLogs[0].timestamp).toLocaleDateString()}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Quick Communication Hub Box */}
          <div className="w-full lg:w-auto p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/5 flex flex-col gap-2.5 text-xs font-mono">
            <div className="flex items-center justify-between gap-4">
              <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Manchaha WhatsApp</span>
              </span>
              <button
                type="button"
                onClick={() => setIsEditClientModalOpen(true)}
                className="text-[10px] text-stone-400 hover:text-white underline cursor-pointer"
              >
                Change Number
              </button>
            </div>

            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 min-w-0">
                <span className="font-mono text-sm font-semibold text-stone-200 truncate">
                  {client.whatsappNumber || client.phone || 'No WhatsApp set'}
                </span>
                {(client.whatsappNumber || client.phone) && (
                  <button
                    type="button"
                    id="btn-copy-comm-number"
                    onClick={() => copyToClipboard(client.whatsappNumber || client.phone, 'Contact Number')}
                    className="px-2 py-1 rounded-md bg-stone-500/20 hover:bg-emerald-500/20 text-stone-300 hover:text-emerald-400 border border-stone-500/30 hover:border-emerald-500/40 transition-all flex items-center gap-1 cursor-pointer shrink-0"
                    title="Copy phone number to clipboard"
                  >
                    {copiedText === (client.whatsappNumber || client.phone) ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400 stroke-[3]" />
                        <span className="text-[10px] font-bold text-emerald-400 font-mono">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span className="text-[10px] font-mono">Copy</span>
                      </>
                    )}
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={handleOpenWhatsAppDirect}
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
              >
                <span>Open Chat</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>

            <div className="flex items-center gap-2 pt-1 border-t border-emerald-500/20 text-[11px] text-stone-300">
              <button
                type="button"
                onClick={handleDialDirect}
                className="flex-1 py-1 px-2 rounded bg-stone-500/20 hover:bg-stone-500/30 flex items-center justify-center gap-1.5"
              >
                <Phone className="w-3 h-3 text-amber-400" />
                <span>Quick Call</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setCommInitialChannel('sms');
                  setIsCommModalOpen(true);
                }}
                className="flex-1 py-1 px-2 rounded bg-stone-500/20 hover:bg-stone-500/30 flex items-center justify-center gap-1.5"
              >
                <Send className="w-3 h-3 text-blue-400" />
                <span>Send SMS</span>
              </button>
            </div>
            
            {/* INLINE CALL LOGGING FORM */}
            {isLoggingCall && (
              <div className={`fixed inset-x-3 bottom-3 sm:inset-auto sm:top-1/2 sm:left-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2 sm:w-[min(520px,calc(100vw-32px))] z-[80] p-4 rounded-3xl ${tokens.surface} ${tokens.border} border shadow-2xl backdrop-blur-2xl space-y-3 animate-in fade-in slide-in-from-bottom-3`}>
                <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-to-br from-blue-500/10 via-violet-500/10 to-transparent" />
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 font-bold flex items-center gap-1">
                    <Phone className="w-3 h-3" /> Call Completed
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsLoggingCall(false);
                        onOpenVoiceRecorder(client.id);
                      }}
                      className="text-[10px] font-mono uppercase font-bold text-blue-400 hover:bg-blue-500/20 px-2 py-1 rounded bg-blue-500/10 flex items-center gap-1"
                    >
                      <Mic className="w-3 h-3" /> Record Audio
                    </button>
                    <button type="button" onClick={() => setIsLoggingCall(false)} className="text-stone-400 hover:text-white ml-1">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <div className={`rounded-2xl px-3 py-2 ${tokens.bgSubtle} flex items-center justify-between`}>
                  <div><div className={`text-[10px] uppercase tracking-wider font-bold ${tokens.textMuted}`}>Call duration</div><div className="text-lg font-semibold">{Math.floor(callDurationSeconds/60)}:{String(callDurationSeconds%60).padStart(2,'0')}</div></div>
                  <div className="text-right"><div className={`text-[10px] uppercase tracking-wider font-bold ${tokens.textMuted}`}>Next action</div><div className="text-xs font-semibold capitalize">{callNextAction}</div></div>
                </div>
                <textarea
                  autoFocus
                  placeholder="What happened? Add a quick note…"
                  value={callNote}
                  onChange={(e) => setCallNote(e.target.value)}
                  className="w-full bg-black/40 border border-emerald-500/30 rounded-lg p-2 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-emerald-500 resize-none h-16 font-sans"
                />
                <div className="grid grid-cols-3 gap-2">
                  {[['call','Call'],['whatsapp','WhatsApp'],['meeting','Site Visit']].map(([value,label]) => (
                    <button key={value} type="button" onClick={() => setCallNextAction(value as typeof callNextAction)} className={`py-2 rounded-xl border text-[10px] font-semibold ${callNextAction === value ? 'bg-blue-500/15 border-blue-400/50 text-blue-300' : `${tokens.border} ${tokens.textSecondary}`}`}>{label}</button>
                  ))}
                </div>
                <div className="flex items-center gap-2 mt-2 flex-wrap">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500">Next follow-up:</span>
                  {[
                    { label: 'Tomorrow', days: 1 },
                    { label: '3 Days', days: 3 },
                    { label: '7 Days', days: 7 },
                    { label: '15 Days', days: 15 },
                  ].map(opt => (
                    <button
                      key={opt.days}
                      type="button"
                      onClick={() => setQuickRemindDays(quickRemindDays === opt.days ? null : opt.days)}
                      className={`px-2 py-1 rounded border text-[10px] font-semibold transition-colors ${
                        quickRemindDays === opt.days 
                          ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                          : 'bg-transparent border-stone-500/30 text-stone-400 hover:bg-stone-500/10'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                  <label className={`px-2 py-1 rounded border text-[10px] font-semibold cursor-pointer ${customFollowUpDate ? 'bg-violet-500/20 border-violet-500/50 text-violet-300' : 'bg-transparent border-stone-500/30 text-stone-400'}`}>
                    Custom
                    <input
                      type="date"
                      value={customFollowUpDate}
                      onChange={(e) => { setCustomFollowUpDate(e.target.value); setQuickRemindDays(null); }}
                      className="sr-only"
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </label>
                </div>
                <div className="flex justify-end">
                  <button
                    type="button"
                    disabled={!callNote.trim()}
                    onClick={handleSaveQuickCallNote}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-[11px] transition-colors"
                  >
                    Save & Next
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Briefing notes */}
        <div className="mt-6 pt-6 border-t border-inherit">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-xs font-mono uppercase tracking-wider text-stone-400">
              Client Requirements, Sensibilities & Siyaram Preferences
            </h4>
            <button
              type="button"
              onClick={() => setIsEditClientModalOpen(true)}
              className="text-[10px] text-amber-400 hover:underline flex items-center gap-1 font-mono"
            >
              <Edit className="w-3 h-3" /> Edit Notes
            </button>
          </div>
          <p className={`text-xs sm:text-sm leading-relaxed ${tokens.textSecondary}`}>
            {client.notes || 'No confidential briefing notes added yet.'}
          </p>
        </div>
      </motion.div>

      {/* UNIFIED COMMUNICATION LOG: Calls, WhatsApp, SMS */}
      <div className={`p-6 rounded-2xl border space-y-4 ${tokens.surface} ${tokens.border}`}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-display text-2xl tracking-tight">
                Unified Communication Log
              </h3>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 font-semibold">
                Calls · WhatsApp · SMS · Notes · Recordings
              </span>
            </div>
            <p className={`text-xs mt-0.5 ${tokens.textSecondary}`}>
              Centralized timeline of all telephone calls, text messages, quick notes, and voice recordings
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter Tabs */}
            <div className={`p-1 rounded-xl border flex items-center gap-1 text-[11px] font-mono flex-wrap ${tokens.surfaceElevated} ${tokens.border}`}>
              <button
                type="button"
                onClick={() => setActivityFilter('all')}
                className={`px-2.5 py-1 rounded-lg transition-all ${
                  activityFilter === 'all'
                    ? `${tokens.accentBtn} font-bold`
                    : `${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                All ({commLogs.filter((l) => l.clientId === client.id).length + clientRecordings.length})
              </button>
              <button
                type="button"
                onClick={() => setActivityFilter('call')}
                className={`px-2.5 py-1 rounded-lg flex items-center gap-1 transition-all ${
                  activityFilter === 'call'
                    ? 'bg-amber-500/25 text-amber-400 font-bold'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                <Phone className="w-3 h-3" />
                <span>Calls</span>
              </button>
              <button
                type="button"
                onClick={() => setActivityFilter('note')}
                className={`px-2.5 py-1 rounded-lg flex items-center gap-1 transition-all ${
                  activityFilter === 'note'
                    ? 'bg-emerald-500/25 text-emerald-400 font-bold'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                <Edit className="w-3 h-3" />
                <span>Notes</span>
              </button>
              <button
                type="button"
                onClick={() => setActivityFilter('recording')}
                className={`px-2.5 py-1 rounded-lg flex items-center gap-1 transition-all ${
                  activityFilter === 'recording'
                    ? 'bg-purple-500/25 text-purple-400 font-bold'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                <Mic className="w-3 h-3" />
                <span>Recordings</span>
              </button>
              <button
                type="button"
                onClick={() => setActivityFilter('whatsapp')}
                className={`px-2.5 py-1 rounded-lg flex items-center gap-1 transition-all ${
                  activityFilter === 'whatsapp'
                    ? 'bg-emerald-500/25 text-emerald-400 font-bold'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                <MessageSquare className="w-3 h-3" />
                <span>WhatsApp</span>
              </button>
              <button
                type="button"
                onClick={() => setActivityFilter('sms')}
                className={`px-2.5 py-1 rounded-lg flex items-center gap-1 transition-all ${
                  activityFilter === 'sms'
                    ? 'bg-blue-500/25 text-blue-400 font-bold'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary}`
                }`}
              >
                <Send className="w-3 h-3" />
                <span>SMS</span>
              </button>
            </div>
            <button
              type="button"
              onClick={() => {
                setCommInitialChannel('whatsapp');
                setIsCommModalOpen(true);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 ${tokens.accentBtn}`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Send / Log</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenVoiceRecorder(client.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-colors bg-purple-500/20 text-purple-400 hover:bg-purple-500/30`}
            >
              <Mic className="w-3.5 h-3.5" />
              <span>Record Voice Note</span>
            </button>
            {unifiedActivityLogs.length > 0 && (
              <button
                type="button"
                onClick={() => setIsClearLogConfirmOpen(true)}
                className="p-1.5 rounded-xl border border-stone-500/20 text-stone-400 hover:text-red-500 hover:bg-red-500/10 hover:border-red-500/40 transition-colors shrink-0"
                title="Clear Activity Log"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Communication Timeline List */}
        <div className="space-y-3">
          {unifiedActivityLogs.map((item) => {
            if (item.type === 'recording') {
              const rec = item.data;
              const linkedProj = projects.find((p) => p.id === rec.projectId);
              return (
                <ExpandableVoiceRecordingItem
                  key={rec.id}
                  recording={rec}
                  clientName={client.name}
                  projectName={linkedProj?.title}
                  onOpenVoiceRecorder={onOpenVoiceRecorder}
                />
              );
            }

            const log = item.data;
            const isCall = log.channel === 'call';
            const isWhatsApp = log.channel === 'whatsapp';
            const isSMS = log.channel === 'sms';
            const isNote = log.channel === 'note';

            return (
              <div
                key={log.id}
                className={`p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${tokens.surfaceElevated} ${tokens.border}`}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      isWhatsApp
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : isSMS
                        ? 'bg-blue-500/20 text-blue-400 border border-blue-500/40'
                        : isNote ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    }`}
                  >
                    {isWhatsApp && <MessageSquare className="w-4 h-4" />}
                    {isSMS && <Send className="w-4 h-4" />}
                    {isCall && <Phone className="w-4 h-4" />}
                    {isNote && <Edit className="w-4 h-4" />}
                  </div>

                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-bold uppercase tracking-wider font-mono">
                        {log.channel === 'whatsapp'
                          ? 'WhatsApp Message'
                          : log.channel === 'sms'
                          ? 'SMS Text Message'
                          : log.channel === 'note'
                          ? 'Activity Note'
                          : 'Telephone Call'}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-stone-500/15 text-stone-300">
                        {log.direction === 'outgoing' ? 'Outgoing' : 'Incoming'} · {log.status}
                      </span>
                      {log.durationSeconds && (
                        <span className="text-[10px] font-mono text-amber-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {Math.floor(log.durationSeconds / 60)}m {log.durationSeconds % 60}s
                        </span>
                      )}
                    </div>

                    <p className={`text-xs mt-1 ${tokens.textPrimary} leading-relaxed`}>
                      {log.messageBody || log.notes}
                    </p>

                    <div className="flex flex-wrap items-center gap-2.5 mt-1.5 text-[11px] font-mono text-stone-400">
                      <span>{new Date(log.timestamp).toLocaleString()}</span>
                      {log.phoneNumber && (
                        <button
                          type="button"
                          onClick={() => copyToClipboard(log.phoneNumber!, 'Logged Number')}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-stone-500/10 hover:bg-emerald-500/15 text-stone-300 hover:text-emerald-400 border border-stone-500/20 hover:border-emerald-500/30 transition-all cursor-pointer group"
                          title="Copy phone number to clipboard"
                        >
                          <Phone className="w-2.5 h-2.5 text-stone-400 group-hover:text-emerald-400 transition-colors" />
                          <span>{log.phoneNumber}</span>
                          {copiedText === log.phoneNumber ? (
                            <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-0.5 ml-0.5">
                              <Check className="w-2.5 h-2.5 stroke-[3]" /> Copied!
                            </span>
                          ) : (
                            <Copy className="w-2.5 h-2.5 opacity-60 group-hover:opacity-100 transition-opacity ml-0.5" />
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  {isWhatsApp && (
                    <button
                      type="button"
                      onClick={() => {
                        const num = (log.phoneNumber || client.whatsappNumber || '').replace(/[^0-9]/g, '');
                        if (num) window.open(`https://wa.me/${num}`, '_blank');
                      }}
                      className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 border border-emerald-500/40 flex items-center gap-1"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>WhatsApp</span>
                    </button>
                  )}
                  {isCall && (
                    <button
                      type="button"
                      onClick={() => onOpenVoiceRecorder(client.id)}
                      className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 border border-amber-500/40 flex items-center gap-1"
                    >
                      <Mic className="w-3 h-3" />
                      <span>Record Voice Note</span>
                    </button>
                  )}
                  {isNote && (
                    <button
                      type="button"
                      onClick={() => {
                        const text = log.messageBody || log.notes || '';
                        if (text) { copyToClipboard(text, 'Note text'); }
                      }}
                      className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 border border-emerald-500/40 flex items-center gap-1 cursor-pointer"
                      title="Copy to clipboard"
                    >
                      {copiedText === (log.messageBody || log.notes) ? (
                        <>
                          <Check className="w-3 h-3 stroke-[3]" />
                          <span>Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {unifiedActivityLogs.length === 0 && (
            <div className="p-8 text-center text-xs text-stone-400 border border-dashed border-stone-500/20 rounded-xl">
              No communication logs matching current filter. Click "Send / Log" to send a WhatsApp, SMS, or log a call.
            </div>
          )}
        </div>
      </div>

      {/* Grid: Linked Projects & Pending Follow-ups */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Linked Projects (e.g. Siyaram) */}
        <div className={`p-6 rounded-2xl border space-y-4 ${tokens.surface} ${tokens.border}`}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display text-xl tracking-tight">
                Associated Commissions ({clientProjects.length})
              </h3>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Projects (e.g. Siyaram) linked with {client.name.split(' ')[0]}
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {clientProjects.map((project) => (
              <div
                key={project.id}
                onClick={() => onSelectProject(project.id)}
                className={`p-4 rounded-xl border cursor-pointer transition-all hover:translate-y-[-1px] ${tokens.surfaceElevated} ${tokens.border} hover:${tokens.surfaceHover}`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-semibold">
                    {project.code}
                  </span>
                  <span className="text-xs font-mono font-semibold">
                    €{project.budget.toLocaleString()}
                  </span>
                </div>
                <h4 className="font-display text-base tracking-tight hover:underline flex items-center gap-2">
                  <span>{project.title}</span>
                  {project.location && (
                    <span className="text-xs font-mono font-normal text-stone-400">
                      · {project.location}
                    </span>
                  )}
                </h4>
                <p className={`text-xs line-clamp-2 mt-1 ${tokens.textSecondary}`}>
                  {project.description}
                </p>
              </div>
            ))}

            {clientProjects.length === 0 && (
              <div className="p-6 text-center text-xs text-stone-400 border border-dashed border-stone-500/20 rounded-xl">
                No active project commissions linked to this client yet.
              </div>
            )}
          </div>
        </div>

        {/* Pending Follow-ups for this Client */}
        <div className={`p-6 rounded-2xl border space-y-4 ${tokens.surface} ${tokens.border}`}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display text-xl tracking-tight">
                Follow-ups & Scheduled Calls ({clientFollowUps.length})
              </h3>
              <p className={`text-xs ${tokens.textSecondary}`}>
                Upcoming outreach agenda
              </p>
            </div>
          </div>

          <div className="space-y-2.5">
            {clientFollowUps.map((item) => (
              <div
                key={item.id}
                className={`p-3.5 rounded-xl border flex items-start justify-between gap-3 ${tokens.surfaceElevated} ${tokens.border}`}
              >
                <div className="flex items-start gap-2.5 min-w-0">
                  <button
                    type="button"
                    onClick={() => toggleFollowUpStatus(item.id)}
                    className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center transition-colors ${
                      item.status === 'completed'
                        ? 'bg-emerald-500 border-emerald-500 text-white'
                        : 'border-stone-500 hover:border-stone-300'
                    }`}
                  >
                    {item.status === 'completed' && <CheckCircle2 className="w-3 h-3" />}
                  </button>
                  <div>
                    <h5
                      className={`text-xs font-semibold leading-snug ${
                        item.status === 'completed' ? 'line-through text-stone-500' : tokens.textPrimary
                      }`}
                    >
                      {item.title}
                    </h5>
                    <p className={`text-[11px] mt-0.5 ${tokens.textSecondary}`}>{item.notes}</p>
                    <div className="flex items-center gap-2 text-[10px] font-mono text-stone-400 mt-1">
                      <span>Due: {item.dueDate}</span>
                      {item.scheduledTime && <span>· Time: {item.scheduledTime}</span>}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setCommInitialChannel(item.channel || 'call');
                      setIsCommModalOpen(true);
                    }}
                    className={`p-1.5 rounded-lg text-xs flex items-center gap-1 ${
                      item.channel === 'whatsapp'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-amber-500/20 text-amber-400'
                    }`}
                    title="Outreach now"
                  >
                    {item.channel === 'whatsapp' ? <MessageSquare className="w-3.5 h-3.5" /> : <Phone className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenVoiceRecorder(client.id, item.projectId, item.id)}
                    className={`p-1.5 rounded-lg text-xs flex items-center gap-1 ${tokens.accentBgTint} ${tokens.accentText}`}
                    title="Record Voice Note"
                  >
                    <Mic className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}

            {clientFollowUps.length === 0 && (
              <div className="p-6 text-center text-xs text-stone-400 border border-dashed border-stone-500/20 rounded-xl">
                No outstanding follow-ups for {client.name.split(' ')[0]}.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modals */}
      <ConfirmDialog
        isOpen={isDeleteClientConfirmOpen}
        onClose={() => setIsDeleteClientConfirmOpen(false)}
        onConfirm={() => {
          deleteClient(client.id);
          onBack();
        }}
        title="Delete Client Dossier"
        message="Are you sure you want to delete this client? This will also remove all associated projects, communication logs, and voice recordings. This action cannot be undone."
        confirmText="Delete Client"
        isDestructive={true}
      />
      <ConfirmDialog
        isOpen={isClearLogConfirmOpen}
        onClose={() => setIsClearLogConfirmOpen(false)}
        onConfirm={() => clearClientActivityLogs(client.id)}
        title="Clear Activity Log"
        message="Are you sure you want to clear this client's entire activity log? This will permanently delete all call logs, WhatsApp messages, SMS records, quick notes, and voice recordings for this client."
        confirmText="Clear Activity Log"
        isDestructive={true}
      />
      <QuickCommModal
        isOpen={isCommModalOpen}
        onClose={() => setIsCommModalOpen(false)}
        initialClientId={client.id}
        initialChannel={commInitialChannel}
        initialCustomNumber={client.whatsappNumber || client.phone}
        onOpenVoiceRecorder={onOpenVoiceRecorder}
      />

      <EditClientModal
        isOpen={isEditClientModalOpen}
        onClose={() => setIsEditClientModalOpen(false)}
        client={client}
      />

      {/* 'Copied!' Floating Toast Notification */}
      <AnimatePresence>
        {toast?.show && (
          <motion.div
            id="toast-copied-notification"
            initial={{ opacity: 0, y: 35, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 450, damping: 28 }}
            className={`fixed bottom-24 right-4 sm:bottom-8 sm:right-8 z-[150] flex items-center gap-3 px-4 py-3 rounded-2xl border shadow-[0_16px_40px_rgba(0,0,0,0.5)] backdrop-blur-md ${tokens.surfaceElevated} ${tokens.border}`}
          >
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0 text-emerald-400">
              <Check className="w-4 h-4 stroke-[3]" />
            </div>
            <div className="min-w-0 pr-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold font-mono text-emerald-400">Copied!</span>
                <span className={`text-[11px] ${tokens.textSecondary}`}>Copied to clipboard</span>
              </div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <Phone className="w-3 h-3 text-stone-400 shrink-0" />
                <span className={`text-xs font-mono font-semibold truncate max-w-[220px] ${tokens.textPrimary}`}>
                  {toast.text}
                </span>
                {toast.label && (
                  <span className="text-[10px] font-mono text-stone-400">· {toast.label}</span>
                )}
              </div>
            </div>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="p-1 rounded-lg text-stone-400 hover:text-stone-200 transition-colors ml-1"
              title="Dismiss toast"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
