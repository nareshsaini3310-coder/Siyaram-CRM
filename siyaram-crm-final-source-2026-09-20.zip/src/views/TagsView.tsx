import React, { useState } from 'react';
import {
  Tags,
  Plus,
  Trash2,
  Edit3,
  Users,
  Briefcase,
  X,
  Check,
  Search
} from 'lucide-react';
import { Tag } from '../types';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { ConfirmDialog } from '../components/ConfirmDialog';

interface TagsViewProps {
  onSelectClient: (id: string) => void;
  onSelectProject: (id: string) => void;
  searchQuery: string;
}

const PRESET_COLORS = [
  { name: 'Sage Green', hex: '#6c9377' },
  { name: 'Ocean Blue', hex: '#5a8196' },
  { name: 'Terracotta Red', hex: '#c85642' },
  { name: 'Tan Gold', hex: '#c59b4e' },
  { name: 'Editorial Violet', hex: '#8e7dbe' },
  { name: 'Muted Slate', hex: '#78716c' },
];

export const TagsView: React.FC<TagsViewProps> = ({
  onSelectClient,
  onSelectProject,
  searchQuery,
}) => {
  const { theme, tokens, accent } = useTheme();
  const { tags, clients, projects, addTag, updateTag, deleteTag } = useData();

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [tagToDelete, setTagToDelete] = useState<{id: string, name: string} | null>(null);
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState('#6c9377');
  const [newTagDesc, setNewTagDesc] = useState('');
  const [activeFilterTagId, setActiveFilterTagId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'clients' | 'projects'>('all');

  const handleCreateTag = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagName.trim()) return;

    addTag({
      name: newTagName.trim(),
      color: newTagColor,
      description: newTagDesc.trim() || undefined,
    });

    setNewTagName('');
    setNewTagDesc('');
    setIsCreateModalOpen(false);
  };

  const filteredTags = tags.filter((t) => {
    const q = searchQuery.toLowerCase().trim();
    return (
      !q ||
      t.name.toLowerCase().includes(q) ||
      (t.description && t.description.toLowerCase().includes(q))
    );
  });

  // Selected tag items
  const activeTag = tags.find((t) => t.id === activeFilterTagId);
  const taggedClients = activeTag
    ? clients.filter((c) => c.tagIds.includes(activeTag.id))
    : [];
  const taggedProjects = activeTag
    ? projects.filter((p) => p.tagIds.includes(activeTag.id))
    : [];

  return (
    <div className="space-y-8 ">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-2 border-b border-inherit">
        <div>
          <span className={`text-[11px] font-mono tracking-widest uppercase ${tokens.textMuted}`}>
            Taxonomy & Labeling
          </span>
          <h2 className="font-display text-3xl tracking-tight mt-0.5">
            Tags & Organizational Labels
          </h2>
          <p className={`text-xs ${tokens.textSecondary}`}>
            Organize clients, design stages, and project contracts with unified metadata
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsCreateModalOpen(true)}
          className={`px-4 py-2.5 rounded-xl font-medium text-xs tracking-wider uppercase flex items-center gap-2 transition-all shrink-0 ${tokens.accentBtn}`}
        >
          <Plus className="w-4 h-4" />
          <span>New Studio Tag</span>
        </button>
      </div>

      {/* NESTED SUB-TABS (Tab ke andar Tab) */}
      <div className="space-y-4">
        <div className="p-1 rounded-2xl bg-stone-500/10 border border-inherit flex flex-wrap items-center gap-1">
          {[
            { id: 'all', label: `All Labels (${filteredTags.length})`, icon: Tags },
            { id: 'clients', label: 'Clients Taxonomy', icon: Users },
            { id: 'projects', label: 'Projects Taxonomy', icon: Briefcase },
          ].map((tab) => {
            const active = activeTab === tab.id;
            const TabIcon = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  active
                    ? theme === 'dark'
                      ? 'tactile-pill-active-dark scale-[1.01]'
                      : 'tactile-pill-active-dawn scale-[1.01]'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary} hover:bg-stone-500/10`
                }`}
              >
                <TabIcon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tags Grid with 3D tactile styling */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTags.map((tag) => {
          const clientCount = clients.filter((c) => c.tagIds.includes(tag.id)).length;
          const projectCount = projects.filter((p) => p.tagIds.includes(tag.id)).length;
          const isSelected = activeFilterTagId === tag.id;

          // Filter by activeTab if clients or projects tab is selected
          if (activeTab === 'clients' && clientCount === 0) return null;
          if (activeTab === 'projects' && projectCount === 0) return null;

          return (
            <div
              key={tag.id}
              onClick={() => setActiveFilterTagId(isSelected ? null : tag.id)}
              className={`p-5 rounded-[22px] cursor-pointer transition-all duration-200 hover:scale-[1.01] ${
                theme === 'dark' ? 'tactile-card-dark' : 'tactile-card-dawn'
              } ${isSelected ? 'ring-2 ring-stone-400' : ''}`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0 shadow-sm"
                    style={{ backgroundColor: tag.color }}
                  />
                  <h4 className="font-semibold text-sm tracking-tight">{tag.name}</h4>
                </div>

                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setTagToDelete({ id: tag.id, name: tag.name }); }}
                  className="p-1 text-stone-500 hover:text-red-400 transition-colors"
                  title="Delete Tag"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {tag.description && (
                <p className={`text-xs mt-2 ${tokens.textSecondary}`}>{tag.description}</p>
              )}

              {/* Counts */}
              <div className="mt-4 pt-3 border-t border-inherit flex items-center justify-between text-xs text-stone-400 font-mono">
                <div className="flex items-center gap-1.5">
                  <Briefcase className="w-3 h-3" />
                  <span>{projectCount} Projects</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Users className="w-3 h-3" />
                  <span>{clientCount} Clients</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Tag Inspector */}
      {activeTag && (
        <div className={`p-6 rounded-2xl border space-y-6 ${tokens.surfaceElevated} ${tokens.border}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span
                className="w-4 h-4 rounded-full"
                style={{ backgroundColor: activeTag.color }}
              />
              <h3 className="font-display text-2xl tracking-tight">
                Entries Tagged #{activeTag.name}
              </h3>
            </div>
            <button
              onClick={() => setActiveFilterTagId(null)}
              className="text-xs text-stone-400 hover:text-stone-200"
            >
              Clear Filter
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Projects with this tag */}
            <div>
              <h4 className="text-xs font-mono uppercase tracking-wider text-stone-400 mb-3 flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5" />
                <span>Associated Projects ({taggedProjects.length})</span>
              </h4>
              <div className="space-y-2">
                {taggedProjects.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => onSelectProject(p.id)}
                    className={`p-3 rounded-xl border cursor-pointer flex items-center justify-between text-xs ${tokens.surface} ${tokens.border} hover:${tokens.surfaceHover}`}
                  >
                    <div>
                      <span className="font-mono text-[10px] text-stone-400 mr-2">{p.code}</span>
                      <span className="font-medium hover:underline">{p.title}</span>
                    </div>
                    <span className="text-[10px] font-mono text-stone-400 capitalize">{p.status}</span>
                  </div>
                ))}
                {taggedProjects.length === 0 && (
                  <p className="text-xs text-stone-500 italic">No projects under this tag.</p>
                )}
              </div>
            </div>

            {/* Clients with this tag */}
            <div>
              <h4 className="text-xs font-mono uppercase tracking-wider text-stone-400 mb-3 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                <span>Associated Clients ({taggedClients.length})</span>
              </h4>
              <div className="space-y-2">
                {taggedClients.map((c) => (
                  <div
                    key={c.id}
                    onClick={() => onSelectClient(c.id)}
                    className={`p-3 rounded-xl border cursor-pointer flex items-center gap-2.5 text-xs ${tokens.surface} ${tokens.border} hover:${tokens.surfaceHover}`}
                  >
                    <img src={c.avatar} alt={c.name} className="w-6 h-6 rounded-full object-cover" />
                    <div className="min-w-0 flex-1">
                      <div className="font-medium truncate hover:underline">{c.name}</div>
                      <div className="text-[10px] text-stone-400 truncate">{c.company}</div>
                    </div>
                  </div>
                ))}
                {taggedClients.length === 0 && (
                  <p className="text-xs text-stone-500 italic">No clients under this tag.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Tag Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs ">
          <div
            className={`relative w-full max-w-md rounded-2xl border shadow-2xl overflow-hidden flex flex-col ${tokens.surface} ${tokens.border}`}
          >
            <div className={`px-6 py-4 border-b flex items-center justify-between ${tokens.border} ${tokens.bgSubtle}`}>
              <h3 className="font-display text-xl tracking-tight">Create Studio Tag</h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className={`p-1.5 rounded-lg ${tokens.textMuted} hover:${tokens.textPrimary}`}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTag} className="p-6 space-y-4">
              <div>
                <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                  Tag Name *
                </label>
                <input
                  type="text"
                  required
                  value={newTagName}
                  onChange={(e) => setNewTagName(e.target.value)}
                  placeholder="e.g. Bespoke Joinery"
                  className={`w-full px-3.5 py-2 rounded-xl text-xs border focus:outline-none ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                />
              </div>

              <div>
                <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                  Color Swatch
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {PRESET_COLORS.map((color) => (
                    <button
                      key={color.hex}
                      type="button"
                      onClick={() => setNewTagColor(color.hex)}
                      className={`p-2 rounded-xl border flex items-center gap-2 text-xs transition-all ${
                        newTagColor === color.hex
                          ? 'border-white bg-stone-500/20 font-bold'
                          : `${tokens.border} text-stone-400 hover:text-stone-200`
                      }`}
                    >
                      <span
                        className="w-3 h-3 rounded-full shrink-0"
                        style={{ backgroundColor: color.hex }}
                      />
                      <span className="text-[11px] truncate">{color.name.split(' ')[0]}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className={`block text-xs font-semibold uppercase tracking-wider mb-1 ${tokens.textSecondary}`}>
                  Description / Intended Taxonomy
                </label>
                <textarea
                  rows={2}
                  value={newTagDesc}
                  onChange={(e) => setNewTagDesc(e.target.value)}
                  placeholder="Short note on where this label applies..."
                  className={`w-full px-3.5 py-2 rounded-xl text-xs border focus:outline-none ${tokens.surfaceElevated} ${tokens.border} ${tokens.textPrimary}`}
                />
              </div>

              <div className="pt-3 border-t border-inherit flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className={`px-4 py-2 text-xs font-medium ${tokens.textSecondary} hover:${tokens.textPrimary}`}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-xs font-semibold tracking-wider uppercase ${tokens.accentBtn}`}
                >
                  Save Tag
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
