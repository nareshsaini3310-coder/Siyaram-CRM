import { motion, AnimatePresence } from 'motion/react';
import React, { useState } from 'react';
import {
  UserPlus,
  FileSpreadsheet,
  Users,
  Plus,
  Search,
  Phone,
  Mail,
  Briefcase,
  ArrowRight,
  Star,
  X,
  Calendar,
  MapPin,
  MessageSquare,
  Clock,
  Sparkles,
  ExternalLink,
  MoreVertical,
  Check,
  CheckSquare,
  CheckCircle2,
  Tag as TagIcon
} from 'lucide-react';
import { EmptyStatePlaceholder } from '../components/EmptyStatePlaceholder';

import { Client, ClientStatus } from '../types';
import { useTheme } from '../context/ThemeContext';
import { useData } from '../context/DataContext';
import { AddClientModal } from '../components/AddClientModal';
import { EditFollowUpModal } from '../components/EditFollowUpModal';
import { QuickCommModal } from '../components/QuickCommModal';
import { CardContextMenuModal } from '../components/CardContextMenuModal';
import { BulkClientActionBar } from '../components/BulkClientActionBar';
import { BulkTagModal } from '../components/BulkTagModal';
import { ExcelImportModal } from '../components/ExcelImportModal';
import { useLongPress } from '../utils/useLongPress';
import { getClientStatusColor } from '../utils/status';
import { haptics } from '../utils/haptics';

interface ClientsViewProps {
  onSelectClient: (id: string) => void;
  onSelectProject: (id: string) => void;
  onOpenVoiceRecorder: (clientId?: string, projectId?: string) => void;
  searchQuery: string;
}

interface ClientCardItemProps {
  client: Client;
  tokens: any;
  theme: string;
  isSelected: boolean;
  isSelectionMode: boolean;
  onToggleSelect: (id: string) => void;
  onSelectClient: (id: string) => void;
  onOpenContextMenu: (client: Client) => void;
  handleQuickCall: (phoneNumber?: string) => void;
  handleOpenWhatsApp: (whatsappNumber?: string, clientName?: string) => void;
}

const ClientCardItem: React.FC<ClientCardItemProps> = ({
  client,
  tokens,
  theme,
  isSelected,
  isSelectionMode,
  onToggleSelect,
  onSelectClient,
  onOpenContextMenu,
  handleQuickCall,
  handleOpenWhatsApp,
}) => {
  const { projects, tags } = useData();
  const [isPressing, setIsPressing] = useState(false);

  const longPressProps = useLongPress(
    () => {
      setIsPressing(false);
      onOpenContextMenu(client);
    },
    () => {
      if (isSelectionMode) {
        onToggleSelect(client.id);
      } else {
        onSelectClient(client.id);
      }
    },
    {
      threshold: 420,
      onStart: () => setIsPressing(true),
      onCancel: () => setIsPressing(false),
      onFinish: () => setIsPressing(false),
    }
  );

  const clientProjects = client.projectIds
    .map((pId) => projects.find((p) => p.id === pId))
    .filter(Boolean);

  const clientTags = client.tagIds
    .map((tId) => tags.find((t) => t.id === tId))
    .filter(Boolean);

  const isVIP = client.status === 'vip';
  const card3D = `${tokens.surface} ${tokens.border} ${tokens.surfaceHover}`;

  return (
    <motion.div
      key={client.id}
      {...longPressProps}
      className={`p-5 sm:p-4 sm:p-5 rounded-[20px] flex flex-col justify-between select-none cursor-pointer transition-all duration-150 relative ${
        isSelected
          ? 'ring-2 ring-amber-500 border-amber-500/60 bg-amber-500/[0.05] shadow-md'
          : isPressing
          ? 'scale-[0.98] ring-2 ring-amber-500/60 shadow-inner'
          : 'hover:translate-y-[-2px]'
      } ${card3D}`}
    >
      <div>
        {/* Header with selection checkbox, avatar, location, badges and long-press trigger */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            {/* Selection Checkbox */}
            <button
              type="button"
              data-prevent-long-press="true"
              onClick={(e) => {
                e.stopPropagation();
                haptics.selection();
                onToggleSelect(client.id);
              }}
              className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all cursor-pointer shrink-0 border ${
                isSelected
                  ? 'bg-amber-500 border-amber-500 text-slate-950 shadow-sm scale-105'
                  : isSelectionMode
                  ? 'border-amber-500/60 bg-amber-500/10 hover:border-amber-500 text-transparent'
                  : 'border-stone-400/30 hover:border-amber-500 hover:bg-stone-500/10 text-transparent opacity-60 hover:opacity-100'
              }`}
              title={isSelected ? 'Deselect client' : 'Select client for bulk actions'}
            >
              <Check className={`w-3.5 h-3.5 stroke-[3] ${isSelected ? 'opacity-100' : 'opacity-0'}`} />
            </button>

            <div className="relative">
              <img
                src={client.avatar}
                alt={client.name}
                onClick={(e) => {
                  e.stopPropagation();
                  if (isSelectionMode) {
                    onToggleSelect(client.id);
                  } else {
                    onSelectClient(client.id);
                  }
                }}
                className="w-13 h-13 rounded-2xl object-cover border-2 border-white/40 shadow-sm cursor-pointer hover:opacity-90"
              />
              {isVIP && (
                <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center text-slate-950 ring-2 ring-white">
                  <Star className="w-3 h-3 fill-current" />
                </span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3
                  onClick={(e) => {
                    e.stopPropagation();
                    if (isSelectionMode) {
                      onToggleSelect(client.id);
                    } else {
                      onSelectClient(client.id);
                    }
                  }}
                  className="font-display text-lg tracking-tight font-bold cursor-pointer hover:underline"
                >
                  {client.name}
                </h3>
                <span 
                  className={`w-2.5 h-2.5 rounded-full shrink-0 ${getClientStatusColor(client.status)}`}
                  title={`Status: ${client.status}`}
                />
              </div>
              {client.location && (
                <div className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-stone-400">
                  <MapPin className="w-3 h-3 text-rose-500 shrink-0" />
                  <span className="truncate max-w-[160px]">{client.location}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <span
              className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full font-semibold ${
                client.status === 'vip'
                  ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                  : client.status === 'active'
                  ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  : 'bg-blue-500/15 text-blue-600 dark:text-blue-400'
              }`}
            >
              {client.status}
            </span>
            <button
              type="button"
              data-prevent-long-press="true"
              onClick={(e) => {
                e.stopPropagation();
                haptics.selection();
                onOpenContextMenu(client);
              }}
              className="p-1 rounded-lg text-stone-400 hover:text-amber-500 hover:bg-stone-500/15 transition-colors cursor-pointer"
              title="Quick Tasks (Long-press card or click)"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="text-xs mb-3">
          <p className={`font-medium ${tokens.textSecondary}`}>{client.role}</p>
          <p className="text-[11px] font-mono text-slate-400">{client.company}</p>
        </div>

        {/* Contact numbers: Mobile & Manchaha WhatsApp */}
        <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200/80 dark:border-white/10 space-y-1.5 text-xs font-mono">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-slate-600 dark:text-stone-300">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              <span>{client.phone}</span>
            </div>
          </div>

          {client.whatsappNumber && (
            <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 dark:border-white/5">
              <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-semibold">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>{client.whatsappNumber}</span>
              </div>
              <button
                type="button"
                data-prevent-long-press="true"
                onClick={(e) => {
                  e.stopPropagation();
                  handleOpenWhatsApp(client.whatsappNumber, client.name);
                }}
                className="text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-0.5 cursor-pointer"
              >
                <span>WhatsApp</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </button>
            </div>
          )}
        </div>

        {/* Next Follow-Up Schedule Card */}
        {client.nextFollowUpDate && (
          <div className="mt-3 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs">
            <div className="flex items-center justify-between text-[10px] font-mono font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 mb-1">
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                Next Follow-Up: {client.nextFollowUpDate}
              </span>
              {client.nextFollowUpTime && (
                <span className="flex items-center gap-0.5">
                  <Clock className="w-2.5 h-2.5" />
                  {client.nextFollowUpTime}
                </span>
              )}
            </div>
            {client.nextFollowUpNote && (
              <p className="text-[11px] text-slate-700 dark:text-stone-300 line-clamp-1 italic">
                "{client.nextFollowUpNote}"
              </p>
            )}
          </div>
        )}

        {/* Tags */}
        {clientTags.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-3">
            {clientTags.map((tag) => (
              <span
                key={tag!.id}
                className="text-[10px] font-mono px-2 py-0.5 rounded-md border"
                style={{
                  borderColor: `${tag!.color}40`,
                  backgroundColor: `${tag!.color}15`,
                  color: tag!.color,
                }}
              >
                {tag!.name}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Footer: Linked Projects + Action */}
      <div className="mt-4 pt-3 border-t border-inherit flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 text-stone-400 text-[11px] font-mono">
          <Briefcase className="w-3.5 h-3.5" />
          <span className="truncate max-w-[140px]">
            {clientProjects[0]?.title || 'Siyaram Project'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            data-prevent-long-press="true"
            onClick={(e) => {
              e.stopPropagation();
              handleQuickCall(client.phone || client.whatsappNumber);
            }}
            className="flex-1 py-1.5 px-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 bg-blue-500/15 text-blue-700 hover:bg-blue-500/25 dark:bg-blue-500/20 dark:text-blue-400 dark:hover:bg-blue-500/30 transition-colors cursor-pointer"
            title="Quick Call"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Call</span>
          </button>

          <button
            type="button"
            data-prevent-long-press="true"
            onClick={(e) => {
              e.stopPropagation();
              handleOpenWhatsApp(client.whatsappNumber || client.phone, client.name);
            }}
            className="p-1.5 rounded-xl text-emerald-600 bg-emerald-500/15 hover:bg-emerald-500/25 transition-colors cursor-pointer shrink-0"
            title="Send WhatsApp Message"
          >
            <MessageSquare className="w-4 h-4" />
          </button>

          <button
            type="button"
            data-prevent-long-press="true"
            onClick={(e) => {
              e.stopPropagation();
              onSelectClient(client.id);
            }}
            className={`p-1.5 rounded-xl text-xs font-semibold flex items-center justify-center transition-colors shrink-0 bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-white/5 dark:text-stone-300 dark:hover:bg-white/10`}
            title="View Dossier"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export const ClientsView: React.FC<ClientsViewProps> = ({
  onSelectClient,
  onSelectProject,
  onOpenVoiceRecorder,
  searchQuery,
}) => {
  const { theme, tokens, accent } = useTheme();
  const { clients, projects, tags } = useData();

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [nestedClientTab, setNestedClientTab] = useState<'directory' | 'contact' | 'touchpoints'>('directory');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isExcelImportOpen, setIsExcelImportOpen] = useState(false);

  // Bulk Selection & Tag Management State
  const [selectedClientIds, setSelectedClientIds] = useState<string[]>([]);
  const [isBulkTagModalOpen, setIsBulkTagModalOpen] = useState(false);
  const [bulkTagModalMode, setBulkTagModalMode] = useState<'apply' | 'remove'>('apply');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Contextual Menu & Quick Task Modals
  const [contextClient, setContextClient] = useState<Client | null>(null);
  const [isFollowUpModalOpen, setIsFollowUpModalOpen] = useState(false);
  const [followUpClientId, setFollowUpClientId] = useState<string | undefined>();
  const [followUpProjectId, setFollowUpProjectId] = useState<string | undefined>();
  const [isQuickCommOpen, setIsQuickCommOpen] = useState(false);
  const [quickCommClientId, setQuickCommClientId] = useState<string | undefined>();
  const [quickCommProjectId, setQuickCommProjectId] = useState<string | undefined>();
  const [quickCommChannel, setQuickCommChannel] = useState<'call' | 'whatsapp'>('call');

  const filteredClients = clients.filter((c) => {
    const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !query ||
      c.name.toLowerCase().includes(query) ||
      c.company.toLowerCase().includes(query) ||
      c.email.toLowerCase().includes(query) ||
      c.role.toLowerCase().includes(query) ||
      (c.location && c.location.toLowerCase().includes(query)) ||
      (c.phone && c.phone.includes(query)) ||
      (c.whatsappNumber && c.whatsappNumber.includes(query));
    return matchesStatus && matchesSearch;
  });

  const handleToggleSelect = (id: string) => {
    setSelectedClientIds((prev) =>
      prev.includes(id) ? prev.filter((cId) => cId !== id) : [...prev, id]
    );
  };

  const isAllFilteredSelected =
    filteredClients.length > 0 &&
    filteredClients.every((c) => selectedClientIds.includes(c.id));

  const handleToggleSelectAll = () => {
    const filteredIds = filteredClients.map((c) => c.id);
    if (isAllFilteredSelected) {
      setSelectedClientIds((prev) => prev.filter((id) => !filteredIds.includes(id)));
    } else {
      setSelectedClientIds((prev) => Array.from(new Set([...prev, ...filteredIds])));
    }
  };

  const handleClearSelection = () => {
    setSelectedClientIds([]);
  };

  const handleOpenBulkTagModal = (mode: 'apply' | 'remove') => {
    setBulkTagModalMode(mode);
    setIsBulkTagModalOpen(true);
  };

  const handleSuccessToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleOpenWhatsApp = (whatsappNumber?: string, clientName?: string) => {
    if (!whatsappNumber) return;
    const cleanNum = whatsappNumber.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(
      `Namaste ${clientName || ''}, greeting from Siyaram Estates. I wanted to follow up with you regarding your inquiry.`
    );
    window.open(`https://wa.me/${cleanNum}?text=${text}`, '_blank');
  };

  const handleQuickCall = (phoneNumber?: string) => {
    if (!phoneNumber) return;
    const cleanNum = phoneNumber.replace(/[^0-9+]/g, '');
    if (cleanNum) {
      window.location.href = `tel:${cleanNum}`;
    }
  };

  return (
    <div className="space-y-4 ">
      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-2 border-b border-inherit">
        <div>
          <span className={`text-[11px] font-mono tracking-widest uppercase ${tokens.textMuted}`}>
            Relationship Directory · Siyaram CRM
          </span>
          <h2 className="font-display text-xl tracking-tight mt-0.5">
            Client Dossiers & Follow-ups
          </h2>
          <p className={`text-xs ${tokens.textSecondary}`}>
            Managing {clients.length} clients with direct WhatsApp, location details, and upcoming schedules
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setIsExcelImportOpen(true)}
            className={`px-4 py-2.5 rounded-2xl font-semibold text-xs flex items-center gap-2 border ${tokens.border} ${tokens.surfaceElevated} ${tokens.textPrimary} hover:border-blue-500/40 transition-all`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Import Excel</span>
          </button>
          <button
            type="button"
            onClick={() => setIsCreateModalOpen(true)}
            className={`px-5 py-2.5 rounded-2xl font-bold text-xs tracking-wider uppercase flex items-center gap-2 transition-all cursor-pointer shadow-md ${tokens.accentBtn}`}
          >
            <Plus className="w-4 h-4" />
            <span>Add New Client</span>
          </button>
        </div>
      </div>

      {/* PRIMARY TAB LEVEL: Status Filter */}
      <div className="space-y-3">
        <div className="p-1 rounded-2xl bg-stone-500/10 border border-inherit flex flex-wrap items-center gap-1">
          {[
            { id: 'all', label: 'All Stakeholders' },
            { id: 'vip', label: 'VIP Partners' },
            { id: 'active', label: 'Active Buyers' },
            { id: 'lead', label: 'Inbound Leads' },
          ].map((tab) => {
            const active = statusFilter === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setStatusFilter(tab.id)}
                className={`flex-1 min-w-[100px] py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  active
                    ? theme === 'dark'
                      ? 'tactile-pill-active-dark scale-[1.01]'
                      : 'tactile-pill-active-dawn scale-[1.01]'
                    : `${tokens.textSecondary} hover:${tokens.textPrimary} hover:bg-stone-500/10`
                }`}
              >
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* NESTED SECONDARY SUB-TABS */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex items-center gap-2">
            {[
              { id: 'directory', label: 'Directory Cards' },
              { id: 'contact', label: 'Contact Details' },
              { id: 'touchpoints', label: 'Upcoming Follow-ups' },
            ].map((sub) => (
              <button
                key={sub.id}
                type="button"
                onClick={() => setNestedClientTab(sub.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                  nestedClientTab === sub.id
                    ? theme === 'dark'
                      ? 'bg-[#f4f1ea] text-[#0b0c0e] font-semibold shadow-sm'
                      : 'bg-[#1b1a17] text-[#ece7de] font-semibold shadow-sm'
                    : `${tokens.surfaceElevated} ${tokens.textSecondary} border ${tokens.border} hover:${tokens.textPrimary}`
                }`}
              >
                {sub.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Bulk Select Toggle Button */}
            <button
              type="button"
              id="btn-toggle-client-selection"
              onClick={() => {
                haptics.selection();
                handleToggleSelectAll();
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono flex items-center gap-1.5 border transition-all cursor-pointer ${
                selectedClientIds.length > 0
                  ? 'bg-amber-500/20 border-amber-500/50 text-amber-600 dark:text-amber-400 font-bold shadow-sm'
                  : `${tokens.surfaceElevated} ${tokens.border} ${tokens.textSecondary} hover:${tokens.textPrimary}`
              }`}
            >
              <CheckSquare className={`w-3.5 h-3.5 ${selectedClientIds.length > 0 ? 'text-amber-500' : 'text-stone-400'}`} />
              <span>
                {selectedClientIds.length > 0
                  ? `${selectedClientIds.length} Selected`
                  : 'Select Multiple'}
              </span>
            </button>

            <span className="text-xs font-mono text-stone-400 hidden sm:inline">
              {filteredClients.length} clients
            </span>
          </div>
        </div>
      </div>

      {/* Floating Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-18 right-4 sm:right-6 z-[80] px-4 py-3 rounded-2xl bg-emerald-500 text-white font-semibold text-xs shadow-xl flex items-center gap-2 border border-emerald-400"
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Clients Grid with Apple 3D glass card styling */}
      {filteredClients.length === 0 ? (
        <EmptyStatePlaceholder
          icon={Users}
          title="No clients found"
          description="Your client roster is currently empty or no matches were found. Get started by adding a new lead or client."
          actionLabel="Add New Client"
          ActionIcon={UserPlus}
          onAction={() => setIsCreateModalOpen(true)}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredClients.map((client) => (
            <ClientCardItem
              key={client.id}
              client={client}
              tokens={tokens}
              theme={theme}
              isSelected={selectedClientIds.includes(client.id)}
              isSelectionMode={selectedClientIds.length > 0}
              onToggleSelect={handleToggleSelect}
              onSelectClient={onSelectClient}
              onOpenContextMenu={(c) => setContextClient(c)}
              handleQuickCall={handleQuickCall}
              handleOpenWhatsApp={handleOpenWhatsApp}
            />
          ))}
        </div>
      )}

      {/* Floating Action Menu for Bulk Operations */}
      <BulkClientActionBar
        selectedCount={selectedClientIds.length}
        totalFilteredCount={filteredClients.length}
        isAllSelected={isAllFilteredSelected}
        onToggleSelectAll={handleToggleSelectAll}
        onOpenBulkTagModal={handleOpenBulkTagModal}
        onClearSelection={handleClearSelection}
      />

      {/* Bulk Tag Management Modal */}
      <BulkTagModal
        isOpen={isBulkTagModalOpen}
        onClose={() => setIsBulkTagModalOpen(false)}
        selectedClientIds={selectedClientIds}
        initialMode={bulkTagModalMode}
        onSuccess={handleSuccessToast}
      />

      {/* Contextual Long-Press Menu for Rapid Tasks (Call, Message, Add Follow-up) */}
      <CardContextMenuModal
        isOpen={Boolean(contextClient)}
        onClose={() => setContextClient(null)}
        type="client"
        client={contextClient}
        onSelectClient={onSelectClient}
        onOpenFollowUp={(clientId, projectId) => {
          setFollowUpClientId(clientId);
          setFollowUpProjectId(projectId);
          setIsFollowUpModalOpen(true);
        }}
        onOpenVoiceRecorder={onOpenVoiceRecorder}
        onOpenQuickComm={(clientId, projectId, channel) => {
          setQuickCommClientId(clientId);
          setQuickCommProjectId(projectId);
          setQuickCommChannel(channel || 'call');
          setIsQuickCommOpen(true);
        }}
      />

      {/* Rapid Add Follow-Up Modal */}
      <EditFollowUpModal
        isOpen={isFollowUpModalOpen}
        onClose={() => setIsFollowUpModalOpen(false)}
        initialClientId={followUpClientId}
        initialProjectId={followUpProjectId}
      />

      {/* Quick Communication Modal */}
      <QuickCommModal
        isOpen={isQuickCommOpen}
        onClose={() => setIsQuickCommOpen(false)}
        initialClientId={quickCommClientId}
        initialProjectId={quickCommProjectId}
        initialChannel={quickCommChannel}
        onOpenVoiceRecorder={onOpenVoiceRecorder}
      />

      <ExcelImportModal isOpen={isExcelImportOpen} onClose={() => setIsExcelImportOpen(false)} />

      {/* Add Client Modal */}
      <AddClientModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onClientCreated={(newId) => onSelectClient(newId)}
      />
    </div>
  );
};

