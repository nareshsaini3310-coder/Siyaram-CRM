import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion, useScroll } from 'motion/react';
import { ArrowUp } from 'lucide-react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider, useData } from './context/DataContext';
import { ViewType } from './types';
import { haptics } from './utils/haptics';

// Components
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { BottomDock } from './components/BottomDock';
import { VoiceRecorderModal } from './components/VoiceRecorderModal';
import { AuthModal } from './components/AuthModal';
import { SyncToast } from './components/SyncToast';
import { PullToRefresh } from './components/PullToRefresh';
import { SyncConflictModal } from './components/SyncConflictModal';
import { NotificationManager } from './components/NotificationManager';

// Views
import { DashboardView } from './views/DashboardView';
import { ProjectsView } from './views/ProjectsView';
import { ProjectDetailView } from './views/ProjectDetailView';
import { ClientsView } from './views/ClientsView';
import { ClientDetailView } from './views/ClientDetailView';
import { FollowUpsView } from './views/FollowUpsView';
import { TagsView } from './views/TagsView';
import { SettingsView } from './views/SettingsView';

interface VoiceRecorderModalState {
  isOpen: boolean;
  clientId?: string;
  projectId?: string;
  followUpId?: string;
}

// Ultra-fast, snappy view transition variants for instantaneous tab switching
const viewFastVariants = {
  initial: {
    opacity: 0,
    y: 3,
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.09,
      ease: [0.16, 1, 0.3, 1],
    },
  },
  exit: {
    opacity: 0,
    transition: {
      duration: 0.04,
      ease: 'easeOut',
    },
  },
};

const AppContent: React.FC = () => {
  const { theme, tokens, accent } = useTheme();
  const { isAuthModalOpen, closeAuthModal } = useAuth();
  const { clients, followUps } = useData();
  const { scrollY, scrollYProgress } = useScroll();
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const checkScroll = () => {
      setIsScrolled(window.scrollY > 0);
      setShowScrollTop(window.scrollY > 500);
    };
    checkScroll();
    const unsubscribe = scrollY.on('change', (latest) => {
      setIsScrolled(latest > 0);
      setShowScrollTop(latest > 500);
    });
    window.addEventListener('scroll', checkScroll, { passive: true });
    return () => {
      unsubscribe();
      window.removeEventListener('scroll', checkScroll);
    };
  }, [scrollY]);

  const handleScrollToTop = () => {
    haptics.light();
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  // Haptic feedback listener for tactile user interactions within 'atelier-main-container'
  useEffect(() => {
    const container = document.getElementById('atelier-main-container');
    if (!container) return;

    const handlePointerDown = (e: PointerEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;

      // Identify interactive controls: buttons, anchors, tabs, checkboxes, radios, selects, or custom touchable targets
      const interactive = target.closest(
        'button, a, [role="button"], [role="tab"], [role="switch"], input[type="checkbox"], input[type="radio"], select, [data-haptic]'
      );
      if (interactive) {
        haptics.selection();
      }
    };

    container.addEventListener('pointerdown', handlePointerDown, { passive: true });
    return () => {
      container.removeEventListener('pointerdown', handlePointerDown);
    };
  }, []);

  // Navigation state
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const currentState = window.history.state;
    if (!currentState?.siyaramView) {
      window.history.replaceState({ siyaramView: 'dashboard' }, '', window.location.href);
    }
    const handlePopState = (event: PopStateEvent) => {
      const state = event.state;
      if (!state?.siyaramView) return;
      setCurrentView(state.siyaramView);
      setSelectedProjectId(state.projectId || null);
      setSelectedClientId(state.clientId || null);
      window.scrollTo(0, 0);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Voice recorder modal state
  const [voiceRecorderState, setVoiceRecorderState] = useState<VoiceRecorderModalState>({
    isOpen: false,
  });

  const handleOpenVoiceRecorder = (clientId?: string, projectId?: string, followUpId?: string) => {
    haptics.medium();
    setVoiceRecorderState({
      isOpen: true,
      clientId,
      projectId,
      followUpId,
    });
  };

  const handleCloseVoiceRecorder = () => {
    haptics.selection();
    setVoiceRecorderState({ isOpen: false });
  };


  const handleSaveAndNextClient = (currentClientId: string) => {
    const now = new Date();
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const todayCalls = followUps
      .filter((f) => f.status === 'pending' && f.dueDate === today && f.type === 'call' && f.clientId)
      .sort((a, b) => (a.scheduledTime || '').localeCompare(b.scheduledTime || ''));
    const orderedIds = todayCalls.map((f) => f.clientId as string);
    const uniqueIds = [...new Set(orderedIds)];
    const currentIndex = uniqueIds.indexOf(currentClientId);
    const nextId = currentIndex >= 0 ? uniqueIds[currentIndex + 1] : uniqueIds.find((id) => id !== currentClientId);
    if (nextId && clients.some((c) => c.id === nextId)) {
      haptics.selection();
      setSelectedClientId(nextId);
      setCurrentView('client_detail');
      window.scrollTo(0, 0);
      return;
    }
    haptics.success?.();
    setSelectedClientId(null);
    setCurrentView('dashboard');
    window.scrollTo(0, 0);
  };

  const handleNavigate = (view: ViewType) => {
    haptics.selection();
    setCurrentView(view);
    setSelectedProjectId(null);
    setSelectedClientId(null);
    window.history.pushState({ siyaramView: view }, '', window.location.href);
    window.scrollTo(0, 0);
  };

  const handleSelectProject = (projectId: string) => {
    haptics.selection();
    setSelectedProjectId(projectId);
    setCurrentView('project_detail');
    window.history.pushState({ siyaramView: 'project_detail', projectId }, '', window.location.href);
    window.scrollTo(0, 0);
  };

  const handleSelectClient = (clientId: string) => {
    haptics.selection();
    setSelectedClientId(clientId);
    setCurrentView('client_detail');
    window.history.pushState({ siyaramView: 'client_detail', clientId }, '', window.location.href);
    window.scrollTo(0, 0);
  };

  const handleBackToProjects = () => {
    haptics.selection();
    if (window.history.state?.siyaramView === 'project_detail') {
      window.history.back();
      return;
    }
    setSelectedProjectId(null);
    setCurrentView('projects');
  };

  const handleBackToClients = () => {
    haptics.selection();
    if (window.history.state?.siyaramView === 'client_detail') {
      window.history.back();
      return;
    }
    setSelectedClientId(null);
    setCurrentView('clients');
  };

  return (
    <div
      className={`min-h-screen font-jakarta transition-colors duration-200 selection:bg-blue-500/20 ${theme === 'dark' ? 'text-white' : 'text-[#141414]'}`}
      style={{
        backgroundColor: theme === 'dark' ? '#07111F' : '#F5F8FF',
        backgroundImage: theme === 'dark'
          ? 'radial-gradient(circle at 88% 8%, rgba(37, 99, 235, 0.20) 0px, transparent 55%), radial-gradient(circle at 12% 88%, rgba(139, 92, 246, 0.12) 0px, transparent 50%)'
          : 'radial-gradient(circle at 88% 8%, rgba(37, 99, 235, 0.10) 0px, transparent 55%), radial-gradient(circle at 12% 88%, rgba(139, 92, 246, 0.07) 0px, transparent 50%)',
        backgroundAttachment: 'fixed',
      }}
    >
      {/* 
        Child 1 of root container: Sidebar navigation component.
        Renders the desktop fixed sidebar and mobile slide-out drawer.
      */}
      <Sidebar
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenVoiceRecorder={() => handleOpenVoiceRecorder()}
        isMobileOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* 
        Child 2 of root container: Targeted by focus mode selector
        `div#root:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(2)`
        The main viewport container for Atelier Studio CRM
      */}
      <div
        id="atelier-main-container"
        className={`flex-1 min-w-0 flex flex-col min-h-screen lg:pl-64 transition-all duration-300 text-inherit bg-transparent relative ${
          isScrolled
            ? theme === 'dark'
              ? 'shadow-[inset_0_12px_24px_-10px_rgba(0,0,0,0.85)]'
              : 'shadow-[inset_0_12px_24px_-10px_rgba(0,0,0,0.08)]'
            : ''
        }`}
      >
        {/* Thin, fixed-position progress bar tracking main content scroll position using useScroll */}
        <motion.div
          id="atelier-scroll-progress-bar"
          className="fixed top-0 left-0 lg:left-64 right-0 h-[2.5px] z-50 pointer-events-none origin-left bg-gradient-to-r from-blue-600 via-violet-500 to-cyan-400 shadow-[0_1px_8px_rgba(37,99,235,0.40)]"
          style={{ scaleX: scrollYProgress, transformOrigin: '0%' }}
        />

        {/* Top Navbar */}
        <Navbar
          currentView={currentView}
          onNavigate={handleNavigate}
          onOpenMobileMenu={() => setIsMobileSidebarOpen(true)}
          onOpenVoiceRecorder={() => handleOpenVoiceRecorder()}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          isScrolled={isScrolled}
        />

        {/* Dynamic drop-shadow pinned header effect along the top edge of atelier-main-container */}
        <div
          id="atelier-pinned-header-shadow"
          className={`sticky top-14 left-0 right-0 h-0 z-20 pointer-events-none transition-shadow duration-300 ${
            isScrolled
              ? theme === 'dark'
                ? 'shadow-[0_14px_30px_-4px_rgba(0,0,0,0.9),0_4px_12px_-2px_rgba(139,92,246,0.18)]'
                : 'shadow-[0_14px_30px_-4px_rgba(0,0,0,0.12),0_4px_12px_-2px_rgba(37,99,235,0.14)]'
              : 'shadow-none'
          }`}
        />

        {/* Dynamic Viewport Content */}
        <PullToRefresh>
        <main className="flex-1 p-3 sm:p-5 max-w-5xl w-full mx-auto overflow-x-hidden">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={
                currentView === 'project_detail'
                  ? `project_detail_${selectedProjectId}`
                  : currentView === 'client_detail'
                  ? `client_detail_${selectedClientId}`
                  : currentView
              }
              variants={viewFastVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full"
            >

          {currentView === 'dashboard' && (
            <DashboardView
              onNavigate={handleNavigate}
              onSelectProject={handleSelectProject}
              onSelectClient={handleSelectClient}
              onOpenVoiceRecorder={handleOpenVoiceRecorder}
            />
          )}

          {currentView === 'projects' && (
            <ProjectsView
              onSelectProject={handleSelectProject}
              onSelectClient={handleSelectClient}
              onOpenVoiceRecorder={handleOpenVoiceRecorder}
              searchQuery={searchQuery}
            />
          )}

          {currentView === 'project_detail' && selectedProjectId && (
            <ProjectDetailView
              projectId={selectedProjectId}
              onBack={handleBackToProjects}
              onSelectClient={handleSelectClient}
              onOpenVoiceRecorder={handleOpenVoiceRecorder}
            />
          )}

          {currentView === 'clients' && (
            <ClientsView
              onSelectClient={handleSelectClient}
              onSelectProject={handleSelectProject}
              onOpenVoiceRecorder={handleOpenVoiceRecorder}
              searchQuery={searchQuery}
            />
          )}

          {currentView === 'client_detail' && selectedClientId && (
            <ClientDetailView
              clientId={selectedClientId}
              onBack={handleBackToClients}
              onSelectProject={handleSelectProject}
              onOpenVoiceRecorder={handleOpenVoiceRecorder}
              onSaveAndNextClient={handleSaveAndNextClient}
            />
          )}

          {currentView === 'followups' && (
            <FollowUpsView
              onSelectClient={handleSelectClient}
              onSelectProject={handleSelectProject}
              onOpenVoiceRecorder={handleOpenVoiceRecorder}
              searchQuery={searchQuery}
            />
          )}

          {currentView === 'tags' && (
            <TagsView
              onSelectClient={handleSelectClient}
              onSelectProject={handleSelectProject}
              searchQuery={searchQuery}
            />
          )}

          {currentView === 'settings' && <SettingsView />}
        
            </motion.div>
          </AnimatePresence>
</main>
        </PullToRefresh>

        {/* Architectural Footer */}
        <footer
          className={`mt-auto border-t py-8 px-4 sm:px-8 flex flex-col md:flex-row items-center justify-between gap-6 ${
            tokens.border
          }`}
        >
          <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-4 text-center sm:text-left">
            <div className="flex items-center gap-2.5">
              <img src="/brand-mark.svg" alt="Siyaram CRM" className="w-8 h-8 rounded-xl shadow-sm shrink-0" />
              <span className="font-display text-2xl sm:text-3xl font-black tracking-tight text-blue-500 dark:text-blue-400 leading-none">
                SIYARAM CRM
              </span>
              <span className="text-[10px] uppercase font-mono font-black tracking-wider px-2 py-0.5 rounded-md bg-blue-500/15 text-blue-600 dark:text-blue-300 border border-blue-500/25 shrink-0">
                REAL ESTATE
              </span>
            </div>

            <div className={`flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs font-mono ${tokens.textMuted}`}>
              <span className="hidden sm:inline">·</span>
              <span>Plots & High-Rises Executive Desk</span>
              <span>·</span>
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>Synced Locally & Audio Ready</span>
              </span>
            </div>
          </div>

          <div className={`flex items-center gap-3 sm:gap-4 text-xs font-mono ${tokens.textMuted}`}>
            <span className="capitalize">Theme: {theme}</span>
            <span>·</span>
            <span className="capitalize">Accent: {accent}</span>
            <span>·</span>
            <span>Edition 2026.4</span>
          </div>
        </footer>

        {/* Scroll-to-Top Utility Button */}
        <AnimatePresence>
          {showScrollTop && (
            <motion.button
              id="atelier-scroll-to-top"
              type="button"
              onClick={handleScrollToTop}
              initial={{ opacity: 0, scale: 0.6, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.6, y: 20 }}
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
              whileHover={{ scale: 1.08, y: -2 }}
              whileTap={{ scale: 0.92 }}
              aria-label="Scroll to top"
              className={`fixed bottom-24 sm:bottom-8 right-4 sm:right-8 z-40 p-3 rounded-full shadow-xl backdrop-blur-md border cursor-pointer flex items-center justify-center transition-colors ${
                theme === 'dark'
                  ? 'bg-blue-500/10 text-blue-300 border-blue-400/20 hover:bg-blue-500/15 hover:border-blue-400/30 shadow-[0_8px_24px_rgba(0,0,0,0.5)]'
                  : 'bg-white/95 text-[#8A6A1E] border-[#D4A33A]/30 hover:bg-stone-50 hover:border-[#D4A33A]/60 shadow-[0_8px_24px_rgba(212,163,58,0.25)]'
              }`}
            >
              <ArrowUp className="w-5 h-5 stroke-[2.2]" />
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      {/* 3D Floating Bottom Navigation Dock (matches user's mobile dock design) */}
      <BottomDock currentView={currentView} onNavigate={handleNavigate} />

      {/* Voice Recorder Modal */}
      {voiceRecorderState.isOpen && (
        <VoiceRecorderModal
          isOpen={voiceRecorderState.isOpen}
          onClose={handleCloseVoiceRecorder}
          initialClientId={voiceRecorderState.clientId}
          initialProjectId={voiceRecorderState.projectId}
          initialFollowUpId={voiceRecorderState.followUpId}
        />
      )}

      {/* Better-Auth Session Modal */}
      <AuthModal isOpen={isAuthModalOpen} onClose={closeAuthModal} />
      <SyncToast />

      {/* 2-Minute Call Alert & Background Notification Engine */}
      <NotificationManager onSelectClient={handleSelectClient} />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <DataProvider>
          <AppContent />
          <SyncConflictModal />
    </DataProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
