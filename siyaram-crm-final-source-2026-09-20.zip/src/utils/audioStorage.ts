const DATABASE_NAME = 'siyaram-crm-media';
const STORE_NAME = 'audio-blobs';
const DATABASE_VERSION = 1;

const openAudioDatabase = (): Promise<IDBDatabase> => new Promise((resolve, reject) => {
  const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
  request.onupgradeneeded = () => {
    if (!request.result.objectStoreNames.contains(STORE_NAME)) {
      request.result.createObjectStore(STORE_NAME);
    }
  };
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => reject(request.error || new Error('Unable to open audio storage'));
});

export const saveAudioBlob = async (blob: Blob): Promise<string> => {
  if (typeof indexedDB === 'undefined') throw new Error('Local audio storage is unavailable.');
  const id = `audio-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const database = await openAudioDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, 'readwrite');
    transaction.objectStore(STORE_NAME).put(blob, id);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error || new Error('Unable to save audio'));
  });
  database.close();
  return id;
};

export const loadAudioBlobUrl = async (id: string): Promise<string | null> => {
  if (typeof indexedDB === 'undefined') return null;
  const database = await openAudioDatabase();
  const blob = await new Promise<Blob | undefined>((resolve, reject) => {
    const request = database.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).get(id);
    request.onsuccess = () => resolve(request.result as Blob | undefined);
    request.onerror = () => reject(request.error);
  });
  database.close();
  return blob ? URL.createObjectURL(blob) : null;
};

export const deleteAudioBlob = async (id: string): Promise<void> => {
  if (typeof indexedDB === 'undefined') return;
  const database = await openAudioDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, 'readwrite');
    transaction.objectStore(STORE_NAME).delete(id);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
  database.close();
};
