export type CallLaunchResult = 'launched' | 'invalid' | 'unsupported';

const cleanNumber = (phone: string) => phone.replace(/[^0-9+]/g, '');

export const startCellularCall = (phone: string): CallLaunchResult => {
  const number = cleanNumber(phone);
  if (!number) return 'invalid';
  if (typeof window === 'undefined') return 'unsupported';
  try {
    const nativeCall = (window as Window & {
      SiyaramNative?: { call?: (value: string) => void };
    }).SiyaramNative?.call;
    if (nativeCall) {
      nativeCall(number);
      return 'launched';
    }
    window.location.href = `tel:${number}`;
    return 'launched';
  } catch {
    return 'unsupported';
  }
};

export const getCleanPhoneNumber = cleanNumber;
