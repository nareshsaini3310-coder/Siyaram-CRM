export type CallLaunchResult = 'launched' | 'invalid' | 'unsupported';

const cleanNumber = (phone: string) => phone.replace(/[^0-9+]/g, '');

/**
 * Single entry point for cellular calls. The web/PWA build uses the tel: intent;
 * the Android shell can replace this implementation with a native Telecom/RoleManager bridge.
 */
export const startCellularCall = (phone: string): CallLaunchResult => {
  const number = cleanNumber(phone);
  if (!number) return 'invalid';
  if (typeof window === 'undefined') return 'unsupported';
  try {
    window.location.href = `tel:${number}`;
    return 'launched';
  } catch {
    return 'unsupported';
  }
};

export const getCleanPhoneNumber = cleanNumber;
