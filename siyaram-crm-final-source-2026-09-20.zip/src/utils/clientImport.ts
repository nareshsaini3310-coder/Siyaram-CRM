import { Client, ClientStatus, Project } from '../types';

export interface RawImportRow {
  [key: string]: unknown;
}

export interface ClientImportSummary {
  total: number;
  valid: number;
  existing: number;
  duplicates: number;
  missingData: number;
  needsReview: number;
  projectsToCreate: string[];
  clients: Array<{
    name: string;
    phone: string;
    whatsappNumber?: string;
    email: string;
    location?: string;
    company: string;
    budget?: string;
    requirement?: string;
    leadSource?: string;
    leadDate?: string;
    notes?: string;
    nextFollowUpDate?: string;
    nextFollowUpType?: 'call' | 'whatsapp' | 'sms' | 'email' | 'meeting' | 'review';
    importReview?: string;
    importProjectName?: string;
    status?: ClientStatus;
    projectIds: string[];
    existingClientId?: string;
  }>;
}

const normalizeHeader = (value: unknown) => String(value ?? '').trim().toLowerCase().replace(/[\s_\-./]+/g, '');
const valueFrom = (row: RawImportRow, aliases: string[]) => {
  const normalized = new Map(Object.entries(row).map(([k, v]) => [normalizeHeader(k), v]));
  for (const alias of aliases) {
    const value = normalized.get(normalizeHeader(alias));
    if (value !== undefined && String(value).trim() !== '') return String(value).trim();
  }
  return '';
};

const HEADER_ALIASES = new Set(['name', 'client', 'buyername', 'mobile', 'phone', 'contact', 'project', 'status', 'remarks', 'remark', 'notes']);

export const rowsFromSheetMatrix = (matrix: unknown[][]): RawImportRow[] => {
  if (!matrix.length) return [];
  const firstRow = matrix[0].map((value) => normalizeHeader(value));
  const hasHeader = firstRow.some((value) => HEADER_ALIASES.has(value));
  if (hasHeader) {
    const headers = matrix[0].map((value, index) => String(value || `Column ${index + 1}`).trim());
    return matrix.slice(1).filter((row) => row.some((value) => String(value ?? '').trim() !== '')).map((row) => Object.fromEntries(headers.map((header, index) => [header, row[index] ?? ''])));
  }

  const columnCount = Math.max(...matrix.map((row) => row.length));
  const phoneColumn = Array.from({ length: columnCount }, (_, column) => matrix.slice(0, 30).filter((row) => /^\+?[0-9\s().-]{8,}$/.test(String(row[column] ?? '').trim())).length).reduce((best, score, column) => score > best.score ? { column, score } : best, { column: 0, score: -1 }).column;
  const statusWords = new Set(['grey', 'warm', 'closing', 'site visit confirmed', 'not interested', 'deal tay karega', 'deal dega']);
  const statusColumn = Array.from({ length: columnCount }, (_, column) => matrix.slice(0, 30).filter((row) => statusWords.has(String(row[column] ?? '').trim().toLowerCase())).length).reduce((best, score, column) => score > best.score ? { column, score } : best, { column: -1, score: 0 }).column;
  const nameColumn = Array.from({ length: columnCount }, (_, column) => matrix.slice(0, 30).filter((row) => column !== phoneColumn && /[A-Za-z\u0900-\u097F]/.test(String(row[column] ?? '')) && !statusWords.has(String(row[column] ?? '').trim().toLowerCase())).length).reduce((best, score, column) => score > best.score ? { column, score } : best, { column: 0, score: -1 }).column;
  const remainingColumns = Array.from({ length: columnCount }, (_, column) => column).filter((column) => ![nameColumn, phoneColumn, statusColumn].includes(column));
  const projectColumn = remainingColumns[0];
  const notesColumn = remainingColumns[1];
  return matrix.filter((row) => row.some((value) => String(value ?? '').trim() !== '')).map((row) => ({
    Name: row[nameColumn] ?? '',
    Mobile: row[phoneColumn] ?? '',
    Project: projectColumn === undefined ? '' : row[projectColumn] ?? '',
    Status: statusColumn < 0 ? '' : row[statusColumn] ?? '',
    Remarks: notesColumn === undefined ? '' : row[notesColumn] ?? '',
  }));
};

export const normalizePhoneValue = (value: string) => {
  const trimmed = String(value || '').trim();
  if (/^\d+(?:\.\d+)?e[+-]?\d+$/i.test(trimmed)) {
    const expanded = Number(trimmed);
    if (Number.isFinite(expanded)) return String(Math.trunc(expanded));
  }
  return trimmed;
};

const cleanPhone = (value: string) => {
  const digits = normalizePhoneValue(value).replace(/\D/g, '');
  if (!digits) return '';
  if (digits.length === 10) return digits;
  if (digits.length > 10) {
    if (digits.startsWith('91') && digits.length === 12) return digits.slice(2);
    if (digits.startsWith('0') && digits.length === 11) return digits.slice(1);
    return '';
  }
  if (digits.length === 11 && digits.startsWith('0')) return digits.slice(1);
  return '';
};

const normalizeDate = (value: string) => {
  if (!value) return undefined;
  const d = new Date(value);
  if (!Number.isNaN(d.getTime())) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }
  const m = value.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return undefined;
};

export function mapClientRows(rows: RawImportRow[], projects: Project[], existingClients: Pick<Client, 'id' | 'phone'>[]): ClientImportSummary {
  const existingByPhone = new Map<string, string>();
  existingClients.forEach((client) => {
    const phone = cleanPhone(client.phone);
    if (phone) existingByPhone.set(phone, client.id);
  });
  const batch = new Set<string>();
  const result: ClientImportSummary = { total: rows.length, valid: 0, existing: 0, duplicates: 0, missingData: 0, needsReview: 0, projectsToCreate: [], clients: [] };

  for (const row of rows) {
    const name = valueFrom(row, ['Name', 'Client Name', 'Customer Name', 'Buyer Name', 'Customer', 'Client', 'Full Name', 'Buyer']);
    const phone = cleanPhone(valueFrom(row, ['Mobile', 'Mobile Number', 'Phone', 'Phone Number', 'Contact', 'Contact Number', 'Mob']));
    if (!name || !phone) { result.missingData += 1; continue; }
    if (batch.has(phone) || existingByPhone.has(phone)) { result.duplicates += 1; continue; }
    batch.add(phone);

    const projectValue = valueFrom(row, ['Project', 'Project Name', 'Interested Project', 'Property Project']);
    let projectIds: string[] = [];
    let importReview: string | undefined;
    if (projectValue) {
      const normalizedProjectValue = projectValue.trim().toLowerCase();
      const matches = projects.filter((p) => {
        const title = (p.title || '').trim().toLowerCase();
        const code = (p.code || '').trim().toLowerCase();
        return title === normalizedProjectValue || code === normalizedProjectValue;
      });
      if (matches.length === 1) projectIds = [matches[0].id];
      else if (matches.length > 1) importReview = `Project value matches multiple projects: ${projectValue}`;
      else {
        if (!result.projectsToCreate.some((project) => project.toLowerCase() === projectValue.toLowerCase())) {
          result.projectsToCreate.push(projectValue);
        }
        importReview = `New project will be created: ${projectValue}`;
      }
    }

    const client = {
      name,
      phone,
      whatsappNumber: cleanPhone(valueFrom(row, ['WhatsApp', 'WhatsApp Number', 'Whatsapp Number'])) || undefined,
      email: valueFrom(row, ['Email', 'Email Address']),
      location: valueFrom(row, ['Location', 'City', 'Area', 'Address', 'Locality', 'Site Location']) || undefined,
      company: valueFrom(row, ['Company', 'Organization', 'Organisation']),
      budget: valueFrom(row, ['Budget', 'Budget Range']) || undefined,
      requirement: valueFrom(row, ['Interest', 'Requirement', 'Property Type', 'Looking For', 'Requirement Type', 'Interested In', 'Property Requirement']) || undefined,
      notes: valueFrom(row, ['Comment', 'Comments', 'Remark', 'Remarks', 'Note', 'Notes', 'Description']) || undefined,
      leadSource: valueFrom(row, ['Lead Source', 'Source', 'LeadSource']) || undefined,
      nextFollowUpDate: normalizeDate(valueFrom(row, ['Follow Up', 'Follow-up', 'Followup', 'Next Follow Up', 'Follow Up Date'])),
      leadDate: normalizeDate(valueFrom(row, ['Date', 'Lead Date', 'Created Date', 'Enquiry Date'])),
      importReview,
      importProjectName: projectValue || undefined,
      status: valueFrom(row, ['Status', 'Lead Status', 'Stage']).toLowerCase() === 'grey' ? ('past' as ClientStatus) : undefined,
      projectIds,
      existingClientId: existingByPhone.get(phone),
    };
    result.clients.push(client);
    result.valid += 1;
    if (importReview) result.needsReview += 1;
  }
  return result;
}

export const toClientRecord = (item: ClientImportSummary['clients'][number]) => ({
  name: item.name,
  role: 'Lead',
  company: item.company || '—',
  email: item.email || '',
  budget: item.budget,
  requirement: item.requirement,
  leadSource: item.leadSource || 'Excel Import',
  phone: item.phone,
  whatsappNumber: item.whatsappNumber,
  avatar: item.name.slice(0, 2).toUpperCase(),
  status: item.status || ('lead' as ClientStatus),
  tagIds: [],
  projectIds: item.projectIds,
  lastContactDate: item.leadDate || new Date().toISOString().slice(0, 10),
  leadDate: item.leadDate,
  importReview: item.importReview,
  importProjectName: item.importProjectName,
  notes: item.notes || '',
  nextFollowUpDate: item.nextFollowUpDate,
  nextFollowUpType: item.nextFollowUpDate ? 'call' : undefined,
  preferredContact: 'phone' as const,
  existingClientId: item.existingClientId,
});
