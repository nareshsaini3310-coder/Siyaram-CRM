import { Client, ClientStatus, Project } from '../types';

export interface RawImportRow {
  [key: string]: unknown;
}

export interface ClientImportSummary {
  total: number;
  valid: number;
  existing: number;
  duplicates: number;
  missingData: number;
  needsReview: number;
  clients: Array<{
    name: string;
    phone: string;
    whatsappNumber?: string;
    email: string;
    location?: string;
    company: string;
    budget?: string;
    requirement?: string;
    leadSource?: string;
    leadDate?: string;
    importReview?: string;
    projectIds: string[];
    existingClientId?: string;
  }>;
}

const normalizeHeader = (value: unknown) => String(value ?? '').trim().toLowerCase().replace(/[\s_\-./]+/g, '');
const valueFrom = (row: RawImportRow, aliases: string[]) => {
  const normalized = new Map(Object.entries(row).map(([k, v]) => [normalizeHeader(k), v]));
  for (const alias of aliases) {
    const value = normalized.get(normalizeHeader(alias));
    if (value !== undefined && String(value).trim() !== '') return String(value).trim();
  }
  return '';
};

const cleanPhone = (value: string) => {
  const digits = (value || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.length === 10) return digits;
  if (digits.length > 10) {
    if (digits.startsWith('91') && digits.length === 12) return digits.slice(2);
    if (digits.startsWith('0') && digits.length > 10) return digits.slice(1).slice(-10);
    return digits.slice(-10);
  }
  if (digits.length === 11 && digits.startsWith('0')) return digits.slice(1);
  return digits;
};

const normalizeDate = (value: string) => {
  if (!value) return undefined;
  const d = new Date(value);
  if (!Number.isNaN(d.getTime())) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }
  const m = value.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return undefined;
};

export function mapClientRows(rows: RawImportRow[], projects: Project[], existingClients: Pick<Client, 'id' | 'phone'>[]): ClientImportSummary {
  const existingByPhone = new Map<string, string>();
  existingClients.forEach((client) => {
    const phone = cleanPhone(client.phone);
    if (phone) existingByPhone.set(phone, client.id);
  });
  const batch = new Set<string>();
  const result: ClientImportSummary = { total: rows.length, valid: 0, existing: 0, duplicates: 0, missingData: 0, needsReview: 0, clients: [] };

  for (const row of rows) {
    const name = valueFrom(row, ['Name', 'Client Name', 'Client', 'Buyer Name', 'Customer Name']);
    const phone = cleanPhone(valueFrom(row, ['Mobile', 'Mobile Number', 'Phone', 'Phone Number', 'Contact', 'Contact Number']));
    if (!name || !phone) { result.missingData += 1; continue; }
    if (batch.has(phone)) { result.duplicates += 1; continue; }
    batch.add(phone);

    const projectValue = valueFrom(row, ['Project', 'Project Name', 'Property', 'Project/Property', 'Project Name / Property']);
    let projectIds: string[] = [];
    let importReview: string | undefined;
    if (projectValue) {
      const normalizedProjectValue = projectValue.trim().toLowerCase();
      const matches = projects.filter((p) => {
        const title = (p.title || '').trim().toLowerCase();
        const code = (p.code || '').trim().toLowerCase();
        return title === normalizedProjectValue || code === normalizedProjectValue || title.includes(normalizedProjectValue) || code.includes(normalizedProjectValue);
      });
      if (matches.length === 1) projectIds = [matches[0].id];
      else importReview = matches.length > 1 ? `Project value matches multiple projects: ${projectValue}` : `Project not matched: ${projectValue}`;
    }

    const client = {
      name,
      phone,
      whatsappNumber: cleanPhone(valueFrom(row, ['WhatsApp', 'WhatsApp Number', 'Whatsapp Number'])) || undefined,
      email: valueFrom(row, ['Email', 'Email Address']),
      location: valueFrom(row, ['Location', 'City', 'Area']) || undefined,
      company: valueFrom(row, ['Company', 'Organization', 'Organisation']),
      budget: valueFrom(row, ['Budget', 'Budget Range']) || undefined,
      requirement: valueFrom(row, ['Requirement', 'Need', 'Property Requirement']) || undefined,
      leadSource: valueFrom(row, ['Lead Source', 'Source', 'LeadSource']) || undefined,
      leadDate: normalizeDate(valueFrom(row, ['Date', 'Lead Date', 'Created Date', 'Enquiry Date'])),
      importReview,
      projectIds,
      existingClientId: existingByPhone.get(phone),
    };
    result.clients.push(client);
    result.valid += 1;
    if (existingByPhone.has(phone)) result.existing += 1;
    if (importReview) result.needsReview += 1;
  }
  return result;
}

export const toClientRecord = (item: ClientImportSummary['clients'][number]) => ({
  name: item.name,
  role: 'Lead',
  company: item.company || '—',
  email: item.email || '',
  budget: item.budget,
  requirement: item.requirement,
  leadSource: item.leadSource || 'Excel Import',
  phone: item.phone,
  whatsappNumber: item.whatsappNumber,
  avatar: item.name.slice(0, 2).toUpperCase(),
  status: 'lead' as ClientStatus,
  tagIds: [],
  projectIds: item.projectIds,
  lastContactDate: item.leadDate || new Date().toISOString().slice(0, 10),
  leadDate: item.leadDate,
  importReview: item.importReview,
  notes: '',
  preferredContact: 'phone' as const,
  existingClientId: item.existingClientId,
});
