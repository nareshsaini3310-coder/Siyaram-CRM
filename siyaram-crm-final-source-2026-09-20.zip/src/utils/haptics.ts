let lastVibrateTime = 0;

export const vibrate = (pattern: number | number[] = 50) => {
  if (typeof window !== 'undefined' && typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
    try {
      const now = Date.now();
      // Throttle rapid repeated micro-ticks under 35ms to ensure crisp tactile response without buzz-clutter
      if (typeof pattern === 'number' && now - lastVibrateTime < 35) {
        return;
      }
      lastVibrateTime = now;
      navigator.vibrate(pattern);
    } catch (e) {
      // Ignore vibration errors gracefully
    }
  }
};

export const haptics = {
  selection: () => vibrate(10),
  light: () => vibrate(15),
  medium: () => vibrate(30),
  heavy: () => vibrate(60),
  success: () => vibrate([20, 50, 30]),
  warning: () => vibrate([30, 50, 80]),
  error: () => vibrate([40, 60, 40, 60, 40]),
};
