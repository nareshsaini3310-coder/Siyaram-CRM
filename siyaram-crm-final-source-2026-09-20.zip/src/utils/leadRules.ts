import { Client, FollowUp } from '../types';

export type LeadTemperature = 'hot' | 'warm' | 'cold';

export const LEAD_REMINDER_DAYS: Record<LeadTemperature, number> = {
  hot: 3,
  warm: 7,
  cold: 15,
};

export const getLeadTemperature = (client: Client, followUps: FollowUp[]): LeadTemperature => {
  const activeFollowUps = followUps.filter((f) => f.clientId === client.id && f.status !== 'completed');
  if (client.status === 'vip' || activeFollowUps.some((f) => f.priority === 'high')) return 'hot';

  const lastContact = client.lastContactDate ? new Date(client.lastContactDate).getTime() : 0;
  const daysSinceContact = lastContact ? Math.max(0, Math.floor((Date.now() - lastContact) / 86400000)) : 999;
  if (daysSinceContact <= 7 || activeFollowUps.some((f) => f.priority === 'medium')) return 'warm';
  return 'cold';
};

export const getReminderDate = (from = new Date(), temperature: LeadTemperature) => {
  const next = new Date(from);
  next.setHours(10, 0, 0, 0);
  next.setDate(next.getDate() + LEAD_REMINDER_DAYS[temperature]);
  return next;
};

export const isOverdueFollowUp = (followUp: FollowUp, now = new Date()) => {
  if (followUp.status === 'completed') return false;
  const [y, m, d] = followUp.dueDate.split('-').map(Number);
  const due = new Date(y, m - 1, d, 23, 59, 59, 999);
  return due.getTime() < now.getTime();
};
