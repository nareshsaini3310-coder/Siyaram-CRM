import { Client, FollowUp, Project, CommLog } from '../types';

// Web Audio API offline sound synthesizer (Works 100% offline without internet or external files)
let audioCtx: AudioContext | null = null;

const getAudioContext = (): AudioContext | null => {
  if (typeof window === 'undefined') return null;
  try {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  } catch (err) {
    console.warn('Web Audio Context initialization error:', err);
    return null;
  }
};

/**
 * Plays a warm double-bell alert chime (offline)
 */
export const playNotificationChime = () => {
  const ctx = getAudioContext();
  if (!ctx) return;

  try {
    const now = ctx.currentTime;

    // Note 1: 587.33 Hz (D5)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now);
    gain1.gain.setValueAtTime(0.3, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.5);

    // Note 2: 880 Hz (A5)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880, now + 0.15);
    gain2.gain.setValueAtTime(0.35, now + 0.15);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.15);
    osc2.stop(now + 0.7);
  } catch (e) {
    console.warn('Audio chime error:', e);
  }
};

/**
 * Plays an urgent triple chime for the 2-Minute Call Alert
 */
export const playUrgent2MinChime = () => {
  const ctx = getAudioContext();
  if (!ctx) return;

  try {
    const now = ctx.currentTime;
    const notes = [659.25, 783.99, 987.77]; // E5, G5, B5

    notes.forEach((freq, idx) => {
      const startTime = now + idx * 0.12;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.4, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.6);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + 0.6);
    });
  } catch (e) {
    console.warn('Urgent chime error:', e);
  }
};

/**
 * Triggers hardware vibration if supported on mobile devices
 */
export const vibrateDevice = (pattern: number[] = [200, 100, 200, 100, 300]) => {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignored if restricted
    }
  }
};

/**
 * Checks system notification permission status
 */
export const getNotificationPermission = (): NotificationPermission | 'unsupported' => {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission;
};

/**
 * Requests browser notification permission
 */
export const requestNotificationPermission = async (): Promise<boolean> => {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }
  try {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  } catch (err) {
    console.warn('Notification permission request failed:', err);
    return false;
  }
};

/**
 * Shows an OS-level native notification (via Service Worker or direct Web Notification)
 * Works when app is in background, locked, or offline.
 */
export const showNativeNotification = async (
  title: string,
  options: {
    body?: string;
    tag?: string;
    icon?: string;
    data?: any;
    actions?: { action: string; title: string }[];
    requireInteraction?: boolean;
  } = {}
) => {
  playUrgent2MinChime();
  vibrateDevice();

  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }

  if (Notification.permission !== 'granted') {
    return false;
  }

  const notificationOptions = {
    icon: options.icon || '/brand-mark.svg',
    badge: '/brand-mark.svg',
    body: options.body || '',
    tag: options.tag || `siyaram-alert-${Date.now()}`,
    vibrate: [200, 100, 200, 100, 300],
    requireInteraction: options.requireInteraction ?? true,
    renotify: true,
    data: options.data || {},
    actions: options.actions || [
      { action: 'call', title: '📞 Call Now' },
      { action: 'whatsapp', title: '💬 WhatsApp' }
    ],
  };

  try {
    // Try Service Worker registration first (allows background & action handling)
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.ready;
      if (reg && 'showNotification' in reg) {
        await reg.showNotification(title, notificationOptions as any);
        return true;
      }
    }

    // Fallback to standard Notification API (Strip actions as standard window Notification throws TypeError if actions are present)
    const { actions, ...standardOptions } = notificationOptions;
    new Notification(title, standardOptions);
    return true;
  } catch (err) {
    console.warn('Failed to show native notification:', err);
    return false;
  }
};

/**
 * Parses dueDate ("2026-09-18") and scheduledTime ("14:30" or "02:30 PM") into a Date object
 */
export const parseFollowUpDateTime = (dueDateStr: string, timeStr?: string): Date => {
  const fallback = new Date(dueDateStr);

  if (!timeStr || !timeStr.trim()) {
    // Default to 10:00 AM on the due date
    fallback.setHours(10, 0, 0, 0);
    return fallback;
  }

  const cleanTime = timeStr.trim();
  let hours = 10;
  let minutes = 0;

  // Handle 12-hour format e.g. "02:30 PM" or "11:00 AM"
  const is12Hour = /pm|am/i.test(cleanTime);
  const match = cleanTime.match(/(\d+):(\d+)(?:\s*(am|pm))?/i);

  if (match) {
    hours = parseInt(match[1], 10);
    minutes = parseInt(match[2], 10);
    const meridiem = match[3]?.toLowerCase();

    if (is12Hour) {
      if (meridiem === 'pm' && hours < 12) hours += 12;
      if (meridiem === 'am' && hours === 12) hours = 0;
    }
  }

  const [y, m, d] = dueDateStr.split('-').map((v) => parseInt(v, 10));
  if (y && m && d) {
    return new Date(y, m - 1, d, hours, minutes, 0, 0);
  }

  fallback.setHours(hours, minutes, 0, 0);
  return fallback;
};

/**
 * Extracts and formats the summary of the last conversation/discussion with the client
 */
export const getLastConversationSummary = (
  client?: Client,
  commLogs: CommLog[] = []
): string => {
  if (!client) return 'Koi pichli baat-cheet record nahi hai.';

  // 1. Check client's specific next follow-up note
  if (client.nextFollowUpNote && client.nextFollowUpNote.trim()) {
    return client.nextFollowUpNote.trim();
  }

  // 2. Check communication logs for this client
  const clientLogs = commLogs
    .filter((l) => l.clientId === client.id)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  if (clientLogs.length > 0) {
    const latest = clientLogs[0];
    const logNote = latest.notes || latest.messageBody;
    if (logNote && logNote.trim()) {
      const channelLabel =
        latest.channel === 'call'
          ? 'Pichli Call'
          : latest.channel === 'whatsapp'
          ? 'Pichla WhatsApp'
          : 'Pichla Note';
      return `${channelLabel}: "${logNote.trim()}"`;
    }
  }

  // 3. Check client notes
  if (client.notes && client.notes.trim()) {
    return client.notes.trim();
  }

  return 'Inquiry registered regarding Siyaram project options. Follow-up for site visit & pricing.';
};

/**
 * Returns the title of the project linked to a follow-up or client
 */
export const getLinkedProjectTitle = (
  projectId?: string,
  projects: Project[] = []
): string => {
  if (!projectId) return 'Siyaram Estates Portfolio';
  const found = projects.find((p) => p.id === projectId);
  return found?.title || 'Siyaram Estates Portfolio';
};

const ALERTED_STORAGE_KEY = 'siyaram_alerted_followups_v1';
const SNOOZED_STORAGE_KEY = 'siyaram_snoozed_followups_v1';

export const getLocalDateKey = (date = new Date()): string => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

/**
 * Checks if a 2-minute alert has already been fired for this follow-up today
 */
export const hasAlertFired = (id: string, type: '2min' | 'due' = '2min'): boolean => {
  if (typeof window === 'undefined') return false;
  try {
    const raw = sessionStorage.getItem(ALERTED_STORAGE_KEY) || '{}';
    const parsed = JSON.parse(raw);
    const key = `${id}_${type}_${getLocalDateKey()}`;
    return Boolean(parsed[key]);
  } catch {
    return false;
  }
};

export const snoozeAlert = (id: string, minutes: number) => {
  if (typeof window === 'undefined') return;
  try {
    const raw = sessionStorage.getItem(SNOOZED_STORAGE_KEY) || '{}';
    const parsed = JSON.parse(raw);
    parsed[id] = Date.now() + minutes * 60_000;
    sessionStorage.setItem(SNOOZED_STORAGE_KEY, JSON.stringify(parsed));
  } catch {
    // Ignored
  }
};

export const isAlertSnoozed = (id: string): boolean => {
  if (typeof window === 'undefined') return false;
  try {
    const raw = sessionStorage.getItem(SNOOZED_STORAGE_KEY) || '{}';
    const parsed = JSON.parse(raw);
    const until = Number(parsed[id] || 0);
    if (until > Date.now()) return true;
    if (parsed[id]) {
      delete parsed[id];
      sessionStorage.setItem(SNOOZED_STORAGE_KEY, JSON.stringify(parsed));
    }
  } catch {
    // Ignored
  }
  return false;
};

/**
 * Marks a 2-minute alert as fired to prevent repeating
 */
export const markAlertFired = (id: string, type: '2min' | 'due' = '2min') => {
  if (typeof window === 'undefined') return;
  try {
    const raw = sessionStorage.getItem(ALERTED_STORAGE_KEY) || '{}';
    const parsed = JSON.parse(raw);
    const key = `${id}_${type}_${getLocalDateKey()}`;
    parsed[key] = Date.now();
    sessionStorage.setItem(ALERTED_STORAGE_KEY, JSON.stringify(parsed));
  } catch {
    // Ignored
  }
};
