import React, { useRef, useCallback } from 'react';
import type { MouseEvent as ReactMouseEvent, TouchEvent as ReactTouchEvent } from 'react';
import { haptics } from './haptics';

interface LongPressOptions {
  threshold?: number; // ms to trigger long press (default: 450ms)
  onStart?: () => void;
  onCancel?: () => void;
  onFinish?: () => void;
}

/**
 * Custom hook providing a reliable, tactile Long-Press gesture for both touch and desktop pointer events.
 * Cancels if the user scrolls (pointer moves > 10px), triggers haptic vibration on success,
 * and seamlessly preserves standard click/tap when released before the threshold.
 */
export function useLongPress(
  onLongPress: (e: ReactMouseEvent | ReactTouchEvent) => void,
  onClick?: (e: ReactMouseEvent | ReactTouchEvent) => void,
  options: LongPressOptions = {}
) {
  const { threshold = 450, onStart, onCancel, onFinish } = options;
  const isLongPressTriggered = useRef(false);
  const isPointerDown = useRef(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startCoordinates = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const start = useCallback(
    (e: ReactMouseEvent | ReactTouchEvent) => {
      // Don't trigger if interacting with an inner interactive control
      const target = e.target as HTMLElement;
      if (target.closest('button, a, input, select, textarea, [data-prevent-long-press]')) {
        return;
      }

      isLongPressTriggered.current = false;
      isPointerDown.current = true;

      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      startCoordinates.current = { x: clientX, y: clientY };

      if (onStart) onStart();

      timerRef.current = setTimeout(() => {
        isLongPressTriggered.current = true;
        haptics.heavy();
        if (onFinish) onFinish();
        onLongPress(e);
      }, threshold);
    },
    [onLongPress, threshold, onStart, onFinish]
  );

  const clear = useCallback(
    (e: ReactMouseEvent | ReactTouchEvent, shouldTriggerClick = true) => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }

      if (isPointerDown.current) {
        if (!isLongPressTriggered.current) {
          if (onCancel) onCancel();
          if (shouldTriggerClick && onClick) {
            onClick(e);
          }
        }
      }

      isPointerDown.current = false;

      // Small cooldown to prevent synthesized click bubbling after a successful long-press
      setTimeout(() => {
        isLongPressTriggered.current = false;
      }, 80);
    },
    [onClick, onCancel]
  );

  const move = useCallback(
    (e: ReactMouseEvent | ReactTouchEvent) => {
      if (!isPointerDown.current || !timerRef.current) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      const dx = Math.abs(clientX - startCoordinates.current.x);
      const dy = Math.abs(clientY - startCoordinates.current.y);

      // If finger/mouse moved more than 10px, the user is scrolling -> cancel long press
      if (dx > 10 || dy > 10) {
        if (timerRef.current) {
          clearTimeout(timerRef.current);
          timerRef.current = null;
        }
        if (onCancel) onCancel();
      }
    },
    [onCancel]
  );

  return {
    onMouseDown: start,
    onMouseUp: (e: ReactMouseEvent) => clear(e, true),
    onMouseLeave: (e: ReactMouseEvent) => clear(e, false),
    onTouchStart: start,
    onTouchEnd: (e: ReactTouchEvent) => clear(e, true),
    onTouchMove: move,
    onContextMenu: (e: ReactMouseEvent) => {
      // Allow desktop right-click as an accessible secondary trigger for the context menu
      e.preventDefault();
      haptics.medium();
      onLongPress(e);
    },
  };
}
