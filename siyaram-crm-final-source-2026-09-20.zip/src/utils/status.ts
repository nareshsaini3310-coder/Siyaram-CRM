import { ClientStatus, ProjectStatus } from '../types';

export const getClientStatusColor = (status: ClientStatus): string => {
  switch (status) {
    case 'active':
      return 'bg-emerald-500';
    case 'vip':
      return 'bg-amber-500';
    case 'lead':
      return 'bg-blue-500';
    case 'past':
      return 'bg-slate-400';
    default:
      return 'bg-slate-200';
  }
};

export const getProjectStatusColor = (status: ProjectStatus): string => {
  switch (status) {
    case 'active':
      return 'bg-emerald-500';
    case 'in_review':
      return 'bg-amber-500';
    case 'planning':
      return 'bg-blue-500';
    case 'completed':
      return 'bg-indigo-500';
    default:
      return 'bg-slate-200';
  }
};

export const clientStatusConfig: { status: ClientStatus; label: string; colorClass: string; description: string }[] = [
  { status: 'lead', label: 'Lead', colorClass: 'bg-blue-500', description: 'Prospective clients currently in the initial sales pipeline' },
  { status: 'active', label: 'Active', colorClass: 'bg-emerald-500', description: 'Clients with ongoing interactions or active properties' },
  { status: 'vip', label: 'VIP', colorClass: 'bg-amber-500', description: 'High-value clients requiring priority attention' },
  { status: 'past', label: 'Past', colorClass: 'bg-slate-400', description: 'Former clients with no currently active engagements' },
];

export const projectStatusConfig: { status: ProjectStatus; label: string; colorClass: string; description: string }[] = [
  { status: 'planning', label: 'Planning', colorClass: 'bg-blue-500', description: 'Project is in the initial scoping and design phase' },
  { status: 'active', label: 'Active', colorClass: 'bg-emerald-500', description: 'Construction or development is currently underway' },
  { status: 'in_review', label: 'In Review', colorClass: 'bg-amber-500', description: 'Pending approvals, inspections, or client feedback' },
  { status: 'completed', label: 'Completed', colorClass: 'bg-indigo-500', description: 'All work finished and handed over successfully' },
];
