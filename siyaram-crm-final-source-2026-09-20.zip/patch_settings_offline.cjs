const fs = require('fs');
let content = fs.readFileSync('src/views/SettingsView.tsx', 'utf8');

// 1. Ensure Wifi/WifiOff is imported
if (!content.includes('Wifi,')) {
  content = content.replace(/import\s+\{([^}]+)\}\s+from\s+['"]lucide-react['"];/, (match, p1) => {
    return `import { ${p1.trim()}, Wifi, WifiOff } from 'lucide-react';`;
  });
}

// 2. Destructure isOfflineMode and toggleOfflineMode
content = content.replace("const { simulateSyncConflict } = useData();", "const { simulateSyncConflict, isOfflineMode, toggleOfflineMode } = useData();");

// 3. Inject the UI
const target = `        </div>
      </div>
      )}
    </div>`;

const replacement = `        </div>

        <div className="pt-4">
          <span className={\`text-xs font-mono uppercase tracking-widest block mb-4 \${tokens.textMuted}\`}>
            Data & Network
          </span>
          <div className="space-y-3">
            <button
              onClick={toggleOfflineMode}
              className={\`w-full flex items-center justify-between p-4 rounded-[20px] transition-colors border \${isOfflineMode ? 'bg-rose-500/10 border-rose-500/30' : tokens.surfaceElevated + ' ' + tokens.border} hover:\${tokens.surfaceHover}\`}
            >
              <div className="flex items-center gap-3">
                <div className={\`w-10 h-10 rounded-full flex items-center justify-center \${isOfflineMode ? 'bg-rose-500/20' : theme === 'dark' ? 'bg-emerald-500/10' : 'bg-emerald-100'}\`}>
                  {isOfflineMode ? (
                    <WifiOff className="w-4 h-4 text-rose-500" />
                  ) : (
                    <Wifi className={\`w-4 h-4 \${theme === 'dark' ? 'text-emerald-500' : 'text-emerald-600'}\`} />
                  )}
                </div>
                <div className="text-left">
                  <div className="text-sm font-semibold">{isOfflineMode ? 'Offline Mode Active' : 'Online Mode'}</div>
                  <div className={\`text-xs \${isOfflineMode ? 'text-rose-400' : tokens.textSecondary}\`}>
                    {isOfflineMode ? 'Viewing cached data. Sync paused.' : 'Connected and syncing in real-time.'}
                  </div>
                </div>
              </div>
              <div className={\`w-10 h-6 rounded-full p-1 transition-colors \${isOfflineMode ? 'bg-rose-500' : tokens.surfaceHover}\`}>
                <div className={\`w-4 h-4 rounded-full bg-white transition-transform \${isOfflineMode ? 'translate-x-4' : 'translate-x-0'}\`} />
              </div>
            </button>

            <button
              onClick={simulateSyncConflict}
              className={\`w-full flex items-center justify-between p-4 rounded-[20px] transition-colors border \${tokens.surfaceElevated} hover:\${tokens.surfaceHover} \${tokens.border}\`}
            >
              <div className="flex items-center gap-3">
                <div className={\`w-10 h-10 rounded-full flex items-center justify-center \${theme === 'dark' ? 'bg-amber-500/10' : 'bg-amber-100'}\`}>
                  <RefreshCw className={\`w-4 h-4 \${theme === 'dark' ? 'text-amber-500' : 'text-amber-600'}\`} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-semibold">Simulate Sync Conflict</div>
                  <div className={\`text-xs \${tokens.textSecondary}\`}>Test the conflict resolution UI</div>
                </div>
              </div>
            </button>
          </div>
        </div>

      </div>
      )}
    </div>`;

content = content.replace(target, replacement);

fs.writeFileSync('src/views/SettingsView.tsx', content);
