import express from "express";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "15mb" }));

// Health check
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    hasApiKey: !!process.env.GEMINI_API_KEY,
    time: new Date().toISOString(),
  });
});

// Real APK Download Endpoint
// NOTE: Node.js cannot "compile" an APK. This endpoint serves an APK file if you have uploaded one.
app.get(["/downloads/Siyaram-CRM-v1.4.2.apk", "/api/download/apk", "/download/apk"], (req, res) => {
  const fileName = "Siyaram-CRM-v1.4.2.apk";
  const apkPath = path.join(process.cwd(), "public", "downloads", fileName);

  if (fs.existsSync(apkPath)) {
    // If the real APK file exists, send it to the user
    res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
    res.setHeader("Content-Type", "application/vnd.android.package-archive");
    res.sendFile(apkPath);
  } else {
    // Fix: Instead of sending a fake text string that corrupts the download, 
    // we clearly return an error if the real APK hasn't been uploaded yet.
    res.status(404).send("Real APK file not found. Please upload the actual compiled 'Siyaram-CRM-v1.4.2.apk' file into the 'public/downloads/' folder.");
  }
});

// Serve public assets (PWA manifest, icons, service worker)
app.use(express.static(path.join(process.cwd(), "public")));

// Vite middleware for development & static serving for production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
